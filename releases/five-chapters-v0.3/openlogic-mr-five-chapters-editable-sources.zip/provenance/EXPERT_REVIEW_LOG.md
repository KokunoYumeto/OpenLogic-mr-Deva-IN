# Terminology and expert-review ledger

This ledger accompanies the Marathi OpenLogic translation at frozen upstream revision `9620cc73f9c8e0ad003c514a5d3748f29611c4c0`. It is maintained for specialist review and correction; review is welcome but is not a completion or publication gate.

The current editable-source coverage is **45/722 units** (OLP-0004–OLP-0048, 559 aligned translated content blocks). The current released reader remains the 16/722-unit `foundations-v0.2` tranche. Decisions without an applied location are pre-adjudications for later units. This is partial coverage and makes no full-corpus claim.

For T001–T044, the rationale provenance is explicitly a **retrospective reconstruction** from the durable decision records and current aligned files. It is not represented as an original contemporaneous motive. T045 onward were recorded with their first current use. Aligned block scopes are exact locations governed by a unit-level decision index; they do not claim that the literal headword occurs in every listed block. Literal line hits are listed separately when found.

Authorities below are only those actually consulted. A missing authority is stated as not checked/not found; no evidence is inferred from an unavailable dictionary or expert. The frozen English mathematics governs theorem meaning. All provisional choices remain open to correction.

Occurrence-level review surfaces add exact source/target lines and the current coherent-reader page range: [readable full occurrence index](EXPERT_REVIEW_OCCURRENCES.md), [priority view](EXPERT_REVIEW_PRIORITY.md), [one-row-per-occurrence CSV](EXPERT_REVIEW_OCCURRENCES.csv), and [machine JSONL](EXPERT_REVIEW_OCCURRENCES.jsonl).

The public DOI record `10.5281/zenodo.22307961` predates this ledger. The next substantive, nonduplicative release will include it under the existing concept DOI `10.5281/zenodo.22307960`; no ledger-only release is created.

## T001 — set

- **Chosen wording:** संच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Native mathematical and university usage; object collection meaning.
- **Alternatives considered:** समुच्चय.
- **Exact aligned source/target scopes:**

  - OLP-0004 B004: [English](../upstream/content/sets-functions-relations/sets/sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/sets.tex)
  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0007 B004–B009: [English](../upstream/content/sets-functions-relations/sets/important-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/important-sets.tex)
  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0009 B004–B019: [English](../upstream/content/sets-functions-relations/sets/pairs-and-products.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/pairs-and-products.tex)
  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0013 B003–B008: [English](../upstream/content/sets-functions-relations/relations/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/reflections.tex)
  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0017 B004–B009: [English](../upstream/content/sets-functions-relations/relations/graphs.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/graphs.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0029 B005–B009, B011, B013–B016, B021–B023, B028–B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0030 B006–B007, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B007–B008, B010, B013–B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0033 B007–B009, B021–B025: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B007–B012, B014–B017, B019–B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B006–B007, B009–B013, B015–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B006–B007, B009–B012, B014–B016, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0037 B006, B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
  - OLP-0038 B005–B012, B014, B018–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B005–B010, B012–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B007, B009–B014, B016–B023: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0041 B005: [English](../upstream/content/sets-functions-relations/arithmetization/arithmetization.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/arithmetization.tex)
  - OLP-0045 B006, B008–B010, B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B009–B010, B012: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B006: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B007: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T001-OLP-0004-B004`, `T001-OLP-0005-B004`, `T001-OLP-0005-B005`, `T001-OLP-0005-B006`, `T001-OLP-0005-B007`, `T001-OLP-0005-B008`, `T001-OLP-0005-B009`, `T001-OLP-0005-B010`, `T001-OLP-0005-B011`, `T001-OLP-0005-B012`, `T001-OLP-0005-B013`, `T001-OLP-0005-B014`, `T001-OLP-0006-B004`, `T001-OLP-0006-B005`, `T001-OLP-0006-B006`, `T001-OLP-0006-B007`, `T001-OLP-0006-B008`, `T001-OLP-0006-B009`, `T001-OLP-0006-B010`, `T001-OLP-0006-B011`, `T001-OLP-0006-B012`, `T001-OLP-0006-B013`, `T001-OLP-0006-B014`, `T001-OLP-0006-B015`, `T001-OLP-0006-B016`, `T001-OLP-0006-B017`, `T001-OLP-0006-B018`, `T001-OLP-0007-B004`, `T001-OLP-0007-B005`, `T001-OLP-0007-B006`, `T001-OLP-0007-B007`, `T001-OLP-0007-B008`, `T001-OLP-0007-B009`, `T001-OLP-0008-B004`, `T001-OLP-0008-B005`, `T001-OLP-0008-B006`, `T001-OLP-0008-B007`, `T001-OLP-0008-B008`, `T001-OLP-0008-B009`, `T001-OLP-0008-B010`, `T001-OLP-0008-B011`, `T001-OLP-0008-B012`, `T001-OLP-0008-B013`, `T001-OLP-0008-B014`, `T001-OLP-0008-B015`, `T001-OLP-0008-B016`, `T001-OLP-0008-B017`, `T001-OLP-0008-B018`, `T001-OLP-0008-B019`, `T001-OLP-0008-B020`, `T001-OLP-0008-B021`, `T001-OLP-0008-B022`, `T001-OLP-0008-B023`, `T001-OLP-0008-B024`, `T001-OLP-0008-B025`, `T001-OLP-0008-B026`, `T001-OLP-0008-B027`, `T001-OLP-0008-B028`, `T001-OLP-0008-B029`, `T001-OLP-0009-B004`, `T001-OLP-0009-B005`, `T001-OLP-0009-B006`, `T001-OLP-0009-B007`, `T001-OLP-0009-B008`, `T001-OLP-0009-B009`, `T001-OLP-0009-B010`, `T001-OLP-0009-B011`, `T001-OLP-0009-B012`, `T001-OLP-0009-B013`, `T001-OLP-0009-B014`, `T001-OLP-0009-B015`, `T001-OLP-0009-B016`, `T001-OLP-0009-B017`, `T001-OLP-0009-B018`, `T001-OLP-0009-B019`, `T001-OLP-0010-B004`, `T001-OLP-0010-B005`, `T001-OLP-0010-B006`, `T001-OLP-0010-B007`, `T001-OLP-0010-B008`, `T001-OLP-0010-B009`, `T001-OLP-0010-B010`, `T001-OLP-0010-B011`, `T001-OLP-0010-B012`, `T001-OLP-0010-B013`, `T001-OLP-0010-B014`, `T001-OLP-0012-B004`, `T001-OLP-0012-B005`, `T001-OLP-0012-B006`, `T001-OLP-0012-B007`, `T001-OLP-0012-B008`, `T001-OLP-0012-B009`, `T001-OLP-0012-B010`, `T001-OLP-0012-B011`, `T001-OLP-0012-B012`, `T001-OLP-0013-B003`, `T001-OLP-0013-B004`, `T001-OLP-0013-B005`, `T001-OLP-0013-B006`, `T001-OLP-0013-B007`, `T001-OLP-0013-B008`, `T001-OLP-0014-B004`, `T001-OLP-0014-B005`, `T001-OLP-0014-B006`, `T001-OLP-0014-B007`, `T001-OLP-0014-B008`, `T001-OLP-0014-B009`, `T001-OLP-0014-B010`, `T001-OLP-0014-B011`, `T001-OLP-0014-B012`, `T001-OLP-0014-B013`, `T001-OLP-0014-B014`, `T001-OLP-0014-B015`, `T001-OLP-0015-B005`, `T001-OLP-0015-B006`, `T001-OLP-0015-B007`, `T001-OLP-0015-B008`, `T001-OLP-0015-B009`, `T001-OLP-0015-B010`, `T001-OLP-0015-B011`, `T001-OLP-0015-B012`, `T001-OLP-0015-B013`, `T001-OLP-0015-B014`, `T001-OLP-0015-B015`, `T001-OLP-0016-B004`, `T001-OLP-0016-B005`, `T001-OLP-0016-B006`, `T001-OLP-0016-B007`, `T001-OLP-0016-B008`, `T001-OLP-0016-B009`, `T001-OLP-0016-B010`, `T001-OLP-0016-B011`, `T001-OLP-0016-B012`, `T001-OLP-0016-B013`, `T001-OLP-0016-B014`, `T001-OLP-0016-B015`, `T001-OLP-0016-B016`, `T001-OLP-0016-B017`, `T001-OLP-0016-B018`, `T001-OLP-0016-B019`, `T001-OLP-0016-B020`, `T001-OLP-0016-B021`, `T001-OLP-0016-B022`, `T001-OLP-0016-B023`, `T001-OLP-0016-B024`, `T001-OLP-0016-B025`, `T001-OLP-0016-B026`, `T001-OLP-0016-B027`, `T001-OLP-0016-B028`, `T001-OLP-0016-B029`, `T001-OLP-0017-B004`, `T001-OLP-0017-B005`, `T001-OLP-0017-B006`, `T001-OLP-0017-B007`, `T001-OLP-0017-B008`, `T001-OLP-0017-B009`, `T001-OLP-0018-B004`, `T001-OLP-0018-B005`, `T001-OLP-0018-B006`, `T001-OLP-0018-B008`, `T001-OLP-0018-B009`, `T001-OLP-0018-B010`, `T001-OLP-0018-B011`, `T001-OLP-0018-B012`, `T001-OLP-0018-B013`, `T001-OLP-0018-B014`, `T001-OLP-0018-B015`, `T001-OLP-0018-B016`, `T001-OLP-0018-B017`, `T001-OLP-0018-B018`, `T001-OLP-0018-B019`, `T001-OLP-0018-B020`, `T001-OLP-0019-B004`, `T001-OLP-0019-B005`, `T001-OLP-0019-B006`, `T001-OLP-0019-B007`, `T001-OLP-0019-B008`, `T001-OLP-0019-B009`, `T001-OLP-0019-B010`, `T001-OLP-0019-B011`, `T001-OLP-0019-B012`, `T001-OLP-0019-B013`, `T001-OLP-0019-B014`, `T001-OLP-0019-B015`, `T001-OLP-0019-B016`, `T001-OLP-0019-B017`, `T001-OLP-0019-B018`, `T001-OLP-0019-B019`, `T001-OLP-0019-B020`, `T001-OLP-0029-B005`, `T001-OLP-0029-B006`, `T001-OLP-0029-B007`, `T001-OLP-0029-B008`, `T001-OLP-0029-B009`, `T001-OLP-0029-B011`, `T001-OLP-0029-B013`, `T001-OLP-0029-B014`, `T001-OLP-0029-B015`, `T001-OLP-0029-B016`, `T001-OLP-0029-B021`, `T001-OLP-0029-B022`, `T001-OLP-0029-B023`, `T001-OLP-0029-B028`, `T001-OLP-0029-B029`, `T001-OLP-0029-B030`, `T001-OLP-0029-B031`, `T001-OLP-0029-B032`, `T001-OLP-0029-B033`, `T001-OLP-0029-B034`, `T001-OLP-0029-B035`, `T001-OLP-0030-B006`, `T001-OLP-0030-B007`, `T001-OLP-0030-B009`, `T001-OLP-0031-B007`, `T001-OLP-0031-B008`, `T001-OLP-0031-B010`, `T001-OLP-0031-B013`, `T001-OLP-0031-B014`, `T001-OLP-0031-B015`, `T001-OLP-0031-B016`, `T001-OLP-0031-B017`, `T001-OLP-0033-B007`, `T001-OLP-0033-B008`, `T001-OLP-0033-B009`, `T001-OLP-0033-B021`, `T001-OLP-0033-B022`, `T001-OLP-0033-B023`, `T001-OLP-0033-B024`, `T001-OLP-0033-B025`, `T001-OLP-0034-B007`, `T001-OLP-0034-B008`, `T001-OLP-0034-B009`, `T001-OLP-0034-B010`, `T001-OLP-0034-B011`, `T001-OLP-0034-B012`, `T001-OLP-0034-B014`, `T001-OLP-0034-B015`, `T001-OLP-0034-B016`, `T001-OLP-0034-B017`, `T001-OLP-0034-B019`, `T001-OLP-0034-B020`, `T001-OLP-0034-B021`, `T001-OLP-0035-B006`, `T001-OLP-0035-B007`, `T001-OLP-0035-B009`, `T001-OLP-0035-B010`, `T001-OLP-0035-B011`, `T001-OLP-0035-B012`, `T001-OLP-0035-B013`, `T001-OLP-0035-B015`, `T001-OLP-0035-B016`, `T001-OLP-0035-B017`, `T001-OLP-0035-B018`, `T001-OLP-0036-B006`, `T001-OLP-0036-B007`, `T001-OLP-0036-B009`, `T001-OLP-0036-B010`, `T001-OLP-0036-B011`, `T001-OLP-0036-B012`, `T001-OLP-0036-B014`, `T001-OLP-0036-B015`, `T001-OLP-0036-B016`, `T001-OLP-0036-B018`, `T001-OLP-0037-B006`, `T001-OLP-0037-B008`, `T001-OLP-0037-B010`, `T001-OLP-0038-B005`, `T001-OLP-0038-B006`, `T001-OLP-0038-B007`, `T001-OLP-0038-B008`, `T001-OLP-0038-B009`, `T001-OLP-0038-B010`, `T001-OLP-0038-B011`, `T001-OLP-0038-B012`, `T001-OLP-0038-B014`, `T001-OLP-0038-B018`, `T001-OLP-0038-B019`, `T001-OLP-0039-B005`, `T001-OLP-0039-B006`, `T001-OLP-0039-B007`, `T001-OLP-0039-B008`, `T001-OLP-0039-B009`, `T001-OLP-0039-B010`, `T001-OLP-0039-B012`, `T001-OLP-0039-B013`, `T001-OLP-0039-B014`, `T001-OLP-0039-B015`, `T001-OLP-0039-B016`, `T001-OLP-0039-B017`, `T001-OLP-0039-B018`, `T001-OLP-0040-B007`, `T001-OLP-0040-B009`, `T001-OLP-0040-B010`, `T001-OLP-0040-B011`, `T001-OLP-0040-B012`, `T001-OLP-0040-B013`, `T001-OLP-0040-B014`, `T001-OLP-0040-B016`, `T001-OLP-0040-B017`, `T001-OLP-0040-B018`, `T001-OLP-0040-B019`, `T001-OLP-0040-B020`, `T001-OLP-0040-B021`, `T001-OLP-0040-B022`, `T001-OLP-0040-B023`, `T001-OLP-0041-B005`, `T001-OLP-0045-B006`, `T001-OLP-0045-B008`, `T001-OLP-0045-B009`, `T001-OLP-0045-B010`, `T001-OLP-0045-B012`, `T001-OLP-0046-B009`, `T001-OLP-0046-B010`, `T001-OLP-0046-B012`, `T001-OLP-0047-B006`, `T001-OLP-0048-B007`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/arithmetization.tex:1, 12`; `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:1, 28, 35, 76, 117, 177, 181`; `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:1, 24, 182`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:1, 35, 48–49, 55, 59, 65`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:1, 33, 41, 46–48, 54, 57, 60, 65, 74, 77, 87, 92, 94–95`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:1, 13, 33, 35, 71–72, 74`; `upstream/content/sets-functions-relations/relations/graphs.tex:1, 25–26, 30–31, 35, 37, 40, 73`; `upstream/content/sets-functions-relations/relations/operations.tex:1, 15, 20`; `upstream/content/sets-functions-relations/relations/orders.tex:1, 54–55, 73`; `upstream/content/sets-functions-relations/relations/reflections.tex:1, 12, 17–18, 21, 38, 42–46, 48, 50, 52–55, 57, 61–62, 65–66, 71, 75`; `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:1, 3, 9–10, 13, 15–16, 21, 23, 27, 29–31, 34–35, 45, 49, 56, 63, 85, 113, 121`; `upstream/content/sets-functions-relations/relations/special-properties.tex:1, 66`; `upstream/content/sets-functions-relations/relations/trees.tex:1, 22, 43–44, 46, 50, 53, 85, 92, 97, 111`; `upstream/content/sets-functions-relations/sets/basics.tex:1–2, 9, 12–16, 20, 27, 34, 36, 41, 48, 50, 52, 58, 62, 84, 86, 88, 90, 94, 99–100`; `upstream/content/sets-functions-relations/sets/important-sets.tex:1–3, 9–10, 13–14, 18, 20, 22, 24, 26, 29, 40–41, 47, 63`; `upstream/content/sets-functions-relations/sets/pairs-and-products.tex:1–2, 9, 13, 19, 25, 34, 40, 49, 53, 69–71, 116, 123`; `upstream/content/sets-functions-relations/sets/russells-paradox.tex:1–2, 10, 14, 16–18, 23, 27–31, 33–34, 38, 46, 57–59, 67, 73, 77, 79–82`; `upstream/content/sets-functions-relations/sets/sets.tex:1–2, 8, 14`; `upstream/content/sets-functions-relations/sets/subsets.tex:1–2, 9–10, 13–14, 20, 28–29, 35–36, 38, 42, 50, 72–73, 75–77, 86`; `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:1–2, 9, 13, 16–17, 19, 21, 25, 30, 35–36, 44, 47, 50, 60, 65, 72–73, 77, 82, 85, 88–89, 91, 101–106, 110, 121, 135, 138, 144, 152, 157, 163`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:1–2, 11, 14, 16, 18–20, 33, 44, 57, 112, 118, 130, 134, 138, 144`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:1–2, 11, 15, 21–22, 28–29, 34–36, 39–42, 47, 49, 59, 65, 78, 106`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:1–2, 11, 14, 22, 24, 28, 44, 46, 49, 64, 84, 88, 95, 115, 143, 182, 187, 209, 213, 225, 253, 269, 271–272`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:1–3, 13–16, 40`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:1–2, 11, 21, 23, 33, 44, 46, 48–49, 101, 108, 121, 134, 136, 148, 155`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:1–2, 11, 20–23, 26–27, 33, 43, 142, 159, 164, 182, 184, 195, 207`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:1–2, 47, 67, 83, 87–88, 93–94, 100–101`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:1–2, 34–35, 58, 64, 107, 113, 119, 124–125, 131, 137`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:1–2, 21, 33–34, 55, 57, 61, 104, 109, 115, 120–122, 128–129, 135`; `upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:1–2, 18, 49`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:1–2, 15–17, 80`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/arithmetization.tex:11`; `mr/content/sets-functions-relations/arithmetization/cauchy.tex:29, 34, 178, 182`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:24, 157, 179`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:34, 46, 48, 54, 58, 64, 68`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:31, 38, 42–43, 45, 51, 54, 57, 62–63, 71–73, 87, 89–90`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:13, 31–33, 70–71, 73`; `mr/content/sets-functions-relations/relations/graphs.tex:24–25, 29, 33, 35–36, 70`; `mr/content/sets-functions-relations/relations/operations.tex:14, 20`; `mr/content/sets-functions-relations/relations/orders.tex:51, 69`; `mr/content/sets-functions-relations/relations/reflections.tex:12, 18, 36, 40–43, 46, 49–50, 52–53, 56, 59–60, 63–64, 68, 71`; `mr/content/sets-functions-relations/relations/relations-as-sets.tex:10, 13–14, 16, 20, 26, 28–29, 31, 33–35, 44, 47, 49, 55, 63, 79, 84–85, 91, 109, 111, 119`; `mr/content/sets-functions-relations/relations/special-properties.tex:61`; `mr/content/sets-functions-relations/relations/trees.tex:21, 41, 43, 45, 49, 52, 72–73, 83, 91, 96, 111`; `mr/content/sets-functions-relations/sets/basics.tex:12–16, 19, 26, 33–34, 39, 44–45, 47, 49, 55–56, 58, 62, 82–84, 87, 91, 96–97`; `mr/content/sets-functions-relations/sets/important-sets.tex:10, 13–14, 18, 20, 22, 24, 26, 28, 39–40, 47, 61–62`; `mr/content/sets-functions-relations/sets/pairs-and-products.tex:13, 20, 26, 40, 50, 54, 70, 72, 119, 127`; `mr/content/sets-functions-relations/sets/russells-paradox.tex:14, 16–18, 20–22, 25–31, 34–35, 40, 43, 55, 57, 65, 73–74, 77–80`; `mr/content/sets-functions-relations/sets/sets.tex:8`; `mr/content/sets-functions-relations/sets/subsets.tex:10, 13–14, 19–22, 24, 28–29, 32, 36–38, 43, 45, 50, 58, 75–76, 78–80, 87, 89, 98`; `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:13, 16–17, 19, 21, 25–26, 30, 35–36, 43, 47, 51, 63, 67–68, 74–75, 79, 84, 87, 90, 93, 103, 105–108, 113–114, 116, 124–125, 127, 138, 141, 143–144, 147, 156, 160–161, 166–167`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:11, 14–17, 19–20, 33, 45, 57, 76, 78, 83, 98, 116–117, 136–137, 152, 154`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:11, 14, 21–22, 28–29, 34–36, 38–39, 41, 46, 56, 63, 75, 104`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:11, 14, 23–24, 29, 44, 46, 49, 63, 81, 86, 93, 112, 140, 184, 189, 212, 216, 228, 262, 282, 285–286`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:13–16, 40, 100`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:11, 21, 23, 34, 44–45, 48, 60, 99, 101, 109, 119–121, 134, 137, 150, 155`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:11, 20–22, 24–26, 31, 42, 140, 149–151, 155, 161, 178, 180, 194, 203`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:46, 66, 83, 87, 92, 95–97, 101–102, 111`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:34, 60, 66, 68, 109, 115, 121, 126–128, 134–135, 141`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:21, 33, 56, 58, 63–64, 94, 106, 110, 115, 121, 126–128, 134–135, 141`; `mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:17, 46`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:15, 81`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P007, MR-C006, विधेय / संख्यापनीय तर्कशास्त्र आणि संच उपपत्ती, topics 1 and 4, printed page 14. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “संच” remain, or should one of “समुच्चय” replace it? Does the chosen wording preserve the technical sense of set without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T002 — element/member

- **Chosen wording:** घटक / सदस्य
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Default token घटक; सदस्य as synonym when English introduces it; never confuse membership with subset.
- **Alternatives considered:** अवयव.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0007 B004–B009: [English](../upstream/content/sets-functions-relations/sets/important-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/important-sets.tex)
  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0009 B004–B019: [English](../upstream/content/sets-functions-relations/sets/pairs-and-products.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/pairs-and-products.tex)
  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0013 B003–B008: [English](../upstream/content/sets-functions-relations/relations/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/reflections.tex)
  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0017 B004–B009: [English](../upstream/content/sets-functions-relations/relations/graphs.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/graphs.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0029 B007–B009, B011, B014–B015, B024, B029–B032: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0030 B006, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B009, B014–B015: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0033 B007–B009, B012–B013, B015–B017, B019, B022–B024: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B011, B013, B015: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B006, B014–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0038 B007, B010, B012: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B008–B010, B012–B013: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B013–B015, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0042 B005, B014: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B006: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0044 B012: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B006, B010: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T002-OLP-0005-B004`, `T002-OLP-0005-B005`, `T002-OLP-0005-B006`, `T002-OLP-0005-B007`, `T002-OLP-0005-B008`, `T002-OLP-0005-B009`, `T002-OLP-0005-B010`, `T002-OLP-0005-B011`, `T002-OLP-0005-B012`, `T002-OLP-0005-B013`, `T002-OLP-0005-B014`, `T002-OLP-0006-B004`, `T002-OLP-0006-B005`, `T002-OLP-0006-B006`, `T002-OLP-0006-B007`, `T002-OLP-0006-B008`, `T002-OLP-0006-B009`, `T002-OLP-0006-B010`, `T002-OLP-0006-B011`, `T002-OLP-0006-B012`, `T002-OLP-0006-B013`, `T002-OLP-0006-B014`, `T002-OLP-0006-B015`, `T002-OLP-0006-B016`, `T002-OLP-0006-B017`, `T002-OLP-0006-B018`, `T002-OLP-0007-B004`, `T002-OLP-0007-B005`, `T002-OLP-0007-B006`, `T002-OLP-0007-B007`, `T002-OLP-0007-B008`, `T002-OLP-0007-B009`, `T002-OLP-0008-B004`, `T002-OLP-0008-B005`, `T002-OLP-0008-B006`, `T002-OLP-0008-B007`, `T002-OLP-0008-B008`, `T002-OLP-0008-B009`, `T002-OLP-0008-B010`, `T002-OLP-0008-B011`, `T002-OLP-0008-B012`, `T002-OLP-0008-B013`, `T002-OLP-0008-B014`, `T002-OLP-0008-B015`, `T002-OLP-0008-B016`, `T002-OLP-0008-B017`, `T002-OLP-0008-B018`, `T002-OLP-0008-B019`, `T002-OLP-0008-B020`, `T002-OLP-0008-B021`, `T002-OLP-0008-B022`, `T002-OLP-0008-B023`, `T002-OLP-0008-B024`, `T002-OLP-0008-B025`, `T002-OLP-0008-B026`, `T002-OLP-0008-B027`, `T002-OLP-0008-B028`, `T002-OLP-0008-B029`, `T002-OLP-0009-B004`, `T002-OLP-0009-B005`, `T002-OLP-0009-B006`, `T002-OLP-0009-B007`, `T002-OLP-0009-B008`, `T002-OLP-0009-B009`, `T002-OLP-0009-B010`, `T002-OLP-0009-B011`, `T002-OLP-0009-B012`, `T002-OLP-0009-B013`, `T002-OLP-0009-B014`, `T002-OLP-0009-B015`, `T002-OLP-0009-B016`, `T002-OLP-0009-B017`, `T002-OLP-0009-B018`, `T002-OLP-0009-B019`, `T002-OLP-0010-B004`, `T002-OLP-0010-B005`, `T002-OLP-0010-B006`, `T002-OLP-0010-B007`, `T002-OLP-0010-B008`, `T002-OLP-0010-B009`, `T002-OLP-0010-B010`, `T002-OLP-0010-B011`, `T002-OLP-0010-B012`, `T002-OLP-0010-B013`, `T002-OLP-0010-B014`, `T002-OLP-0012-B004`, `T002-OLP-0012-B005`, `T002-OLP-0012-B006`, `T002-OLP-0012-B007`, `T002-OLP-0012-B008`, `T002-OLP-0012-B009`, `T002-OLP-0012-B010`, `T002-OLP-0012-B011`, `T002-OLP-0012-B012`, `T002-OLP-0013-B003`, `T002-OLP-0013-B004`, `T002-OLP-0013-B005`, `T002-OLP-0013-B006`, `T002-OLP-0013-B007`, `T002-OLP-0013-B008`, `T002-OLP-0014-B004`, `T002-OLP-0014-B005`, `T002-OLP-0014-B006`, `T002-OLP-0014-B007`, `T002-OLP-0014-B008`, `T002-OLP-0014-B009`, `T002-OLP-0014-B010`, `T002-OLP-0014-B011`, `T002-OLP-0014-B012`, `T002-OLP-0014-B013`, `T002-OLP-0014-B014`, `T002-OLP-0014-B015`, `T002-OLP-0015-B005`, `T002-OLP-0015-B006`, `T002-OLP-0015-B007`, `T002-OLP-0015-B008`, `T002-OLP-0015-B009`, `T002-OLP-0015-B010`, `T002-OLP-0015-B011`, `T002-OLP-0015-B012`, `T002-OLP-0015-B013`, `T002-OLP-0015-B014`, `T002-OLP-0015-B015`, `T002-OLP-0016-B004`, `T002-OLP-0016-B005`, `T002-OLP-0016-B006`, `T002-OLP-0016-B007`, `T002-OLP-0016-B008`, `T002-OLP-0016-B009`, `T002-OLP-0016-B010`, `T002-OLP-0016-B011`, `T002-OLP-0016-B012`, `T002-OLP-0016-B013`, `T002-OLP-0016-B014`, `T002-OLP-0016-B015`, `T002-OLP-0016-B016`, `T002-OLP-0016-B017`, `T002-OLP-0016-B018`, `T002-OLP-0016-B019`, `T002-OLP-0016-B020`, `T002-OLP-0016-B021`, `T002-OLP-0016-B022`, `T002-OLP-0016-B023`, `T002-OLP-0016-B024`, `T002-OLP-0016-B025`, `T002-OLP-0016-B026`, `T002-OLP-0016-B027`, `T002-OLP-0016-B028`, `T002-OLP-0016-B029`, `T002-OLP-0017-B004`, `T002-OLP-0017-B005`, `T002-OLP-0017-B006`, `T002-OLP-0017-B007`, `T002-OLP-0017-B008`, `T002-OLP-0017-B009`, `T002-OLP-0018-B004`, `T002-OLP-0018-B005`, `T002-OLP-0018-B006`, `T002-OLP-0018-B008`, `T002-OLP-0018-B009`, `T002-OLP-0018-B010`, `T002-OLP-0018-B011`, `T002-OLP-0018-B012`, `T002-OLP-0018-B013`, `T002-OLP-0018-B014`, `T002-OLP-0018-B015`, `T002-OLP-0018-B016`, `T002-OLP-0018-B017`, `T002-OLP-0018-B018`, `T002-OLP-0018-B019`, `T002-OLP-0018-B020`, `T002-OLP-0019-B004`, `T002-OLP-0019-B005`, `T002-OLP-0019-B006`, `T002-OLP-0019-B007`, `T002-OLP-0019-B008`, `T002-OLP-0019-B009`, `T002-OLP-0019-B010`, `T002-OLP-0019-B011`, `T002-OLP-0019-B012`, `T002-OLP-0019-B013`, `T002-OLP-0019-B014`, `T002-OLP-0019-B015`, `T002-OLP-0019-B016`, `T002-OLP-0019-B017`, `T002-OLP-0019-B018`, `T002-OLP-0019-B019`, `T002-OLP-0019-B020`, `T002-OLP-0029-B007`, `T002-OLP-0029-B008`, `T002-OLP-0029-B009`, `T002-OLP-0029-B011`, `T002-OLP-0029-B014`, `T002-OLP-0029-B015`, `T002-OLP-0029-B024`, `T002-OLP-0029-B029`, `T002-OLP-0029-B030`, `T002-OLP-0029-B031`, `T002-OLP-0029-B032`, `T002-OLP-0030-B006`, `T002-OLP-0030-B009`, `T002-OLP-0031-B009`, `T002-OLP-0031-B014`, `T002-OLP-0031-B015`, `T002-OLP-0033-B007`, `T002-OLP-0033-B008`, `T002-OLP-0033-B009`, `T002-OLP-0033-B012`, `T002-OLP-0033-B013`, `T002-OLP-0033-B015`, `T002-OLP-0033-B016`, `T002-OLP-0033-B017`, `T002-OLP-0033-B019`, `T002-OLP-0033-B022`, `T002-OLP-0033-B023`, `T002-OLP-0033-B024`, `T002-OLP-0034-B011`, `T002-OLP-0034-B013`, `T002-OLP-0034-B015`, `T002-OLP-0035-B015`, `T002-OLP-0036-B006`, `T002-OLP-0036-B014`, `T002-OLP-0036-B015`, `T002-OLP-0036-B016`, `T002-OLP-0038-B007`, `T002-OLP-0038-B010`, `T002-OLP-0038-B012`, `T002-OLP-0039-B008`, `T002-OLP-0039-B009`, `T002-OLP-0039-B010`, `T002-OLP-0039-B012`, `T002-OLP-0039-B013`, `T002-OLP-0040-B013`, `T002-OLP-0040-B014`, `T002-OLP-0040-B015`, `T002-OLP-0040-B017`, `T002-OLP-0042-B005`, `T002-OLP-0042-B014`, `T002-OLP-0043-B006`, `T002-OLP-0044-B012`, `T002-OLP-0045-B006`, `T002-OLP-0045-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cuts.tex:28`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:18, 47`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:43, 49`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:80`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:19, 71, 80`; `upstream/content/sets-functions-relations/relations/orders.tex:41`; `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:15, 25, 27, 41, 113, 121`; `upstream/content/sets-functions-relations/relations/trees.tex:44–45, 47, 51, 75, 107`; `upstream/content/sets-functions-relations/sets/basics.tex:13–14, 16, 21–22, 28, 34, 42, 52–53, 58, 61, 100`; `upstream/content/sets-functions-relations/sets/important-sets.tex:13, 27, 48, 64, 66`; `upstream/content/sets-functions-relations/sets/pairs-and-products.tex:14, 21, 43, 80, 84–85, 89, 94, 96, 112, 117–118, 121`; `upstream/content/sets-functions-relations/sets/russells-paradox.tex:16, 27, 29–30, 33, 37, 39, 58, 60, 62, 67–68`; `upstream/content/sets-functions-relations/sets/subsets.tex:20, 35, 37, 43, 45–48, 58–59, 99–100`; `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:18–19, 21, 25, 36, 43–44, 60–61, 66, 73, 78, 82, 85, 105–106, 110–111, 113, 122, 124, 152, 158, 163–164`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:22–23, 115, 117, 120–121, 133`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:22, 26, 29, 32, 49, 66`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:22, 24, 29, 38–43, 45, 57, 75–76, 78, 98–99, 104, 106–107, 186–187, 189, 213, 217, 219, 222, 237, 239–240, 244`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:74`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:29–30, 35–36, 39–40, 46, 83, 100`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:29–30, 35, 37, 39–40, 54, 56, 62, 75, 77, 87, 92, 107, 111, 114, 127, 133, 173, 175, 183`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:60, 95`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:57, 65, 78, 93, 98`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:55, 62, 75, 90, 95`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:39`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:27, 32, 104`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:41`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:49, 78`; `mr/content/sets-functions-relations/relations/reflections.tex:41, 53, 57, 64`; `mr/content/sets-functions-relations/relations/relations-as-sets.tex:24, 26, 40, 112`; `mr/content/sets-functions-relations/relations/special-properties.tex:14`; `mr/content/sets-functions-relations/relations/trees.tex:43, 45, 51, 74, 105`; `mr/content/sets-functions-relations/sets/basics.tex:13`; `mr/content/sets-functions-relations/sets/important-sets.tex:47`; `mr/content/sets-functions-relations/sets/pairs-and-products.tex:10, 13, 21, 44, 48, 50, 87, 121`; `mr/content/sets-functions-relations/sets/russells-paradox.tex:16, 27, 33, 65`; `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:124`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:103`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:46–47`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:38, 41, 252`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:78, 82, 95`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:45`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:28, 33, 35, 39, 54, 59, 107, 110`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:59`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:56, 68, 79`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:60, 76, 78`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:39, 75, 81`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P011, MR-C004, संचांचे प्रकार, proper-subset paragraph. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** In the listed formal contexts, should “घटक / सदस्य” remain, or should one of “अवयव” replace it? Does the chosen wording preserve the technical sense of element/member without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T003 — empty set

- **Chosen wording:** रिक्त संच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** No elements; preserve upstream emptyset symbol rather than witness typography.
- **Alternatives considered:** शून्य संच.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0007 B004–B009: [English](../upstream/content/sets-functions-relations/sets/important-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/important-sets.tex)
  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0029 B009, B015–B016, B021–B022, B028, B033–B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0035 B015, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0038 B011, B014: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0040 B013: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0044 B012: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B006, B010: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T003-OLP-0005-B004`, `T003-OLP-0005-B005`, `T003-OLP-0005-B006`, `T003-OLP-0005-B007`, `T003-OLP-0005-B008`, `T003-OLP-0005-B009`, `T003-OLP-0005-B010`, `T003-OLP-0005-B011`, `T003-OLP-0005-B012`, `T003-OLP-0005-B013`, `T003-OLP-0005-B014`, `T003-OLP-0006-B004`, `T003-OLP-0006-B005`, `T003-OLP-0006-B006`, `T003-OLP-0006-B007`, `T003-OLP-0006-B008`, `T003-OLP-0006-B009`, `T003-OLP-0006-B010`, `T003-OLP-0006-B011`, `T003-OLP-0006-B012`, `T003-OLP-0006-B013`, `T003-OLP-0006-B014`, `T003-OLP-0006-B015`, `T003-OLP-0006-B016`, `T003-OLP-0006-B017`, `T003-OLP-0006-B018`, `T003-OLP-0007-B004`, `T003-OLP-0007-B005`, `T003-OLP-0007-B006`, `T003-OLP-0007-B007`, `T003-OLP-0007-B008`, `T003-OLP-0007-B009`, `T003-OLP-0008-B004`, `T003-OLP-0008-B005`, `T003-OLP-0008-B006`, `T003-OLP-0008-B007`, `T003-OLP-0008-B008`, `T003-OLP-0008-B009`, `T003-OLP-0008-B010`, `T003-OLP-0008-B011`, `T003-OLP-0008-B012`, `T003-OLP-0008-B013`, `T003-OLP-0008-B014`, `T003-OLP-0008-B015`, `T003-OLP-0008-B016`, `T003-OLP-0008-B017`, `T003-OLP-0008-B018`, `T003-OLP-0008-B019`, `T003-OLP-0008-B020`, `T003-OLP-0008-B021`, `T003-OLP-0008-B022`, `T003-OLP-0008-B023`, `T003-OLP-0008-B024`, `T003-OLP-0008-B025`, `T003-OLP-0008-B026`, `T003-OLP-0008-B027`, `T003-OLP-0008-B028`, `T003-OLP-0008-B029`, `T003-OLP-0012-B004`, `T003-OLP-0012-B005`, `T003-OLP-0012-B006`, `T003-OLP-0012-B007`, `T003-OLP-0012-B008`, `T003-OLP-0012-B009`, `T003-OLP-0012-B010`, `T003-OLP-0012-B011`, `T003-OLP-0012-B012`, `T003-OLP-0016-B004`, `T003-OLP-0016-B005`, `T003-OLP-0016-B006`, `T003-OLP-0016-B007`, `T003-OLP-0016-B008`, `T003-OLP-0016-B009`, `T003-OLP-0016-B010`, `T003-OLP-0016-B011`, `T003-OLP-0016-B012`, `T003-OLP-0016-B013`, `T003-OLP-0016-B014`, `T003-OLP-0016-B015`, `T003-OLP-0016-B016`, `T003-OLP-0016-B017`, `T003-OLP-0016-B018`, `T003-OLP-0016-B019`, `T003-OLP-0016-B020`, `T003-OLP-0016-B021`, `T003-OLP-0016-B022`, `T003-OLP-0016-B023`, `T003-OLP-0016-B024`, `T003-OLP-0016-B025`, `T003-OLP-0016-B026`, `T003-OLP-0016-B027`, `T003-OLP-0016-B028`, `T003-OLP-0016-B029`, `T003-OLP-0018-B004`, `T003-OLP-0018-B005`, `T003-OLP-0018-B006`, `T003-OLP-0018-B008`, `T003-OLP-0018-B009`, `T003-OLP-0018-B010`, `T003-OLP-0018-B011`, `T003-OLP-0018-B012`, `T003-OLP-0018-B013`, `T003-OLP-0018-B014`, `T003-OLP-0018-B015`, `T003-OLP-0018-B016`, `T003-OLP-0018-B017`, `T003-OLP-0018-B018`, `T003-OLP-0018-B019`, `T003-OLP-0018-B020`, `T003-OLP-0019-B004`, `T003-OLP-0019-B005`, `T003-OLP-0019-B006`, `T003-OLP-0019-B007`, `T003-OLP-0019-B008`, `T003-OLP-0019-B009`, `T003-OLP-0019-B010`, `T003-OLP-0019-B011`, `T003-OLP-0019-B012`, `T003-OLP-0019-B013`, `T003-OLP-0019-B014`, `T003-OLP-0019-B015`, `T003-OLP-0019-B016`, `T003-OLP-0019-B017`, `T003-OLP-0019-B018`, `T003-OLP-0019-B019`, `T003-OLP-0019-B020`, `T003-OLP-0029-B009`, `T003-OLP-0029-B015`, `T003-OLP-0029-B016`, `T003-OLP-0029-B021`, `T003-OLP-0029-B022`, `T003-OLP-0029-B028`, `T003-OLP-0029-B033`, `T003-OLP-0029-B034`, `T003-OLP-0029-B035`, `T003-OLP-0035-B015`, `T003-OLP-0035-B017`, `T003-OLP-0038-B011`, `T003-OLP-0038-B014`, `T003-OLP-0040-B013`, `T003-OLP-0044-B012`, `T003-OLP-0045-B006`, `T003-OLP-0045-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cuts.tex:49, 59`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:74`; `upstream/content/sets-functions-relations/sets/basics.tex:99`; `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:50, 91`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:64`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:48, 58`; `mr/content/sets-functions-relations/arithmetization/reals.tex:84`; `mr/content/sets-functions-relations/sets/basics.tex:96`; `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:51, 93`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:63`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P003, MR-C001, संचांचे प्रकार table, empty/finite/infinite rows, printed page 4. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “रिक्त संच” remain, or should one of “शून्य संच” replace it? Does the chosen wording preserve the technical sense of empty set without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T004 — extensionality

- **Chosen wording:** विस्तारात्मकता
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-attested-label. This choice remains open to correction.
- **Rationale:** Lexical label from government logic glossary observed in tool text; full origin unavailable. Two-way membership concept and prose independently verified in Balbharati. Not dictionary-only semantic evidence.
- **Alternatives considered:** विस्तारता; बहिरंगता.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0036 B012: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
- **Occurrence records:** `T004-OLP-0005-B004`, `T004-OLP-0005-B005`, `T004-OLP-0005-B006`, `T004-OLP-0005-B007`, `T004-OLP-0005-B008`, `T004-OLP-0005-B009`, `T004-OLP-0005-B010`, `T004-OLP-0005-B011`, `T004-OLP-0005-B012`, `T004-OLP-0005-B013`, `T004-OLP-0005-B014`, `T004-OLP-0006-B004`, `T004-OLP-0006-B005`, `T004-OLP-0006-B006`, `T004-OLP-0006-B007`, `T004-OLP-0006-B008`, `T004-OLP-0006-B009`, `T004-OLP-0006-B010`, `T004-OLP-0006-B011`, `T004-OLP-0006-B012`, `T004-OLP-0006-B013`, `T004-OLP-0006-B014`, `T004-OLP-0006-B015`, `T004-OLP-0006-B016`, `T004-OLP-0006-B017`, `T004-OLP-0006-B018`, `T004-OLP-0021-B004`, `T004-OLP-0021-B005`, `T004-OLP-0021-B006`, `T004-OLP-0021-B007`, `T004-OLP-0021-B008`, `T004-OLP-0021-B009`, `T004-OLP-0021-B010`, `T004-OLP-0021-B011`, `T004-OLP-0021-B012`, `T004-OLP-0021-B013`, `T004-OLP-0021-B014`, `T004-OLP-0021-B015`, `T004-OLP-0021-B016`, `T004-OLP-0021-B017`, `T004-OLP-0021-B018`, `T004-OLP-0021-B019`, `T004-OLP-0021-B020`, `T004-OLP-0023-B005`, `T004-OLP-0023-B006`, `T004-OLP-0023-B007`, `T004-OLP-0023-B008`, `T004-OLP-0023-B009`, `T004-OLP-0023-B010`, `T004-OLP-0023-B011`, `T004-OLP-0023-B012`, `T004-OLP-0023-B013`, `T004-OLP-0023-B014`, `T004-OLP-0023-B015`, `T004-OLP-0023-B016`, `T004-OLP-0036-B012`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/function-basics.tex:116`; `upstream/content/sets-functions-relations/functions/functions-relations.tex:33–35`; `upstream/content/sets-functions-relations/sets/basics.tex:10, 26, 32, 35–36, 52, 80, 87, 89, 94`; `upstream/content/sets-functions-relations/sets/subsets.tex:42, 49`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:62`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/functions-relations.tex:33`; `mr/content/sets-functions-relations/sets/basics.tex:10, 25, 85`.
- **Authorities actually checked:**

  - [MR-C007](https://shabdakosh.marathi.gov.in/ananya-glossary/7/e) — MR-P008, MR-C007, extensionality. Do not treat observation hash as source-byte hash or claim full original archived.
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P004, MR-C001, समान संच, opening criterion and examples, printed page 6. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P002, MR-C001, संच लिहिण्याच्या पद्धती, listing and property methods, printed page 2. visually-read-page-image
- **Precise review question:** Does विस्तारात्मकता carry the precise set-theoretic dependence-on-membership sense, without suggesting geometric extension?

## T005 — subset

- **Chosen wording:** उपसंच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Inclusion direction verified from actual page.
- **Alternatives considered:** अंतःसंच.
- **Exact aligned source/target scopes:**

  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0029 B022: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0031 B014–B015: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0033 B022, B024: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B011–B012: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B012, B014–B016, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0039 B012–B013, B016–B017: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B013–B014: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0045 B008, B010, B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B011: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B024, B028: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T005-OLP-0006-B004`, `T005-OLP-0006-B005`, `T005-OLP-0006-B006`, `T005-OLP-0006-B007`, `T005-OLP-0006-B008`, `T005-OLP-0006-B009`, `T005-OLP-0006-B010`, `T005-OLP-0006-B011`, `T005-OLP-0006-B012`, `T005-OLP-0006-B013`, `T005-OLP-0006-B014`, `T005-OLP-0006-B015`, `T005-OLP-0006-B016`, `T005-OLP-0006-B017`, `T005-OLP-0006-B018`, `T005-OLP-0008-B004`, `T005-OLP-0008-B005`, `T005-OLP-0008-B006`, `T005-OLP-0008-B007`, `T005-OLP-0008-B008`, `T005-OLP-0008-B009`, `T005-OLP-0008-B010`, `T005-OLP-0008-B011`, `T005-OLP-0008-B012`, `T005-OLP-0008-B013`, `T005-OLP-0008-B014`, `T005-OLP-0008-B015`, `T005-OLP-0008-B016`, `T005-OLP-0008-B017`, `T005-OLP-0008-B018`, `T005-OLP-0008-B019`, `T005-OLP-0008-B020`, `T005-OLP-0008-B021`, `T005-OLP-0008-B022`, `T005-OLP-0008-B023`, `T005-OLP-0008-B024`, `T005-OLP-0008-B025`, `T005-OLP-0008-B026`, `T005-OLP-0008-B027`, `T005-OLP-0008-B028`, `T005-OLP-0008-B029`, `T005-OLP-0010-B004`, `T005-OLP-0010-B005`, `T005-OLP-0010-B006`, `T005-OLP-0010-B007`, `T005-OLP-0010-B008`, `T005-OLP-0010-B009`, `T005-OLP-0010-B010`, `T005-OLP-0010-B011`, `T005-OLP-0010-B012`, `T005-OLP-0010-B013`, `T005-OLP-0010-B014`, `T005-OLP-0012-B004`, `T005-OLP-0012-B005`, `T005-OLP-0012-B006`, `T005-OLP-0012-B007`, `T005-OLP-0012-B008`, `T005-OLP-0012-B009`, `T005-OLP-0012-B010`, `T005-OLP-0012-B011`, `T005-OLP-0012-B012`, `T005-OLP-0015-B005`, `T005-OLP-0015-B006`, `T005-OLP-0015-B007`, `T005-OLP-0015-B008`, `T005-OLP-0015-B009`, `T005-OLP-0015-B010`, `T005-OLP-0015-B011`, `T005-OLP-0015-B012`, `T005-OLP-0015-B013`, `T005-OLP-0015-B014`, `T005-OLP-0015-B015`, `T005-OLP-0016-B004`, `T005-OLP-0016-B005`, `T005-OLP-0016-B006`, `T005-OLP-0016-B007`, `T005-OLP-0016-B008`, `T005-OLP-0016-B009`, `T005-OLP-0016-B010`, `T005-OLP-0016-B011`, `T005-OLP-0016-B012`, `T005-OLP-0016-B013`, `T005-OLP-0016-B014`, `T005-OLP-0016-B015`, `T005-OLP-0016-B016`, `T005-OLP-0016-B017`, `T005-OLP-0016-B018`, `T005-OLP-0016-B019`, `T005-OLP-0016-B020`, `T005-OLP-0016-B021`, `T005-OLP-0016-B022`, `T005-OLP-0016-B023`, `T005-OLP-0016-B024`, `T005-OLP-0016-B025`, `T005-OLP-0016-B026`, `T005-OLP-0016-B027`, `T005-OLP-0016-B028`, `T005-OLP-0016-B029`, `T005-OLP-0018-B004`, `T005-OLP-0018-B005`, `T005-OLP-0018-B006`, `T005-OLP-0018-B008`, `T005-OLP-0018-B009`, `T005-OLP-0018-B010`, `T005-OLP-0018-B011`, `T005-OLP-0018-B012`, `T005-OLP-0018-B013`, `T005-OLP-0018-B014`, `T005-OLP-0018-B015`, `T005-OLP-0018-B016`, `T005-OLP-0018-B017`, `T005-OLP-0018-B018`, `T005-OLP-0018-B019`, `T005-OLP-0018-B020`, `T005-OLP-0019-B004`, `T005-OLP-0019-B005`, `T005-OLP-0019-B006`, `T005-OLP-0019-B007`, `T005-OLP-0019-B008`, `T005-OLP-0019-B009`, `T005-OLP-0019-B010`, `T005-OLP-0019-B011`, `T005-OLP-0019-B012`, `T005-OLP-0019-B013`, `T005-OLP-0019-B014`, `T005-OLP-0019-B015`, `T005-OLP-0019-B016`, `T005-OLP-0019-B017`, `T005-OLP-0019-B018`, `T005-OLP-0019-B019`, `T005-OLP-0019-B020`, `T005-OLP-0029-B022`, `T005-OLP-0031-B014`, `T005-OLP-0031-B015`, `T005-OLP-0033-B022`, `T005-OLP-0033-B024`, `T005-OLP-0034-B011`, `T005-OLP-0034-B012`, `T005-OLP-0036-B012`, `T005-OLP-0036-B014`, `T005-OLP-0036-B015`, `T005-OLP-0036-B016`, `T005-OLP-0036-B018`, `T005-OLP-0039-B012`, `T005-OLP-0039-B013`, `T005-OLP-0039-B016`, `T005-OLP-0039-B017`, `T005-OLP-0040-B013`, `T005-OLP-0040-B014`, `T005-OLP-0045-B008`, `T005-OLP-0045-B010`, `T005-OLP-0045-B012`, `T005-OLP-0046-B011`, `T005-OLP-0047-B024`, `T005-OLP-0047-B028`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:160`; `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:48, 56, 78, 85, 91, 111`; `upstream/content/sets-functions-relations/relations/trees.tex:47, 74`; `upstream/content/sets-functions-relations/sets/subsets.tex:3, 10, 19, 21–22, 24, 28–29, 31, 36–37, 44, 50, 57, 73, 76, 84, 86, 95`; `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:47, 88`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:74, 76, 82, 111, 129`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:62, 99, 119–121`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:153–155`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:87, 92, 95`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:157`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:68`; `mr/content/sets-functions-relations/relations/relations-as-sets.tex:47, 55, 79, 85, 91, 109`; `mr/content/sets-functions-relations/relations/trees.tex:45, 73`; `mr/content/sets-functions-relations/sets/subsets.tex:10, 19, 21–22, 24, 28–29, 32, 37–38, 45, 50, 58, 76, 79, 87, 89, 98`; `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:47, 90`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:76, 78, 83, 116, 136`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:60, 99, 119–120`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:149–151`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:87, 92, 95–96`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P007, MR-C006, विधेय / संख्यापनीय तर्कशास्त्र आणि संच उपपत्ती, topics 1 and 4, printed page 14. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “उपसंच” remain, or should one of “अंतःसंच” replace it? Does the chosen wording preserve the technical sense of subset without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T006 — proper subset

- **Chosen wording:** उचित उपसंच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-origin-preservation. This choice remains open to correction.
- **Rationale:** Specialized label observed in Vishwakosh and concept distinguished from equality; subset component verified in textbook. Preserve upstream subsetneq.
- **Alternatives considered:** काटेकोर उपसंच.
- **Exact aligned source/target scopes:**

  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0045 B006, B010: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0047 B024, B028: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T006-OLP-0006-B004`, `T006-OLP-0006-B005`, `T006-OLP-0006-B006`, `T006-OLP-0006-B007`, `T006-OLP-0006-B008`, `T006-OLP-0006-B009`, `T006-OLP-0006-B010`, `T006-OLP-0006-B011`, `T006-OLP-0006-B012`, `T006-OLP-0006-B013`, `T006-OLP-0006-B014`, `T006-OLP-0006-B015`, `T006-OLP-0006-B016`, `T006-OLP-0006-B017`, `T006-OLP-0006-B018`, `T006-OLP-0045-B006`, `T006-OLP-0045-B010`, `T006-OLP-0047-B024`, `T006-OLP-0047-B028`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:160`; `upstream/content/sets-functions-relations/sets/subsets.tex:24`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:157`; `mr/content/sets-functions-relations/sets/subsets.tex:24`.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P011, MR-C004, संचांचे प्रकार, proper-subset paragraph. Do not treat observation hash as source-byte hash or claim full original archived.
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “उचित उपसंच” remain, or should one of “काटेकोर उपसंच” replace it? Does the chosen wording preserve the technical sense of proper subset without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T007 — power set

- **Chosen wording:** घातसंच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-origin-preservation. This choice remains open to correction.
- **Rationale:** Vishwakosh has घात-संच and all-subsets description. Orthography normalized without hyphen. Original raw HTML unavailable; source theorem remains authoritative.
- **Alternatives considered:** शक्तिसंच.
- **Exact aligned source/target scopes:**

  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0033 B006, B021–B022, B025: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B007, B010–B011, B014: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B010–B012, B014–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0039 B006, B015–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B007, B011–B012, B016, B019: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T007-OLP-0006-B004`, `T007-OLP-0006-B005`, `T007-OLP-0006-B006`, `T007-OLP-0006-B007`, `T007-OLP-0006-B008`, `T007-OLP-0006-B009`, `T007-OLP-0006-B010`, `T007-OLP-0006-B011`, `T007-OLP-0006-B012`, `T007-OLP-0006-B013`, `T007-OLP-0006-B014`, `T007-OLP-0006-B015`, `T007-OLP-0006-B016`, `T007-OLP-0006-B017`, `T007-OLP-0006-B018`, `T007-OLP-0010-B004`, `T007-OLP-0010-B005`, `T007-OLP-0010-B006`, `T007-OLP-0010-B007`, `T007-OLP-0010-B008`, `T007-OLP-0010-B009`, `T007-OLP-0010-B010`, `T007-OLP-0010-B011`, `T007-OLP-0010-B012`, `T007-OLP-0010-B013`, `T007-OLP-0010-B014`, `T007-OLP-0033-B006`, `T007-OLP-0033-B021`, `T007-OLP-0033-B022`, `T007-OLP-0033-B025`, `T007-OLP-0034-B007`, `T007-OLP-0034-B010`, `T007-OLP-0034-B011`, `T007-OLP-0034-B014`, `T007-OLP-0036-B010`, `T007-OLP-0036-B011`, `T007-OLP-0036-B012`, `T007-OLP-0036-B014`, `T007-OLP-0036-B015`, `T007-OLP-0036-B016`, `T007-OLP-0036-B017`, `T007-OLP-0036-B018`, `T007-OLP-0039-B006`, `T007-OLP-0039-B015`, `T007-OLP-0039-B016`, `T007-OLP-0040-B007`, `T007-OLP-0040-B011`, `T007-OLP-0040-B012`, `T007-OLP-0040-B016`, `T007-OLP-0040-B019`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/russells-paradox.tex:27`; `upstream/content/sets-functions-relations/sets/subsets.tex:10, 75, 77`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/russells-paradox.tex:25`; `mr/content/sets-functions-relations/sets/subsets.tex:10, 78, 80`.
- **Authorities actually checked:**

  - [MR-C005](https://vishwakosh.marathi.gov.in/32772/) — MR-P012, MR-C005, paragraph beginning आकारिक तर्कशास्त्र आणि गणित, after Grelling discussion. Do not treat observation hash as source-byte hash or claim full original archived.
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “घातसंच” remain, or should one of “शक्तिसंच” replace it? Does the chosen wording preserve the technical sense of power set without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T008 — natural numbers

- **Chosen wording:** नैसर्गिक संख्या
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted-domain-caveat. This choice remains open to correction.
- **Rationale:** Balbharati starts N at 1; OpenLogic starts Nat at 0. Translate the term but preserve OpenLogic convention.
- **Alternatives considered:** मोजणी संख्या; परंतु OpenLogic मधील शून्याचा समावेश स्पष्ट करावा.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0007 B004–B009: [English](../upstream/content/sets-functions-relations/sets/important-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/important-sets.tex)
  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0029 B006, B017, B020, B024–B026, B028, B033–B034: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0030 B006–B012: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B005–B006, B009, B011, B013, B015, B017–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B006–B010: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0033 B008, B012, B015, B018, B021–B026: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B007, B011–B012, B015, B017–B020: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B015, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B010, B014–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0038 B006–B010, B013, B015: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B006–B010, B012, B015–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B007, B011–B014, B017–B022: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0042 B004–B006, B012, B015: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B005: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0044 B007–B009: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0046 B009, B011–B012, B014: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B008, B010: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B008: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T008-OLP-0005-B004`, `T008-OLP-0005-B005`, `T008-OLP-0005-B006`, `T008-OLP-0005-B007`, `T008-OLP-0005-B008`, `T008-OLP-0005-B009`, `T008-OLP-0005-B010`, `T008-OLP-0005-B011`, `T008-OLP-0005-B012`, `T008-OLP-0005-B013`, `T008-OLP-0005-B014`, `T008-OLP-0006-B004`, `T008-OLP-0006-B005`, `T008-OLP-0006-B006`, `T008-OLP-0006-B007`, `T008-OLP-0006-B008`, `T008-OLP-0006-B009`, `T008-OLP-0006-B010`, `T008-OLP-0006-B011`, `T008-OLP-0006-B012`, `T008-OLP-0006-B013`, `T008-OLP-0006-B014`, `T008-OLP-0006-B015`, `T008-OLP-0006-B016`, `T008-OLP-0006-B017`, `T008-OLP-0006-B018`, `T008-OLP-0007-B004`, `T008-OLP-0007-B005`, `T008-OLP-0007-B006`, `T008-OLP-0007-B007`, `T008-OLP-0007-B008`, `T008-OLP-0007-B009`, `T008-OLP-0021-B004`, `T008-OLP-0021-B005`, `T008-OLP-0021-B006`, `T008-OLP-0021-B007`, `T008-OLP-0021-B008`, `T008-OLP-0021-B009`, `T008-OLP-0021-B010`, `T008-OLP-0021-B011`, `T008-OLP-0021-B012`, `T008-OLP-0021-B013`, `T008-OLP-0021-B014`, `T008-OLP-0021-B015`, `T008-OLP-0021-B016`, `T008-OLP-0021-B017`, `T008-OLP-0021-B018`, `T008-OLP-0021-B019`, `T008-OLP-0021-B020`, `T008-OLP-0029-B006`, `T008-OLP-0029-B017`, `T008-OLP-0029-B020`, `T008-OLP-0029-B024`, `T008-OLP-0029-B025`, `T008-OLP-0029-B026`, `T008-OLP-0029-B028`, `T008-OLP-0029-B033`, `T008-OLP-0029-B034`, `T008-OLP-0030-B006`, `T008-OLP-0030-B007`, `T008-OLP-0030-B008`, `T008-OLP-0030-B009`, `T008-OLP-0030-B010`, `T008-OLP-0030-B011`, `T008-OLP-0030-B012`, `T008-OLP-0031-B005`, `T008-OLP-0031-B006`, `T008-OLP-0031-B009`, `T008-OLP-0031-B011`, `T008-OLP-0031-B013`, `T008-OLP-0031-B015`, `T008-OLP-0031-B017`, `T008-OLP-0031-B018`, `T008-OLP-0032-B006`, `T008-OLP-0032-B007`, `T008-OLP-0032-B008`, `T008-OLP-0032-B009`, `T008-OLP-0032-B010`, `T008-OLP-0033-B008`, `T008-OLP-0033-B012`, `T008-OLP-0033-B015`, `T008-OLP-0033-B018`, `T008-OLP-0033-B021`, `T008-OLP-0033-B022`, `T008-OLP-0033-B023`, `T008-OLP-0033-B024`, `T008-OLP-0033-B025`, `T008-OLP-0033-B026`, `T008-OLP-0034-B007`, `T008-OLP-0034-B011`, `T008-OLP-0034-B012`, `T008-OLP-0034-B015`, `T008-OLP-0034-B017`, `T008-OLP-0034-B018`, `T008-OLP-0034-B019`, `T008-OLP-0034-B020`, `T008-OLP-0035-B015`, `T008-OLP-0035-B018`, `T008-OLP-0036-B010`, `T008-OLP-0036-B014`, `T008-OLP-0036-B015`, `T008-OLP-0036-B016`, `T008-OLP-0038-B006`, `T008-OLP-0038-B007`, `T008-OLP-0038-B008`, `T008-OLP-0038-B009`, `T008-OLP-0038-B010`, `T008-OLP-0038-B013`, `T008-OLP-0038-B015`, `T008-OLP-0039-B006`, `T008-OLP-0039-B007`, `T008-OLP-0039-B008`, `T008-OLP-0039-B009`, `T008-OLP-0039-B010`, `T008-OLP-0039-B012`, `T008-OLP-0039-B015`, `T008-OLP-0039-B016`, `T008-OLP-0039-B017`, `T008-OLP-0039-B018`, `T008-OLP-0040-B007`, `T008-OLP-0040-B011`, `T008-OLP-0040-B012`, `T008-OLP-0040-B013`, `T008-OLP-0040-B014`, `T008-OLP-0040-B017`, `T008-OLP-0040-B018`, `T008-OLP-0040-B019`, `T008-OLP-0040-B020`, `T008-OLP-0040-B021`, `T008-OLP-0040-B022`, `T008-OLP-0042-B004`, `T008-OLP-0042-B005`, `T008-OLP-0042-B006`, `T008-OLP-0042-B012`, `T008-OLP-0042-B015`, `T008-OLP-0043-B005`, `T008-OLP-0044-B007`, `T008-OLP-0044-B008`, `T008-OLP-0044-B009`, `T008-OLP-0046-B009`, `T008-OLP-0046-B011`, `T008-OLP-0046-B012`, `T008-OLP-0046-B014`, `T008-OLP-0047-B008`, `T008-OLP-0047-B010`, `T008-OLP-0048-B008`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:35`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:18, 42, 58, 61, 73, 75`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:12`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:31`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:82, 105`; `upstream/content/sets-functions-relations/functions/function-basics.tex:58–59, 66, 95, 104–105`; `upstream/content/sets-functions-relations/sets/important-sets.tex:18`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:41–42, 70, 72, 90`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:121, 188`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:89`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:21, 31`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:91, 102`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:34, 59`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:64–65, 113`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:116`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:80`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/integers.tex:18, 42, 57–58, 60, 71, 74`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:12`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:35, 42, 57, 78, 81, 88, 98`; `mr/content/sets-functions-relations/functions/function-basics.tex:56–57, 63, 65, 71, 92–93, 102–103, 132–133`; `mr/content/sets-functions-relations/sets/important-sets.tex:18, 30, 33, 40`; `mr/content/sets-functions-relations/sets/subsets.tex:29`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:27, 40–41, 68, 70, 88`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:118, 191`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:92`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:21, 31`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:96, 108`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:34, 58, 112`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:60, 66–67, 115, 121`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:121`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:15, 112`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
- **Precise review question:** Does the Marathi wording make OpenLogic's inclusion of zero unmistakable despite the checked school source starting natural numbers at one?

## T009 — formal validity

- **Chosen wording:** वैधता
- **Coverage:** pre-adjudicated; not yet applied in a translated unit.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted-primary-textbook. This choice remains open to correction.
- **Rationale:** Preserved Marathi logic textbook explicitly distinguishes argument वैधता from truth of statements; युक्तता and आकारिक प्रामाण्य recorded as attested alternatives. Adopt वैधता consistently in formal truth-preservation sense, not legal legitimacy; keep soundness separate.
- **Alternatives considered:** युक्तता; आकारिक प्रामाण्य.
- **Exact aligned source/target scopes:** none yet; the term has not been applied in current translated units.
- **Occurrence records:** none yet.
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P019, MR-C011, Decision procedure, sections 1.1–1.2, printed page 1. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P020, MR-C011, Short truth table, section 1.3 continuation and 1.4, printed page 2. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [MR-C002](https://vishwakosh.marathi.gov.in/20027/) — MR-P010, MR-C002, opening definition and first argument-form discussion; truth-value discussion. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** Which Marathi term most clearly names truth-preservation of an argument and cannot be mistaken for the truth of its premises or conclusion?

## T010 — truth / truth value

- **Chosen wording:** सत्यता / सत्यतामूल्य
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted-primary-textbook. This choice remains open to correction.
- **Rationale:** Apply to statements under interpretations; not synonym for validity.
- **Alternatives considered:** सत्य; सत्यमूल्य.
- **Exact aligned source/target scopes:**

  - OLP-0031 B013: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T010-OLP-0031-B013`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:80–81, 83`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/pairing.tex:81, 83`.
- **Authorities actually checked:**

  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P019, MR-C011, Decision procedure, sections 1.1–1.2, printed page 1. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P020, MR-C011, Short truth table, section 1.3 continuation and 1.4, printed page 2. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [MR-C002](https://vishwakosh.marathi.gov.in/20027/) — MR-P010, MR-C002, opening definition and first argument-form discussion; truth-value discussion. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** Are सत्यता and सत्यतामूल्य sufficiently distinct from argument validity in every formal context?

## T011 — syntax

- **Chosen wording:** विन्यासमीमांसा
- **Coverage:** pre-adjudicated; not yet applied in a translated unit.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-concept-extension. This choice remains open to correction.
- **Rationale:** Government logic glossary label observed; compound spacing normalized. OpenLogic formal formation rules define sense. University symbolic-formation topics are supporting context, not full semantic attestation.
- **Alternatives considered:** वाक्यरचना.
- **Exact aligned source/target scopes:** none yet; the term has not been applied in current translated units.
- **Occurrence records:** none yet.
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [MR-C008](https://shabdakosh.marathi.gov.in/ananya-glossary/7/s) — MR-P009, MR-C008, syntax; semantics; satisfaction. Do not treat observation hash as source-byte hash or claim full original archived.
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P006, MR-C006, विधानीय तर्कशास्त्र, topics 1–4, printed page 12. visually-read-page-image
- **Precise review question:** Is विन्यासमीमांसा established enough for formal syntax, or would वाक्यरचना be clearer without narrowing the concept to grammar?

## T012 — semantics

- **Chosen wording:** चिन्हार्थमीमांसा
- **Coverage:** pre-adjudicated; not yet applied in a translated unit.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-concept-extension. This choice remains open to correction.
- **Rationale:** Logical interpretation and truth conditions; distinguish ordinary linguistic meaning. Full model-theoretic prose attestation still unresolved.
- **Alternatives considered:** अर्थमीमांसा.
- **Exact aligned source/target scopes:** none yet; the term has not been applied in current translated units.
- **Occurrence records:** none yet.
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [MR-C008](https://shabdakosh.marathi.gov.in/ananya-glossary/7/s) — MR-P009, MR-C008, syntax; semantics; satisfaction. Do not treat observation hash as source-byte hash or claim full original archived.
  - [MR-C002](https://vishwakosh.marathi.gov.in/20027/) — MR-P010, MR-C002, opening definition and first argument-form discussion; truth-value discussion. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** Is चिन्हार्थमीमांसा suitable for model-theoretic semantics, or does अर्थमीमांसा better avoid an unintended merely lexical sense?

## T013 — model (model theory)

- **Chosen wording:** प्रतिमान
- **Coverage:** pre-adjudicated; not yet applied in a translated unit.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** No verified Marathi model-theory passage yet. Evidence role of P009 only semantic context; it does not attest प्रतिमान. Candidate chosen for mathematical structure satisfying a theory, to be defined from OpenLogic and revisited before first use.
- **Alternatives considered:** प्रारूप; मॉडेल.
- **Exact aligned source/target scopes:** none yet; the term has not been applied in current translated units.
- **Occurrence records:** none yet.
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [MR-C008](https://shabdakosh.marathi.gov.in/ananya-glossary/7/s) — MR-P009, MR-C008, syntax; semantics; satisfaction. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** For a structure satisfying a theory, should प्रतिमान, प्रारूप or मॉडेल be preferred in current Marathi logic scholarship?

## T014 — perfect number

- **Chosen wording:** परिपूर्ण संख्या
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** No specialized Marathi attestation verified yet. Compositional label with explicit source definition using proper divisors; textbook evidence supports native number grammar, not this technical name.
- **Alternatives considered:** पूर्ण संख्या.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0007 B004–B009: [English](../upstream/content/sets-functions-relations/sets/important-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/important-sets.tex)
- **Occurrence records:** `T014-OLP-0005-B004`, `T014-OLP-0005-B005`, `T014-OLP-0005-B006`, `T014-OLP-0005-B007`, `T014-OLP-0005-B008`, `T014-OLP-0005-B009`, `T014-OLP-0005-B010`, `T014-OLP-0005-B011`, `T014-OLP-0005-B012`, `T014-OLP-0005-B013`, `T014-OLP-0005-B014`, `T014-OLP-0007-B004`, `T014-OLP-0007-B005`, `T014-OLP-0007-B006`, `T014-OLP-0007-B007`, `T014-OLP-0007-B008`, `T014-OLP-0007-B009`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/basics.tex:74, 76, 79, 81`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P004, MR-C001, समान संच, opening criterion and examples, printed page 6. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “परिपूर्ण संख्या” remain, or should one of “पूर्ण संख्या” replace it? Does the chosen wording preserve the technical sense of perfect number without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T015 — proof

- **Chosen wording:** सिद्धता
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** University curricular usage distinguishes proof/inference and quantification.
- **Alternatives considered:** पुरावा.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0033 B020: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B010: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0044 B006–B010: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B008, B010: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B009: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B008, B010, B012: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B013, B016–B017, B022–B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T015-OLP-0005-B004`, `T015-OLP-0005-B005`, `T015-OLP-0005-B006`, `T015-OLP-0005-B007`, `T015-OLP-0005-B008`, `T015-OLP-0005-B009`, `T015-OLP-0005-B010`, `T015-OLP-0005-B011`, `T015-OLP-0005-B012`, `T015-OLP-0005-B013`, `T015-OLP-0005-B014`, `T015-OLP-0006-B004`, `T015-OLP-0006-B005`, `T015-OLP-0006-B006`, `T015-OLP-0006-B007`, `T015-OLP-0006-B008`, `T015-OLP-0006-B009`, `T015-OLP-0006-B010`, `T015-OLP-0006-B011`, `T015-OLP-0006-B012`, `T015-OLP-0006-B013`, `T015-OLP-0006-B014`, `T015-OLP-0006-B015`, `T015-OLP-0006-B016`, `T015-OLP-0006-B017`, `T015-OLP-0006-B018`, `T015-OLP-0033-B020`, `T015-OLP-0034-B010`, `T015-OLP-0036-B017`, `T015-OLP-0044-B006`, `T015-OLP-0044-B007`, `T015-OLP-0044-B008`, `T015-OLP-0044-B009`, `T015-OLP-0044-B010`, `T015-OLP-0045-B008`, `T015-OLP-0045-B010`, `T015-OLP-0046-B009`, `T015-OLP-0047-B008`, `T015-OLP-0047-B010`, `T015-OLP-0047-B012`, `T015-OLP-0048-B013`, `T015-OLP-0048-B016`, `T015-OLP-0048-B017`, `T015-OLP-0048-B022`, `T015-OLP-0048-B023`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:165, 167, 174, 181, 227`; `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:43, 60, 64, 72, 74, 76, 90, 156, 158, 168, 182, 184, 205`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:52, 58, 78`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:29, 33, 37, 70, 72`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:44`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:60, 66–67, 105, 109, 127, 137`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:51, 137, 140, 152, 177, 180`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:21, 47, 83`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:142, 174`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:75, 153, 180`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:51, 119`; `mr/content/sets-functions-relations/arithmetization/reals.tex:34, 38, 75`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:66–67, 114–115, 134–135`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:137`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:22, 45, 48`.
- **Authorities actually checked:**

  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P006, MR-C006, विधानीय तर्कशास्त्र, topics 1–4, printed page 12. visually-read-page-image
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P007, MR-C006, विधेय / संख्यापनीय तर्कशास्त्र आणि संच उपपत्ती, topics 1 and 4, printed page 14. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “सिद्धता” remain, or should one of “पुरावा” replace it? Does the chosen wording preserve the technical sense of proof without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T016 — if and only if

- **Chosen wording:** तेव्हा आणि केवळ तेव्हाच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted-compositional. This choice remains open to correction.
- **Rationale:** Both implications explicitly preserved; source formulas govern biconditional strength.
- **Alternatives considered:** जर आणि तर; स्वतंत्रपणे घेतल्यास द्विशर्त अस्पष्ट होऊ शकते.
- **Exact aligned source/target scopes:**

  - OLP-0005 B004–B014: [English](../upstream/content/sets-functions-relations/sets/basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/basics.tex)
  - OLP-0006 B004–B018: [English](../upstream/content/sets-functions-relations/sets/subsets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/subsets.tex)
  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0029 B016, B025, B028, B033–B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0031 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0033 B018, B022–B023: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B011–B012: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B013, B015, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B007, B009–B010, B014–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0045 B006: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T016-OLP-0005-B004`, `T016-OLP-0005-B005`, `T016-OLP-0005-B006`, `T016-OLP-0005-B007`, `T016-OLP-0005-B008`, `T016-OLP-0005-B009`, `T016-OLP-0005-B010`, `T016-OLP-0005-B011`, `T016-OLP-0005-B012`, `T016-OLP-0005-B013`, `T016-OLP-0005-B014`, `T016-OLP-0006-B004`, `T016-OLP-0006-B005`, `T016-OLP-0006-B006`, `T016-OLP-0006-B007`, `T016-OLP-0006-B008`, `T016-OLP-0006-B009`, `T016-OLP-0006-B010`, `T016-OLP-0006-B011`, `T016-OLP-0006-B012`, `T016-OLP-0006-B013`, `T016-OLP-0006-B014`, `T016-OLP-0006-B015`, `T016-OLP-0006-B016`, `T016-OLP-0006-B017`, `T016-OLP-0006-B018`, `T016-OLP-0021-B004`, `T016-OLP-0021-B005`, `T016-OLP-0021-B006`, `T016-OLP-0021-B007`, `T016-OLP-0021-B008`, `T016-OLP-0021-B009`, `T016-OLP-0021-B010`, `T016-OLP-0021-B011`, `T016-OLP-0021-B012`, `T016-OLP-0021-B013`, `T016-OLP-0021-B014`, `T016-OLP-0021-B015`, `T016-OLP-0021-B016`, `T016-OLP-0021-B017`, `T016-OLP-0021-B018`, `T016-OLP-0021-B019`, `T016-OLP-0021-B020`, `T016-OLP-0029-B016`, `T016-OLP-0029-B025`, `T016-OLP-0029-B028`, `T016-OLP-0029-B033`, `T016-OLP-0029-B034`, `T016-OLP-0029-B035`, `T016-OLP-0031-B015`, `T016-OLP-0033-B018`, `T016-OLP-0033-B022`, `T016-OLP-0033-B023`, `T016-OLP-0034-B011`, `T016-OLP-0034-B012`, `T016-OLP-0035-B013`, `T016-OLP-0035-B015`, `T016-OLP-0035-B017`, `T016-OLP-0036-B007`, `T016-OLP-0036-B009`, `T016-OLP-0036-B010`, `T016-OLP-0036-B014`, `T016-OLP-0036-B015`, `T016-OLP-0036-B016`, `T016-OLP-0045-B006`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:44`; `mr/content/sets-functions-relations/sets/basics.tex:26`; `mr/content/sets-functions-relations/sets/subsets.tex:43, 48, 50, 54, 71`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:28, 38, 47, 106, 120, 126`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:112, 212, 262, 269, 271, 275, 283, 286, 289`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:30`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:115, 156, 167, 169`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:94`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P004, MR-C001, समान संच, opening criterion and examples, printed page 6. visually-read-page-image
  - [MR-C002](https://vishwakosh.marathi.gov.in/20027/) — MR-P010, MR-C002, opening definition and first argument-form discussion; truth-value discussion. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** In the listed formal contexts, should “तेव्हा आणि केवळ तेव्हाच” remain, or should one of “जर आणि तर; स्वतंत्रपणे घेतल्यास द्विशर्त अस्पष्ट होऊ शकते” replace it? Does the chosen wording preserve the technical sense of if and only if without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T017 — union

- **Chosen wording:** संयोग
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Balbharati संयोग selected over syllabus युती; use consistently for binary and indexed operation.
- **Alternatives considered:** संघ; युती.
- **Exact aligned source/target scopes:**

  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0029 B021, B023: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0031 B016: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0035 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0038 B018–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0045 B010: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T017-OLP-0008-B004`, `T017-OLP-0008-B005`, `T017-OLP-0008-B006`, `T017-OLP-0008-B007`, `T017-OLP-0008-B008`, `T017-OLP-0008-B009`, `T017-OLP-0008-B010`, `T017-OLP-0008-B011`, `T017-OLP-0008-B012`, `T017-OLP-0008-B013`, `T017-OLP-0008-B014`, `T017-OLP-0008-B015`, `T017-OLP-0008-B016`, `T017-OLP-0008-B017`, `T017-OLP-0008-B018`, `T017-OLP-0008-B019`, `T017-OLP-0008-B020`, `T017-OLP-0008-B021`, `T017-OLP-0008-B022`, `T017-OLP-0008-B023`, `T017-OLP-0008-B024`, `T017-OLP-0008-B025`, `T017-OLP-0008-B026`, `T017-OLP-0008-B027`, `T017-OLP-0008-B028`, `T017-OLP-0008-B029`, `T017-OLP-0019-B004`, `T017-OLP-0019-B005`, `T017-OLP-0019-B006`, `T017-OLP-0019-B007`, `T017-OLP-0019-B008`, `T017-OLP-0019-B009`, `T017-OLP-0019-B010`, `T017-OLP-0019-B011`, `T017-OLP-0019-B012`, `T017-OLP-0019-B013`, `T017-OLP-0019-B014`, `T017-OLP-0019-B015`, `T017-OLP-0019-B016`, `T017-OLP-0019-B017`, `T017-OLP-0019-B018`, `T017-OLP-0019-B019`, `T017-OLP-0019-B020`, `T017-OLP-0029-B021`, `T017-OLP-0029-B023`, `T017-OLP-0031-B016`, `T017-OLP-0035-B017`, `T017-OLP-0038-B018`, `T017-OLP-0038-B019`, `T017-OLP-0045-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/operations.tex:13–14`; `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:3, 10, 20, 24–25, 27, 34–35, 43, 47, 50, 59, 100, 102–103`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:100, 102`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/operations.tex:14–15`; `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:10, 25, 34–35, 44, 47, 51, 61, 103, 105, 107`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:101, 103`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P016, MR-C001, दोन संचांचा संयोग, definition and examples, printed page 13. visually-read-page-image
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P007, MR-C006, विधेय / संख्यापनीय तर्कशास्त्र आणि संच उपपत्ती, topics 1 and 4, printed page 14. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “संयोग” remain, or should one of “संघ / युती” replace it? Does the chosen wording preserve the technical sense of union without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T018 — intersection

- **Chosen wording:** छेद
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Shared-element set; छेदसंच when noun requires explicit set.
- **Alternatives considered:** संगम.
- **Exact aligned source/target scopes:**

  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0035 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
- **Occurrence records:** `T018-OLP-0008-B004`, `T018-OLP-0008-B005`, `T018-OLP-0008-B006`, `T018-OLP-0008-B007`, `T018-OLP-0008-B008`, `T018-OLP-0008-B009`, `T018-OLP-0008-B010`, `T018-OLP-0008-B011`, `T018-OLP-0008-B012`, `T018-OLP-0008-B013`, `T018-OLP-0008-B014`, `T018-OLP-0008-B015`, `T018-OLP-0008-B016`, `T018-OLP-0008-B017`, `T018-OLP-0008-B018`, `T018-OLP-0008-B019`, `T018-OLP-0008-B020`, `T018-OLP-0008-B021`, `T018-OLP-0008-B022`, `T018-OLP-0008-B023`, `T018-OLP-0008-B024`, `T018-OLP-0008-B025`, `T018-OLP-0008-B026`, `T018-OLP-0008-B027`, `T018-OLP-0008-B028`, `T018-OLP-0008-B029`, `T018-OLP-0019-B004`, `T018-OLP-0019-B005`, `T018-OLP-0019-B006`, `T018-OLP-0019-B007`, `T018-OLP-0019-B008`, `T018-OLP-0019-B009`, `T018-OLP-0019-B010`, `T018-OLP-0019-B011`, `T018-OLP-0019-B012`, `T018-OLP-0019-B013`, `T018-OLP-0019-B014`, `T018-OLP-0019-B015`, `T018-OLP-0019-B016`, `T018-OLP-0019-B017`, `T018-OLP-0019-B018`, `T018-OLP-0019-B019`, `T018-OLP-0019-B020`, `T018-OLP-0035-B017`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:3, 10, 62, 64–65, 67, 71–72, 77, 82, 85, 88, 91, 100, 103, 105`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:10, 64, 67, 73–74, 79, 84, 87, 90, 93, 103, 105, 109`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P014, MR-C001, संचांवरील क्रिया, intersection definition, printed page 11. visually-read-page-image
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P007, MR-C006, विधेय / संख्यापनीय तर्कशास्त्र आणि संच उपपत्ती, topics 1 and 4, printed page 14. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “छेद” remain, or should one of “संगम” replace it? Does the chosen wording preserve the technical sense of intersection without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T019 — disjoint

- **Chosen wording:** विभक्त
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Prefer विभक्त over various/different implication of विभिन्न; no common elements.
- **Alternatives considered:** विसंयुक्त.
- **Exact aligned source/target scopes:**

  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
- **Occurrence records:** `T019-OLP-0008-B004`, `T019-OLP-0008-B005`, `T019-OLP-0008-B006`, `T019-OLP-0008-B007`, `T019-OLP-0008-B008`, `T019-OLP-0008-B009`, `T019-OLP-0008-B010`, `T019-OLP-0008-B011`, `T019-OLP-0008-B012`, `T019-OLP-0008-B013`, `T019-OLP-0008-B014`, `T019-OLP-0008-B015`, `T019-OLP-0008-B016`, `T019-OLP-0008-B017`, `T019-OLP-0008-B018`, `T019-OLP-0008-B019`, `T019-OLP-0008-B020`, `T019-OLP-0008-B021`, `T019-OLP-0008-B022`, `T019-OLP-0008-B023`, `T019-OLP-0008-B024`, `T019-OLP-0008-B025`, `T019-OLP-0008-B026`, `T019-OLP-0008-B027`, `T019-OLP-0008-B028`, `T019-OLP-0008-B029`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:77`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:79`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P015, MR-C001, विभिन्न संच, definition and figures, printed page 12. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “विभक्त” remain, or should one of “विसंयुक्त” replace it? Does the chosen wording preserve the technical sense of disjoint without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T020 — ordered pair

- **Chosen wording:** क्रमित जोडी
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted. This choice remains open to correction.
- **Rationale:** Actual numeric-order example supports native usage; upstream Wiener–Kuratowski encoding preserved.
- **Alternatives considered:** सुव्यवस्थित जोडी.
- **Exact aligned source/target scopes:**

  - OLP-0009 B004–B019: [English](../upstream/content/sets-functions-relations/sets/pairs-and-products.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/pairs-and-products.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0030 B006, B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B005–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B006–B008: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0034 B016: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0042 B005–B007, B012, B014: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B005–B006: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0046 B009–B010: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B010: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T020-OLP-0009-B004`, `T020-OLP-0009-B005`, `T020-OLP-0009-B006`, `T020-OLP-0009-B007`, `T020-OLP-0009-B008`, `T020-OLP-0009-B009`, `T020-OLP-0009-B010`, `T020-OLP-0009-B011`, `T020-OLP-0009-B012`, `T020-OLP-0009-B013`, `T020-OLP-0009-B014`, `T020-OLP-0009-B015`, `T020-OLP-0009-B016`, `T020-OLP-0009-B017`, `T020-OLP-0009-B018`, `T020-OLP-0009-B019`, `T020-OLP-0012-B004`, `T020-OLP-0012-B005`, `T020-OLP-0012-B006`, `T020-OLP-0012-B007`, `T020-OLP-0012-B008`, `T020-OLP-0012-B009`, `T020-OLP-0012-B010`, `T020-OLP-0012-B011`, `T020-OLP-0012-B012`, `T020-OLP-0019-B004`, `T020-OLP-0019-B005`, `T020-OLP-0019-B006`, `T020-OLP-0019-B007`, `T020-OLP-0019-B008`, `T020-OLP-0019-B009`, `T020-OLP-0019-B010`, `T020-OLP-0019-B011`, `T020-OLP-0019-B012`, `T020-OLP-0019-B013`, `T020-OLP-0019-B014`, `T020-OLP-0019-B015`, `T020-OLP-0019-B016`, `T020-OLP-0019-B017`, `T020-OLP-0019-B018`, `T020-OLP-0019-B019`, `T020-OLP-0019-B020`, `T020-OLP-0023-B005`, `T020-OLP-0023-B006`, `T020-OLP-0023-B007`, `T020-OLP-0023-B008`, `T020-OLP-0023-B009`, `T020-OLP-0023-B010`, `T020-OLP-0023-B011`, `T020-OLP-0023-B012`, `T020-OLP-0023-B013`, `T020-OLP-0023-B014`, `T020-OLP-0023-B015`, `T020-OLP-0023-B016`, `T020-OLP-0030-B006`, `T020-OLP-0030-B008`, `T020-OLP-0030-B009`, `T020-OLP-0031-B005`, `T020-OLP-0031-B006`, `T020-OLP-0031-B007`, `T020-OLP-0031-B008`, `T020-OLP-0031-B009`, `T020-OLP-0032-B006`, `T020-OLP-0032-B007`, `T020-OLP-0032-B008`, `T020-OLP-0034-B016`, `T020-OLP-0042-B005`, `T020-OLP-0042-B006`, `T020-OLP-0042-B007`, `T020-OLP-0042-B012`, `T020-OLP-0042-B014`, `T020-OLP-0043-B005`, `T020-OLP-0043-B006`, `T020-OLP-0046-B009`, `T020-OLP-0046-B010`, `T020-OLP-0047-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/integers.tex:16, 18, 24, 42`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:20, 23`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:39–40, 48, 70, 72`; `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:24, 27, 31`; `upstream/content/sets-functions-relations/sets/pairs-and-products.tex:15–16, 19–20, 25, 29, 39, 43–44, 49`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:21, 37`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/integers.tex:16`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:19`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:68`; `mr/content/sets-functions-relations/relations/relations-as-sets.tex:23`; `mr/content/sets-functions-relations/sets/pairs-and-products.tex:15–16, 29, 40, 44`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:37`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “क्रमित जोडी” remain, or should one of “सुव्यवस्थित जोडी” replace it? Does the chosen wording preserve the technical sense of ordered pair without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T021 — Cartesian product

- **Chosen wording:** कार्तीय गुणाकार
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** adopted-observation-backed. This choice remains open to correction.
- **Rationale:** Named concept and six-pair example in official encyclopedia; origin hash pending.
- **Alternatives considered:** कार्तेशियन गुणाकार.
- **Exact aligned source/target scopes:**

  - OLP-0009 B004–B019: [English](../upstream/content/sets-functions-relations/sets/pairs-and-products.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/pairs-and-products.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0030 B006, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T021-OLP-0009-B004`, `T021-OLP-0009-B005`, `T021-OLP-0009-B006`, `T021-OLP-0009-B007`, `T021-OLP-0009-B008`, `T021-OLP-0009-B009`, `T021-OLP-0009-B010`, `T021-OLP-0009-B011`, `T021-OLP-0009-B012`, `T021-OLP-0009-B013`, `T021-OLP-0009-B014`, `T021-OLP-0009-B015`, `T021-OLP-0009-B016`, `T021-OLP-0009-B017`, `T021-OLP-0009-B018`, `T021-OLP-0009-B019`, `T021-OLP-0012-B004`, `T021-OLP-0012-B005`, `T021-OLP-0012-B006`, `T021-OLP-0012-B007`, `T021-OLP-0012-B008`, `T021-OLP-0012-B009`, `T021-OLP-0012-B010`, `T021-OLP-0012-B011`, `T021-OLP-0012-B012`, `T021-OLP-0030-B006`, `T021-OLP-0030-B009`, `T021-OLP-0031-B017`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/pairs-and-products.tex:10, 52–53`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/relations-as-sets.tex:27`; `mr/content/sets-functions-relations/sets/pairs-and-products.tex:10, 53–54`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:87`.
- **Authorities actually checked:**

  - [MR-C010](https://marathivishwakosh.org/21954/) — MR-P018, MR-C010, कार्तीय गुणाकार (Cartesian product), web lines 74–82. primary article tool text read and exact response preserved; displayed formula omissions preclude using extracted formula as authority
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “कार्तीय गुणाकार” remain, or should one of “कार्तेशियन गुणाकार” replace it? Does the chosen wording preserve the technical sense of Cartesian product without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T022 — tuple

- **Chosen wording:** क्रमित घटकसमूह
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Descriptive extension from verified ordered-pair usage. n-tuple is क्रमित n-घटकसमूह, never बहुपद (polynomial). No specialized tuple attestation claimed.
- **Alternatives considered:** n-घटक क्रम; बहुपद — नाकारले; polynomial असा चुकीचा अर्थ होतो.
- **Exact aligned source/target scopes:**

  - OLP-0009 B004–B019: [English](../upstream/content/sets-functions-relations/sets/pairs-and-products.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/pairs-and-products.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0030 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B018: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T022-OLP-0009-B004`, `T022-OLP-0009-B005`, `T022-OLP-0009-B006`, `T022-OLP-0009-B007`, `T022-OLP-0009-B008`, `T022-OLP-0009-B009`, `T022-OLP-0009-B010`, `T022-OLP-0009-B011`, `T022-OLP-0009-B012`, `T022-OLP-0009-B013`, `T022-OLP-0009-B014`, `T022-OLP-0009-B015`, `T022-OLP-0009-B016`, `T022-OLP-0009-B017`, `T022-OLP-0009-B018`, `T022-OLP-0009-B019`, `T022-OLP-0023-B005`, `T022-OLP-0023-B006`, `T022-OLP-0023-B007`, `T022-OLP-0023-B008`, `T022-OLP-0023-B009`, `T022-OLP-0023-B010`, `T022-OLP-0023-B011`, `T022-OLP-0023-B012`, `T022-OLP-0023-B013`, `T022-OLP-0023-B014`, `T022-OLP-0023-B015`, `T022-OLP-0023-B016`, `T022-OLP-0030-B009`, `T022-OLP-0031-B018`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/functions-relations.tex:28, 46, 68, 84`; `upstream/content/sets-functions-relations/sets/pairs-and-products.tex:10, 15, 17, 23, 30, 34–35, 41–42, 44–47, 49, 56, 63–64, 70–71, 90–92, 99–100, 102, 117, 119`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:16, 21–24, 26, 40, 44, 55`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:19, 26, 28, 30, 32, 38, 62–63, 74, 82, 88, 98, 100, 102, 104`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/functions-relations.tex:66`; `mr/content/sets-functions-relations/sets/pairs-and-products.tex:10`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
- **Precise review question:** Is क्रमित घटकसमूह natural for an n-tuple, and is there an attested alternative that cannot be confused with a polynomial?

## T023 — sequence/string/word

- **Chosen wording:** अनुक्रम / चिन्हमाला / शब्द
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Define from source finite ordered symbols; शब्द formal combinatorial sense distinct from ordinary-language word.
- **Alternatives considered:** मालिका; स्ट्रिंग.
- **Exact aligned source/target scopes:**

  - OLP-0009 B004–B019: [English](../upstream/content/sets-functions-relations/sets/pairs-and-products.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/pairs-and-products.tex)
  - OLP-0030 B012: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B012: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0033 B010–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B007, B011–B015, B017–B020: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B015–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0039 B010, B012, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B012–B015, B017–B018, B020–B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0048 B008, B010: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T023-OLP-0009-B004`, `T023-OLP-0009-B005`, `T023-OLP-0009-B006`, `T023-OLP-0009-B007`, `T023-OLP-0009-B008`, `T023-OLP-0009-B009`, `T023-OLP-0009-B010`, `T023-OLP-0009-B011`, `T023-OLP-0009-B012`, `T023-OLP-0009-B013`, `T023-OLP-0009-B014`, `T023-OLP-0009-B015`, `T023-OLP-0009-B016`, `T023-OLP-0009-B017`, `T023-OLP-0009-B018`, `T023-OLP-0009-B019`, `T023-OLP-0030-B012`, `T023-OLP-0031-B012`, `T023-OLP-0033-B010`, `T023-OLP-0033-B011`, `T023-OLP-0033-B012`, `T023-OLP-0033-B013`, `T023-OLP-0033-B014`, `T023-OLP-0033-B015`, `T023-OLP-0033-B016`, `T023-OLP-0033-B017`, `T023-OLP-0033-B018`, `T023-OLP-0033-B019`, `T023-OLP-0034-B007`, `T023-OLP-0034-B011`, `T023-OLP-0034-B012`, `T023-OLP-0034-B013`, `T023-OLP-0034-B014`, `T023-OLP-0034-B015`, `T023-OLP-0034-B017`, `T023-OLP-0034-B018`, `T023-OLP-0034-B019`, `T023-OLP-0034-B020`, `T023-OLP-0036-B015`, `T023-OLP-0036-B016`, `T023-OLP-0039-B010`, `T023-OLP-0039-B012`, `T023-OLP-0039-B018`, `T023-OLP-0040-B012`, `T023-OLP-0040-B013`, `T023-OLP-0040-B014`, `T023-OLP-0040-B015`, `T023-OLP-0040-B017`, `T023-OLP-0040-B018`, `T023-OLP-0040-B020`, `T023-OLP-0040-B021`, `T023-OLP-0048-B008`, `T023-OLP-0048-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:11, 15, 41, 48, 56, 58, 60, 70, 72–73, 84, 92, 98, 100–101, 103, 107, 110, 124, 129, 146, 162, 170, 177, 182, 210, 219, 226`; `upstream/content/sets-functions-relations/sets/pairs-and-products.tex:40, 116–117, 119–120, 122–123`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:90`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:44, 49, 64–65, 77, 92`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:44, 55–57, 62, 74, 76, 78, 80, 83–84, 104–105, 110, 113, 118, 129–131, 134–135`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:60, 81`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:53, 59, 63, 65, 93–94, 119`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:22, 52, 56, 60, 62, 90–91, 115`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/pairs-and-products.tex:42, 119–122, 124–127`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:94`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:44, 48, 62, 77, 94`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:42, 53–54, 59, 71–73, 77, 79–80, 100–102, 106, 109, 114, 126–128, 131–132`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:81, 95`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:54, 56, 65, 94–95, 121`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:21, 53, 57, 60, 62–63, 92–93, 104, 106, 121`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “अनुक्रम / चिन्हमाला / शब्द” remain, or should one of “मालिका / स्ट्रिंग” replace it? Does the chosen wording preserve the technical sense of sequence/string/word without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T024 — set difference

- **Chosen wording:** संचांचा फरक
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-compositional. This choice remains open to correction.
- **Rationale:** Source defines A members not in B; no subtraction of cardinalities.
- **Alternatives considered:** संचवजाबाकी.
- **Exact aligned source/target scopes:**

  - OLP-0008 B004–B029: [English](../upstream/content/sets-functions-relations/sets/unions-and-intersections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/unions-and-intersections.tex)
  - OLP-0045 B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T024-OLP-0008-B004`, `T024-OLP-0008-B005`, `T024-OLP-0008-B006`, `T024-OLP-0008-B007`, `T024-OLP-0008-B008`, `T024-OLP-0008-B009`, `T024-OLP-0008-B010`, `T024-OLP-0008-B011`, `T024-OLP-0008-B012`, `T024-OLP-0008-B013`, `T024-OLP-0008-B014`, `T024-OLP-0008-B015`, `T024-OLP-0008-B016`, `T024-OLP-0008-B017`, `T024-OLP-0008-B018`, `T024-OLP-0008-B019`, `T024-OLP-0008-B020`, `T024-OLP-0008-B021`, `T024-OLP-0008-B022`, `T024-OLP-0008-B023`, `T024-OLP-0008-B024`, `T024-OLP-0008-B025`, `T024-OLP-0008-B026`, `T024-OLP-0008-B027`, `T024-OLP-0008-B028`, `T024-OLP-0008-B029`, `T024-OLP-0045-B012`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/unions-and-intersections.tex:163`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/unions-and-intersections.tex:160, 166`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P014, MR-C001, संचांवरील क्रिया, intersection definition, printed page 11. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “संचांचा फरक” remain, or should one of “संचवजाबाकी” replace it? Does the chosen wording preserve the technical sense of set difference without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T025 — comprehension

- **Chosen wording:** गुणधर्माधारित संचरचना
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-compositional. This choice remains open to correction.
- **Rationale:** Explicitly denotes forming sets by predicates; not ordinary understanding.
- **Alternatives considered:** संचग्रहण.
- **Exact aligned source/target scopes:**

  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0033 B022: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0036 B014, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
- **Occurrence records:** `T025-OLP-0010-B004`, `T025-OLP-0010-B005`, `T025-OLP-0010-B006`, `T025-OLP-0010-B007`, `T025-OLP-0010-B008`, `T025-OLP-0010-B009`, `T025-OLP-0010-B010`, `T025-OLP-0010-B011`, `T025-OLP-0010-B012`, `T025-OLP-0010-B013`, `T025-OLP-0010-B014`, `T025-OLP-0033-B022`, `T025-OLP-0036-B014`, `T025-OLP-0036-B018`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/russells-paradox.tex:22`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/sets/russells-paradox.tex:20`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P002, MR-C001, संच लिहिण्याच्या पद्धती, listing and property methods, printed page 2. visually-read-page-image
  - [MR-C005](https://vishwakosh.marathi.gov.in/32772/) — MR-P012, MR-C005, paragraph beginning आकारिक तर्कशास्त्र आणि गणित, after Grelling discussion. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** In the listed formal contexts, should “गुणधर्माधारित संचरचना” remain, or should one of “संचग्रहण” replace it? Does the chosen wording preserve the technical sense of comprehension without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T026 — contradiction/paradox

- **Chosen wording:** व्याघात / विरोधापत्ती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-origin-preservation. This choice remains open to correction.
- **Rationale:** Keep incompatible assertions distinct from paradox construction.
- **Alternatives considered:** विरोधाभास.
- **Exact aligned source/target scopes:**

  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0033 B012, B018–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B007, B014: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B014–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0048 B022: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T026-OLP-0010-B004`, `T026-OLP-0010-B005`, `T026-OLP-0010-B006`, `T026-OLP-0010-B007`, `T026-OLP-0010-B008`, `T026-OLP-0010-B009`, `T026-OLP-0010-B010`, `T026-OLP-0010-B011`, `T026-OLP-0010-B012`, `T026-OLP-0010-B013`, `T026-OLP-0010-B014`, `T026-OLP-0033-B012`, `T026-OLP-0033-B018`, `T026-OLP-0033-B019`, `T026-OLP-0034-B007`, `T026-OLP-0034-B014`, `T026-OLP-0036-B014`, `T026-OLP-0036-B015`, `T026-OLP-0036-B016`, `T026-OLP-0036-B017`, `T026-OLP-0036-B018`, `T026-OLP-0048-B022`
- **Literal English line hits:** `upstream/content/sets-functions-relations/sets/russells-paradox.tex:3, 11, 24–25, 36, 45, 51, 62, 64–65, 74, 85`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:104, 137–139, 147`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:52, 136`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:219, 227`; `mr/content/sets-functions-relations/sets/russells-paradox.tex:11, 22–23, 34, 42, 48, 60, 62–63, 72, 82`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:95–96, 108, 146, 148, 157`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:50, 132`.
- **Authorities actually checked:**

  - [MR-C005](https://vishwakosh.marathi.gov.in/32772/) — MR-P012, MR-C005, paragraph beginning आकारिक तर्कशास्त्र आणि गणित, after Grelling discussion. Do not treat observation hash as source-byte hash or claim full original archived.
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P006, MR-C006, विधानीय तर्कशास्त्र, topics 1–4, printed page 12. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “व्याघात / विरोधापत्ती” remain, or should one of “विरोधाभास” replace it? Does the chosen wording preserve the technical sense of contradiction/paradox without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T027 — mathematical induction

- **Chosen wording:** गणिती विगमन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Qualifier and source proof task distinguish mathematical induction from empirical inductive inference. Specific term requires further attestation.
- **Alternatives considered:** गणितीय आगमन; इंडक्शन.
- **Exact aligned source/target scopes:**

  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0029 B023: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0038 B019: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
- **Occurrence records:** `T027-OLP-0010-B004`, `T027-OLP-0010-B005`, `T027-OLP-0010-B006`, `T027-OLP-0010-B007`, `T027-OLP-0010-B008`, `T027-OLP-0010-B009`, `T027-OLP-0010-B010`, `T027-OLP-0010-B011`, `T027-OLP-0010-B012`, `T027-OLP-0010-B013`, `T027-OLP-0010-B014`, `T027-OLP-0029-B023`, `T027-OLP-0038-B019`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:130`.
- **Authorities actually checked:**

  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P006, MR-C006, विधानीय तर्कशास्त्र, topics 1–4, printed page 12. visually-read-page-image
- **Precise review question:** Does गणिती विगमन unambiguously mean mathematical induction rather than empirical induction?

## T028 — continuum

- **Chosen wording:** सांतत्य
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Name for real-number continuum in source; not continuity property. Not attested by numeric-set page.
- **Alternatives considered:** सातत्यक.
- **Exact aligned source/target scopes:**

  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0044 B011, B013: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B011: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T028-OLP-0010-B004`, `T028-OLP-0010-B005`, `T028-OLP-0010-B006`, `T028-OLP-0010-B007`, `T028-OLP-0010-B008`, `T028-OLP-0010-B009`, `T028-OLP-0010-B010`, `T028-OLP-0010-B011`, `T028-OLP-0010-B012`, `T028-OLP-0010-B013`, `T028-OLP-0010-B014`, `T028-OLP-0044-B011`, `T028-OLP-0044-B013`, `T028-OLP-0045-B011`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/reals.tex:82`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/reals.tex:98, 100`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “सांतत्य” remain, or should one of “सातत्यक” replace it? Does the chosen wording preserve the technical sense of continuum without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T029 — axiom

- **Chosen wording:** स्वयंसिद्धक
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Explicit postulates of set theory; not claim of self-evidence or factual certainty.
- **Alternatives considered:** स्वयंसिद्ध.
- **Exact aligned source/target scopes:**

  - OLP-0010 B004–B014: [English](../upstream/content/sets-functions-relations/sets/russells-paradox.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/russells-paradox.tex)
  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
- **Occurrence records:** `T029-OLP-0010-B004`, `T029-OLP-0010-B005`, `T029-OLP-0010-B006`, `T029-OLP-0010-B007`, `T029-OLP-0010-B008`, `T029-OLP-0010-B009`, `T029-OLP-0010-B010`, `T029-OLP-0010-B011`, `T029-OLP-0010-B012`, `T029-OLP-0010-B013`, `T029-OLP-0010-B014`, `T029-OLP-0024-B004`, `T029-OLP-0024-B005`, `T029-OLP-0024-B006`, `T029-OLP-0024-B007`, `T029-OLP-0024-B008`, `T029-OLP-0024-B009`, `T029-OLP-0024-B010`, `T029-OLP-0024-B011`, `T029-OLP-0024-B012`, `T029-OLP-0024-B013`, `T029-OLP-0024-B014`, `T029-OLP-0024-B015`, `T029-OLP-0024-B016`, `T029-OLP-0024-B017`, `T029-OLP-0024-B018`, `T029-OLP-0024-B019`, `T029-OLP-0024-B020`, `T029-OLP-0024-B021`, `T029-OLP-0024-B022`, `T029-OLP-0024-B023`, `T029-OLP-0024-B024`, `T029-OLP-0024-B025`, `T029-OLP-0024-B026`, `T029-OLP-0024-B027`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/inverses.tex:106–107, 110`; `upstream/content/sets-functions-relations/sets/russells-paradox.tex:76`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/inverses.tex:108–109, 112`; `mr/content/sets-functions-relations/sets/russells-paradox.tex:75`.
- **Authorities actually checked:**

  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P006, MR-C006, विधानीय तर्कशास्त्र, topics 1–4, printed page 12. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “स्वयंसिद्धक” remain, or should one of “स्वयंसिद्ध” replace it? Does the chosen wording preserve the technical sense of axiom without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T030 — relation / binary relation

- **Chosen wording:** संबंध / द्विपदी संबंध
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Relation label attested in mathematics dictionary and logic prose. Binary qualifier is compositional: ordered pairs, not binary numeral base.
- **Alternatives considered:** नाते; द्विपद संबंध.
- **Exact aligned source/target scopes:**

  - OLP-0011 B004: [English](../upstream/content/sets-functions-relations/relations/relations-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-complete.tex)
  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0013 B003–B008: [English](../upstream/content/sets-functions-relations/relations/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/reflections.tex)
  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0017 B004–B009: [English](../upstream/content/sets-functions-relations/relations/graphs.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/graphs.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0035 B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B008: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0042 B007, B014: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0045 B008, B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0047 B015–B016: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B007, B012, B015: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T030-OLP-0011-B004`, `T030-OLP-0012-B004`, `T030-OLP-0012-B005`, `T030-OLP-0012-B006`, `T030-OLP-0012-B007`, `T030-OLP-0012-B008`, `T030-OLP-0012-B009`, `T030-OLP-0012-B010`, `T030-OLP-0012-B011`, `T030-OLP-0012-B012`, `T030-OLP-0013-B003`, `T030-OLP-0013-B004`, `T030-OLP-0013-B005`, `T030-OLP-0013-B006`, `T030-OLP-0013-B007`, `T030-OLP-0013-B008`, `T030-OLP-0014-B004`, `T030-OLP-0014-B005`, `T030-OLP-0014-B006`, `T030-OLP-0014-B007`, `T030-OLP-0014-B008`, `T030-OLP-0014-B009`, `T030-OLP-0014-B010`, `T030-OLP-0014-B011`, `T030-OLP-0014-B012`, `T030-OLP-0014-B013`, `T030-OLP-0014-B014`, `T030-OLP-0014-B015`, `T030-OLP-0015-B005`, `T030-OLP-0015-B006`, `T030-OLP-0015-B007`, `T030-OLP-0015-B008`, `T030-OLP-0015-B009`, `T030-OLP-0015-B010`, `T030-OLP-0015-B011`, `T030-OLP-0015-B012`, `T030-OLP-0015-B013`, `T030-OLP-0015-B014`, `T030-OLP-0015-B015`, `T030-OLP-0016-B004`, `T030-OLP-0016-B005`, `T030-OLP-0016-B006`, `T030-OLP-0016-B007`, `T030-OLP-0016-B008`, `T030-OLP-0016-B009`, `T030-OLP-0016-B010`, `T030-OLP-0016-B011`, `T030-OLP-0016-B012`, `T030-OLP-0016-B013`, `T030-OLP-0016-B014`, `T030-OLP-0016-B015`, `T030-OLP-0016-B016`, `T030-OLP-0016-B017`, `T030-OLP-0016-B018`, `T030-OLP-0016-B019`, `T030-OLP-0016-B020`, `T030-OLP-0016-B021`, `T030-OLP-0016-B022`, `T030-OLP-0016-B023`, `T030-OLP-0016-B024`, `T030-OLP-0016-B025`, `T030-OLP-0016-B026`, `T030-OLP-0016-B027`, `T030-OLP-0016-B028`, `T030-OLP-0016-B029`, `T030-OLP-0017-B004`, `T030-OLP-0017-B005`, `T030-OLP-0017-B006`, `T030-OLP-0017-B007`, `T030-OLP-0017-B008`, `T030-OLP-0017-B009`, `T030-OLP-0018-B004`, `T030-OLP-0018-B005`, `T030-OLP-0018-B006`, `T030-OLP-0018-B008`, `T030-OLP-0018-B009`, `T030-OLP-0018-B010`, `T030-OLP-0018-B011`, `T030-OLP-0018-B012`, `T030-OLP-0018-B013`, `T030-OLP-0018-B014`, `T030-OLP-0018-B015`, `T030-OLP-0018-B016`, `T030-OLP-0018-B017`, `T030-OLP-0018-B018`, `T030-OLP-0018-B019`, `T030-OLP-0018-B020`, `T030-OLP-0019-B004`, `T030-OLP-0019-B005`, `T030-OLP-0019-B006`, `T030-OLP-0019-B007`, `T030-OLP-0019-B008`, `T030-OLP-0019-B009`, `T030-OLP-0019-B010`, `T030-OLP-0019-B011`, `T030-OLP-0019-B012`, `T030-OLP-0019-B013`, `T030-OLP-0019-B014`, `T030-OLP-0019-B015`, `T030-OLP-0019-B016`, `T030-OLP-0019-B017`, `T030-OLP-0019-B018`, `T030-OLP-0019-B019`, `T030-OLP-0019-B020`, `T030-OLP-0023-B005`, `T030-OLP-0023-B006`, `T030-OLP-0023-B007`, `T030-OLP-0023-B008`, `T030-OLP-0023-B009`, `T030-OLP-0023-B010`, `T030-OLP-0023-B011`, `T030-OLP-0023-B012`, `T030-OLP-0023-B013`, `T030-OLP-0023-B014`, `T030-OLP-0023-B015`, `T030-OLP-0023-B016`, `T030-OLP-0035-B008`, `T030-OLP-0035-B009`, `T030-OLP-0036-B008`, `T030-OLP-0042-B007`, `T030-OLP-0042-B014`, `T030-OLP-0045-B008`, `T030-OLP-0045-B012`, `T030-OLP-0047-B015`, `T030-OLP-0047-B016`, `T030-OLP-0048-B007`, `T030-OLP-0048-B012`, `T030-OLP-0048-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:1, 33, 109, 111, 122, 139`; `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:1, 102, 106–107, 113`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:1, 43`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:1, 24, 26–27, 39, 47`; `upstream/content/sets-functions-relations/functions/functions-relations.tex:1, 3, 12, 16, 20–21, 25, 39, 61–62, 67, 74, 97`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:1–3, 11, 13–14, 17–19, 23–24, 32, 43, 50, 64, 68, 79`; `upstream/content/sets-functions-relations/relations/graphs.tex:1–2, 22, 31, 34, 37, 39, 73`; `upstream/content/sets-functions-relations/relations/operations.tex:1–2, 10, 12, 14, 16–17, 20, 36, 39, 45, 50, 61`; `upstream/content/sets-functions-relations/relations/orders.tex:1–2, 15–16, 23, 39, 41, 46, 54, 62, 67, 73, 78, 83`; `upstream/content/sets-functions-relations/relations/reflections.tex:1–2, 12, 16, 28, 34, 36, 41–42, 54, 57, 59, 65–66, 71, 74`; `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:1–3, 10, 15, 17, 19–21, 34, 46, 49–50, 55–57, 62, 83–84, 91, 97, 99–101, 104, 109, 111–115, 117, 121`; `upstream/content/sets-functions-relations/relations/relations-complete.tex:1–2, 8, 10, 16`; `upstream/content/sets-functions-relations/relations/special-properties.tex:1–2, 10, 13, 17–18, 20, 24, 29, 34, 39, 45–46, 49–50, 52, 54, 58, 63, 66, 70, 75, 79–80, 83`; `upstream/content/sets-functions-relations/relations/trees.tex:1–2, 38, 42, 104, 112`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:1, 31, 42`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:1, 35`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:34, 39, 102–103, 116, 133, 163`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:102, 105–106, 111`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:42`; `mr/content/sets-functions-relations/arithmetization/integers.tex:24, 26–27, 39, 47`; `mr/content/sets-functions-relations/functions/functions-relations.tex:12, 16–17, 19–20, 24, 37, 41, 61–62, 64, 66, 71, 74, 93, 95, 101`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:11, 13–14, 16–18, 22, 24, 29, 40, 47, 62, 68, 77`; `mr/content/sets-functions-relations/relations/graphs.tex:15, 20–21, 29, 33, 35, 37, 70`; `mr/content/sets-functions-relations/relations/operations.tex:10, 12–14, 16–17, 20, 36, 40, 46, 51, 61`; `mr/content/sets-functions-relations/relations/orders.tex:15, 22, 36, 38, 43, 59, 63, 69, 74, 80`; `mr/content/sets-functions-relations/relations/reflections.tex:12, 16, 27, 34–35, 40–41, 53–54, 56–57, 63–64, 68, 71`; `mr/content/sets-functions-relations/relations/relations-as-sets.tex:10, 15–19, 33–34, 40, 45, 47, 49–50, 54–56, 83, 90, 96, 98, 100–103, 108–109, 111–113, 115, 119`; `mr/content/sets-functions-relations/relations/relations-complete.tex:8`; `mr/content/sets-functions-relations/relations/special-properties.tex:10, 13, 16, 18, 22, 27, 32, 37, 43–44, 47, 49–50, 54, 59, 62, 66, 71, 76–78`; `mr/content/sets-functions-relations/relations/trees.tex:22, 38, 41, 102, 111`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:32, 44`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:24, 35`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश](https://shabdakosh.marathi.gov.in/ananya-glossary/9/r) — MR-P023, MR-C013, relation, web lines 365–369. short primary-source observation read; source bytes not preserved
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
- **Precise review question:** In the listed formal contexts, should “संबंध / द्विपदी संबंध” remain, or should one of “नाते / द्विपद संबंध” replace it? Does the chosen wording preserve the technical sense of relation / binary relation without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T031 — identity relation

- **Chosen wording:** एकरूपता संबंध
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Every object related only to itself; distinguish from structural isomorphism. Provisional phrase guided by explicit source definition.
- **Alternatives considered:** तादात्म्य संबंध.
- **Exact aligned source/target scopes:**

  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
- **Occurrence records:** `T031-OLP-0012-B004`, `T031-OLP-0012-B005`, `T031-OLP-0012-B006`, `T031-OLP-0012-B007`, `T031-OLP-0012-B008`, `T031-OLP-0012-B009`, `T031-OLP-0012-B010`, `T031-OLP-0012-B011`, `T031-OLP-0012-B012`, `T031-OLP-0019-B004`, `T031-OLP-0019-B005`, `T031-OLP-0019-B006`, `T031-OLP-0019-B007`, `T031-OLP-0019-B008`, `T031-OLP-0019-B009`, `T031-OLP-0019-B010`, `T031-OLP-0019-B011`, `T031-OLP-0019-B012`, `T031-OLP-0019-B013`, `T031-OLP-0019-B014`, `T031-OLP-0019-B015`, `T031-OLP-0019-B016`, `T031-OLP-0019-B017`, `T031-OLP-0019-B018`, `T031-OLP-0019-B019`, `T031-OLP-0019-B020`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:83`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/relations-as-sets.tex:83`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P004, MR-C001, समान संच, opening criterion and examples, printed page 6. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** In the listed formal contexts, should “एकरूपता संबंध” remain, or should one of “तादात्म्य संबंध” replace it? Does the chosen wording preserve the technical sense of identity relation without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T032 — reflexive / irreflexive

- **Chosen wording:** परावर्ती / अपरावर्ती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Reflexive label attested; irreflexive extension provisional. Every x Rxx versus every x not Rxx, not merely failure of reflexivity. Empty domain treated by source quantifiers.
- **Alternatives considered:** स्वसंबंधी / अस्वसंबंधी.
- **Exact aligned source/target scopes:**

  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0035 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0042 B007–B008: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0047 B015: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T032-OLP-0012-B004`, `T032-OLP-0012-B005`, `T032-OLP-0012-B006`, `T032-OLP-0012-B007`, `T032-OLP-0012-B008`, `T032-OLP-0012-B009`, `T032-OLP-0012-B010`, `T032-OLP-0012-B011`, `T032-OLP-0012-B012`, `T032-OLP-0014-B004`, `T032-OLP-0014-B005`, `T032-OLP-0014-B006`, `T032-OLP-0014-B007`, `T032-OLP-0014-B008`, `T032-OLP-0014-B009`, `T032-OLP-0014-B010`, `T032-OLP-0014-B011`, `T032-OLP-0014-B012`, `T032-OLP-0014-B013`, `T032-OLP-0014-B014`, `T032-OLP-0014-B015`, `T032-OLP-0015-B005`, `T032-OLP-0015-B006`, `T032-OLP-0015-B007`, `T032-OLP-0015-B008`, `T032-OLP-0015-B009`, `T032-OLP-0015-B010`, `T032-OLP-0015-B011`, `T032-OLP-0015-B012`, `T032-OLP-0015-B013`, `T032-OLP-0015-B014`, `T032-OLP-0015-B015`, `T032-OLP-0016-B004`, `T032-OLP-0016-B005`, `T032-OLP-0016-B006`, `T032-OLP-0016-B007`, `T032-OLP-0016-B008`, `T032-OLP-0016-B009`, `T032-OLP-0016-B010`, `T032-OLP-0016-B011`, `T032-OLP-0016-B012`, `T032-OLP-0016-B013`, `T032-OLP-0016-B014`, `T032-OLP-0016-B015`, `T032-OLP-0016-B016`, `T032-OLP-0016-B017`, `T032-OLP-0016-B018`, `T032-OLP-0016-B019`, `T032-OLP-0016-B020`, `T032-OLP-0016-B021`, `T032-OLP-0016-B022`, `T032-OLP-0016-B023`, `T032-OLP-0016-B024`, `T032-OLP-0016-B025`, `T032-OLP-0016-B026`, `T032-OLP-0016-B027`, `T032-OLP-0016-B028`, `T032-OLP-0016-B029`, `T032-OLP-0019-B004`, `T032-OLP-0019-B005`, `T032-OLP-0019-B006`, `T032-OLP-0019-B007`, `T032-OLP-0019-B008`, `T032-OLP-0019-B009`, `T032-OLP-0019-B010`, `T032-OLP-0019-B011`, `T032-OLP-0019-B012`, `T032-OLP-0019-B013`, `T032-OLP-0019-B014`, `T032-OLP-0019-B015`, `T032-OLP-0019-B016`, `T032-OLP-0019-B017`, `T032-OLP-0019-B018`, `T032-OLP-0019-B019`, `T032-OLP-0019-B020`, `T032-OLP-0035-B009`, `T032-OLP-0036-B008`, `T032-OLP-0036-B010`, `T032-OLP-0042-B007`, `T032-OLP-0042-B008`, `T032-OLP-0047-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:106`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:30`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:13, 18, 58`; `upstream/content/sets-functions-relations/relations/operations.tex:56`; `upstream/content/sets-functions-relations/relations/orders.tex:23, 40, 48, 83, 100, 112–113, 115, 164`; `upstream/content/sets-functions-relations/relations/relations-as-sets.tex:104`; `upstream/content/sets-functions-relations/relations/special-properties.tex:24, 49, 51, 63–65, 70, 79–80, 82`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:31, 42`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:39`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:105`; `mr/content/sets-functions-relations/arithmetization/integers.tex:30`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:13, 17, 55`; `mr/content/sets-functions-relations/relations/operations.tex:57`; `mr/content/sets-functions-relations/relations/orders.tex:22, 36, 45, 80, 95, 106–107, 109, 158`; `mr/content/sets-functions-relations/relations/relations-as-sets.tex:103`; `mr/content/sets-functions-relations/relations/special-properties.tex:22, 47, 59–61, 66, 75–78`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:32, 44`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:39`.
- **Authorities actually checked:**

  - [मराठी विश्वकोश शब्दसंग्रह](https://shabdakosh.marathi.gov.in/ananya-glossary/41/r) — MR-P025, MR-C015, reflexive / reflexivity. short primary-source observation read; source bytes not preserved
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** In the listed formal contexts, should “परावर्ती / अपरावर्ती” remain, or should one of “स्वसंबंधी / अस्वसंबंधी” replace it? Does the chosen wording preserve the technical sense of reflexive / irreflexive without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T033 — transitive

- **Chosen wording:** संक्रमक
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Use specific logic dictionary spelling संक्रमक, not संक्रामक from broader senses. Two-step relation entails direct relation, not temporal change.
- **Alternatives considered:** संक्रामी; संक्रामक — नाकारले; सामान्य संसर्गाचा अर्थ येतो.
- **Exact aligned source/target scopes:**

  - OLP-0012 B004–B012: [English](../upstream/content/sets-functions-relations/relations/relations-as-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/relations-as-sets.tex)
  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0035 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0042 B007, B010: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0047 B015: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T033-OLP-0012-B004`, `T033-OLP-0012-B005`, `T033-OLP-0012-B006`, `T033-OLP-0012-B007`, `T033-OLP-0012-B008`, `T033-OLP-0012-B009`, `T033-OLP-0012-B010`, `T033-OLP-0012-B011`, `T033-OLP-0012-B012`, `T033-OLP-0014-B004`, `T033-OLP-0014-B005`, `T033-OLP-0014-B006`, `T033-OLP-0014-B007`, `T033-OLP-0014-B008`, `T033-OLP-0014-B009`, `T033-OLP-0014-B010`, `T033-OLP-0014-B011`, `T033-OLP-0014-B012`, `T033-OLP-0014-B013`, `T033-OLP-0014-B014`, `T033-OLP-0014-B015`, `T033-OLP-0015-B005`, `T033-OLP-0015-B006`, `T033-OLP-0015-B007`, `T033-OLP-0015-B008`, `T033-OLP-0015-B009`, `T033-OLP-0015-B010`, `T033-OLP-0015-B011`, `T033-OLP-0015-B012`, `T033-OLP-0015-B013`, `T033-OLP-0015-B014`, `T033-OLP-0015-B015`, `T033-OLP-0016-B004`, `T033-OLP-0016-B005`, `T033-OLP-0016-B006`, `T033-OLP-0016-B007`, `T033-OLP-0016-B008`, `T033-OLP-0016-B009`, `T033-OLP-0016-B010`, `T033-OLP-0016-B011`, `T033-OLP-0016-B012`, `T033-OLP-0016-B013`, `T033-OLP-0016-B014`, `T033-OLP-0016-B015`, `T033-OLP-0016-B016`, `T033-OLP-0016-B017`, `T033-OLP-0016-B018`, `T033-OLP-0016-B019`, `T033-OLP-0016-B020`, `T033-OLP-0016-B021`, `T033-OLP-0016-B022`, `T033-OLP-0016-B023`, `T033-OLP-0016-B024`, `T033-OLP-0016-B025`, `T033-OLP-0016-B026`, `T033-OLP-0016-B027`, `T033-OLP-0016-B028`, `T033-OLP-0016-B029`, `T033-OLP-0019-B004`, `T033-OLP-0019-B005`, `T033-OLP-0019-B006`, `T033-OLP-0019-B007`, `T033-OLP-0019-B008`, `T033-OLP-0019-B009`, `T033-OLP-0019-B010`, `T033-OLP-0019-B011`, `T033-OLP-0019-B012`, `T033-OLP-0019-B013`, `T033-OLP-0019-B014`, `T033-OLP-0019-B015`, `T033-OLP-0019-B016`, `T033-OLP-0019-B017`, `T033-OLP-0019-B018`, `T033-OLP-0019-B019`, `T033-OLP-0019-B020`, `T033-OLP-0035-B009`, `T033-OLP-0036-B008`, `T033-OLP-0036-B010`, `T033-OLP-0042-B007`, `T033-OLP-0042-B010`, `T033-OLP-0047-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:106`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:30`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:14, 19, 51`; `upstream/content/sets-functions-relations/relations/operations.tex:50, 52, 56, 68`; `upstream/content/sets-functions-relations/relations/orders.tex:23, 40, 48, 84, 112–113, 126, 130`; `upstream/content/sets-functions-relations/relations/special-properties.tex:29, 64–66`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:31, 43`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:40`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:105`; `mr/content/sets-functions-relations/arithmetization/integers.tex:30, 36`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:13, 17, 48`; `mr/content/sets-functions-relations/relations/operations.tex:51, 53, 57, 70`; `mr/content/sets-functions-relations/relations/orders.tex:22, 37, 45, 80, 106–107, 118, 120, 124`; `mr/content/sets-functions-relations/relations/special-properties.tex:26–27, 60–61`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:32, 44`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:39, 52`.
- **Authorities actually checked:**

  - [तत्त्वज्ञान व तर्कशास्त्र परिभाषा कोश](https://shabdakosh.marathi.gov.in/ananya-glossary/7/t) — MR-P024, MR-C014, transitive relation / transitivity of equivalence. short primary-source observation read; source bytes not preserved
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** Is संक्रमक the standard relation-theory spelling, and does it avoid the infectious/common sense carried by संक्रामक?

## T034 — symmetric / anti-symmetric / asymmetric

- **Chosen wording:** सममित / प्रतिसममित / असममित
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Compositional technical distinctions, definitions governed by source. Anti-symmetry permits a two-way relation only at equality; asymmetry forbids every two-way pair. Not-symmetric kept as सममित नसलेला, not used as synonym for either.
- **Alternatives considered:** सममितीय / प्रतिसममितीय / विषममितीय.
- **Exact aligned source/target scopes:**

  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0035 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B008: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0042 B007, B009: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0047 B015: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T034-OLP-0014-B004`, `T034-OLP-0014-B005`, `T034-OLP-0014-B006`, `T034-OLP-0014-B007`, `T034-OLP-0014-B008`, `T034-OLP-0014-B009`, `T034-OLP-0014-B010`, `T034-OLP-0014-B011`, `T034-OLP-0014-B012`, `T034-OLP-0014-B013`, `T034-OLP-0014-B014`, `T034-OLP-0014-B015`, `T034-OLP-0015-B005`, `T034-OLP-0015-B006`, `T034-OLP-0015-B007`, `T034-OLP-0015-B008`, `T034-OLP-0015-B009`, `T034-OLP-0015-B010`, `T034-OLP-0015-B011`, `T034-OLP-0015-B012`, `T034-OLP-0015-B013`, `T034-OLP-0015-B014`, `T034-OLP-0015-B015`, `T034-OLP-0016-B004`, `T034-OLP-0016-B005`, `T034-OLP-0016-B006`, `T034-OLP-0016-B007`, `T034-OLP-0016-B008`, `T034-OLP-0016-B009`, `T034-OLP-0016-B010`, `T034-OLP-0016-B011`, `T034-OLP-0016-B012`, `T034-OLP-0016-B013`, `T034-OLP-0016-B014`, `T034-OLP-0016-B015`, `T034-OLP-0016-B016`, `T034-OLP-0016-B017`, `T034-OLP-0016-B018`, `T034-OLP-0016-B019`, `T034-OLP-0016-B020`, `T034-OLP-0016-B021`, `T034-OLP-0016-B022`, `T034-OLP-0016-B023`, `T034-OLP-0016-B024`, `T034-OLP-0016-B025`, `T034-OLP-0016-B026`, `T034-OLP-0016-B027`, `T034-OLP-0016-B028`, `T034-OLP-0016-B029`, `T034-OLP-0035-B009`, `T034-OLP-0036-B008`, `T034-OLP-0042-B007`, `T034-OLP-0042-B009`, `T034-OLP-0047-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:106`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:30`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:13, 18, 51`; `upstream/content/sets-functions-relations/relations/orders.tex:28, 42, 49, 68, 83, 112–113, 118, 122`; `upstream/content/sets-functions-relations/relations/special-properties.tex:34, 45–46, 49–53, 63–65, 75, 80–83`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:32`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:39`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:105`; `mr/content/sets-functions-relations/arithmetization/integers.tex:30, 34`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:13, 17, 48`; `mr/content/sets-functions-relations/relations/orders.tex:26, 38, 46, 64, 80, 106–107, 112, 115`; `mr/content/sets-functions-relations/relations/special-properties.tex:31–32, 36, 43–44, 46–49, 59–61, 70–71, 76, 78`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:32`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:39, 46`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P004, MR-C001, समान संच, opening criterion and examples, printed page 6. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P022, MR-C011, Predicate logic continuation and section 3.2, printed page 20. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** Do प्रतिसममित and असममित preserve the formal difference between antisymmetry and asymmetry?

## T035 — connected (relation)

- **Chosen wording:** संयोजित
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Provisional label: each distinct pair comparable in one direction. Keep graph path-connectivity separately defined; no claim that the terms imply identical conditions.
- **Alternatives considered:** संलग्न; तुलनीय.
- **Exact aligned source/target scopes:**

  - OLP-0014 B004–B015: [English](../upstream/content/sets-functions-relations/relations/special-properties.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/special-properties.tex)
  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0047 B015: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T035-OLP-0014-B004`, `T035-OLP-0014-B005`, `T035-OLP-0014-B006`, `T035-OLP-0014-B007`, `T035-OLP-0014-B008`, `T035-OLP-0014-B009`, `T035-OLP-0014-B010`, `T035-OLP-0014-B011`, `T035-OLP-0014-B012`, `T035-OLP-0014-B013`, `T035-OLP-0014-B014`, `T035-OLP-0014-B015`, `T035-OLP-0016-B004`, `T035-OLP-0016-B005`, `T035-OLP-0016-B006`, `T035-OLP-0016-B007`, `T035-OLP-0016-B008`, `T035-OLP-0016-B009`, `T035-OLP-0016-B010`, `T035-OLP-0016-B011`, `T035-OLP-0016-B012`, `T035-OLP-0016-B013`, `T035-OLP-0016-B014`, `T035-OLP-0016-B015`, `T035-OLP-0016-B016`, `T035-OLP-0016-B017`, `T035-OLP-0016-B018`, `T035-OLP-0016-B019`, `T035-OLP-0016-B020`, `T035-OLP-0016-B021`, `T035-OLP-0016-B022`, `T035-OLP-0016-B023`, `T035-OLP-0016-B024`, `T035-OLP-0016-B025`, `T035-OLP-0016-B026`, `T035-OLP-0016-B027`, `T035-OLP-0016-B028`, `T035-OLP-0016-B029`, `T035-OLP-0047-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:106`; `upstream/content/sets-functions-relations/relations/orders.tex:33, 48, 88, 132, 135, 165`; `upstream/content/sets-functions-relations/relations/special-properties.tex:58`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:105–106`; `mr/content/sets-functions-relations/relations/orders.tex:30, 45, 84, 126, 129, 159`; `mr/content/sets-functions-relations/relations/special-properties.tex:53–54`.
- **Authorities actually checked:**

  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P022, MR-C011, Predicate logic continuation and section 3.2, printed page 20. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** Does संयोजित convey pairwise comparability here without being confused with graph path-connectedness?

## T036 — order / strict order

- **Chosen wording:** क्रम / काटेकोर क्रम
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Ordered-pair usage supports sequence sense, not full order axioms. Exact source properties control mathematical meaning.
- **Alternatives considered:** कठोर क्रम.
- **Exact aligned source/target scopes:**

  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0042 B015: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B006, B008: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0045 B008: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0047 B015–B016: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B015: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T036-OLP-0016-B004`, `T036-OLP-0016-B005`, `T036-OLP-0016-B006`, `T036-OLP-0016-B007`, `T036-OLP-0016-B008`, `T036-OLP-0016-B009`, `T036-OLP-0016-B010`, `T036-OLP-0016-B011`, `T036-OLP-0016-B012`, `T036-OLP-0016-B013`, `T036-OLP-0016-B014`, `T036-OLP-0016-B015`, `T036-OLP-0016-B016`, `T036-OLP-0016-B017`, `T036-OLP-0016-B018`, `T036-OLP-0016-B019`, `T036-OLP-0016-B020`, `T036-OLP-0016-B021`, `T036-OLP-0016-B022`, `T036-OLP-0016-B023`, `T036-OLP-0016-B024`, `T036-OLP-0016-B025`, `T036-OLP-0016-B026`, `T036-OLP-0016-B027`, `T036-OLP-0016-B028`, `T036-OLP-0016-B029`, `T036-OLP-0018-B004`, `T036-OLP-0018-B005`, `T036-OLP-0018-B006`, `T036-OLP-0018-B008`, `T036-OLP-0018-B009`, `T036-OLP-0018-B010`, `T036-OLP-0018-B011`, `T036-OLP-0018-B012`, `T036-OLP-0018-B013`, `T036-OLP-0018-B014`, `T036-OLP-0018-B015`, `T036-OLP-0018-B016`, `T036-OLP-0018-B017`, `T036-OLP-0018-B018`, `T036-OLP-0018-B019`, `T036-OLP-0018-B020`, `T036-OLP-0042-B015`, `T036-OLP-0043-B006`, `T036-OLP-0043-B008`, `T036-OLP-0045-B008`, `T036-OLP-0047-B015`, `T036-OLP-0047-B016`, `T036-OLP-0048-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:149, 162, 170`; `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:11, 102, 104–105, 107, 112–113, 121, 125, 129, 132, 138–139, 142, 147, 151, 176`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:47`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:16, 18, 24, 42`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:20, 23`; `upstream/content/sets-functions-relations/relations/orders.tex:3, 10, 15–16, 27, 29, 32–34, 38, 42, 49, 54–55, 63, 65–66, 78, 82–83, 87–89, 93–95, 98, 101, 105–107, 111, 139–141, 152, 156`; `upstream/content/sets-functions-relations/relations/trees.tex:12, 19, 42, 44, 46, 51, 53, 74, 103`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:11, 14, 42, 54–56, 66, 68–69, 79, 87, 91, 93–94, 96, 99, 102, 117, 123, 140–141, 143, 145, 161, 163, 170, 177, 182, 211, 220, 230`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:11, 19, 23, 28, 40, 94, 98, 102–103, 105–106, 111–112, 120, 123, 128, 130, 136, 140, 144–145, 147, 174`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:46`; `mr/content/sets-functions-relations/arithmetization/integers.tex:16, 18, 24, 30, 36, 42`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:19, 22`; `mr/content/sets-functions-relations/relations/orders.tex:10, 14–15, 21–22, 25–26, 29–30, 35, 37, 39, 45–46, 51–52, 59, 62, 64, 69, 71, 74, 79–80, 83–85, 89–90, 93–96, 99–101, 105–107, 118, 120, 124, 133–135, 146, 150`; `mr/content/sets-functions-relations/relations/trees.tex:12, 41, 43, 46, 50, 52, 73, 101–102, 106, 110`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [गणित, इयत्ता आठवी](https://books.ebalbharati.in/pdfs/801020004.pdf) — MR-P027, MR-C017, PDF page 12, printed page 2. Personally read recovered OCR and actual page image; historical consultation not adopted
- **Precise review question:** In the listed formal contexts, should “क्रम / काटेकोर क्रम” remain, or should one of “कठोर क्रम” replace it? Does the chosen wording preserve the technical sense of order / strict order without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T037 — equivalence relation / class / quotient

- **Chosen wording:** तुल्यता संबंध / तुल्यतावर्ग / भागाकारसंच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Equivalence label observed in native group-theory use; class and quotient compounds provisional. Quotient is a set of classes, not numeric division.
- **Alternatives considered:** समतुल्यता संबंध / समतुल्यतावर्ग / भागसंच.
- **Exact aligned source/target scopes:**

  - OLP-0015 B005–B015: [English](../upstream/content/sets-functions-relations/relations/equivalence-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/equivalence-relations.tex)
  - OLP-0035 B008: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0042 B007–B012, B014: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B005–B006: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0046 B009, B011: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B008, B010, B012: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B007, B011–B012, B014–B015, B017, B019–B020, B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T037-OLP-0015-B005`, `T037-OLP-0015-B006`, `T037-OLP-0015-B007`, `T037-OLP-0015-B008`, `T037-OLP-0015-B009`, `T037-OLP-0015-B010`, `T037-OLP-0015-B011`, `T037-OLP-0015-B012`, `T037-OLP-0015-B013`, `T037-OLP-0015-B014`, `T037-OLP-0015-B015`, `T037-OLP-0035-B008`, `T037-OLP-0042-B007`, `T037-OLP-0042-B008`, `T037-OLP-0042-B009`, `T037-OLP-0042-B010`, `T037-OLP-0042-B011`, `T037-OLP-0042-B012`, `T037-OLP-0042-B014`, `T037-OLP-0043-B005`, `T037-OLP-0043-B006`, `T037-OLP-0046-B009`, `T037-OLP-0046-B011`, `T037-OLP-0047-B008`, `T037-OLP-0047-B010`, `T037-OLP-0047-B012`, `T037-OLP-0048-B007`, `T037-OLP-0048-B011`, `T037-OLP-0048-B012`, `T037-OLP-0048-B014`, `T037-OLP-0048-B015`, `T037-OLP-0048-B017`, `T037-OLP-0048-B019`, `T037-OLP-0048-B020`, `T037-OLP-0048-B023`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:33, 109, 122, 124, 134, 154`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:24, 26–27, 39, 42, 47`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:30, 35, 38, 42, 48`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:39–40, 48`; `upstream/content/sets-functions-relations/relations/equivalence-relations.tex:11, 17, 19, 23–24, 32–34, 36, 39–40, 43, 50, 64, 68–69, 79`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:35`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:34, 102–104, 116, 118, 128, 143, 151–152, 161, 163, 170, 177`; `mr/content/sets-functions-relations/arithmetization/integers.tex:24, 26–27, 39, 42, 47`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:30, 34, 37, 42, 47`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:35, 37, 45`; `mr/content/sets-functions-relations/relations/equivalence-relations.tex:11, 16, 18, 22, 29–30, 32–33, 36, 40, 62, 68, 77`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:35`.
- **Authorities actually checked:**

  - [गट सिद्धांत](https://vishwakosh.marathi.gov.in/21196/) — MR-P026, MR-C016, representation isomorphism discussion, primary search observation. short primary-source observation read; source bytes not preserved
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P004, MR-C001, समान संच, opening criterion and examples, printed page 6. visually-read-page-image
- **Precise review question:** Are तुल्यतावर्ग and भागाकारसंच standard, and does भागाकारसंच avoid suggesting numerical division?

## T038 — metaphysical identity / set-theoretic reductionism

- **Chosen wording:** सत्तामीमांसक एकरूपता / संचसैद्धान्तिक न्यूनीकरणवाद
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** evidence-based-provisional; attestation limits in reason. This choice remains open to correction.
- **Rationale:** Provisional philosophical compounds; no exact-label attestation claimed. Preserve source distinction between convenient representation and an ontological identity discovery. Predicate/name distinction from native predicate-logic prose.
- **Alternatives considered:** तात्त्विक एकरूपता / संचसैद्धान्तिक न्यूनतावाद.
- **Exact aligned source/target scopes:**

  - OLP-0013 B003–B008: [English](../upstream/content/sets-functions-relations/relations/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/reflections.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0046 B004, B007, B010, B012–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
- **Occurrence records:** `T038-OLP-0013-B003`, `T038-OLP-0013-B004`, `T038-OLP-0013-B005`, `T038-OLP-0013-B006`, `T038-OLP-0013-B007`, `T038-OLP-0013-B008`, `T038-OLP-0023-B005`, `T038-OLP-0023-B006`, `T038-OLP-0023-B007`, `T038-OLP-0023-B008`, `T038-OLP-0023-B009`, `T038-OLP-0023-B010`, `T038-OLP-0023-B011`, `T038-OLP-0023-B012`, `T038-OLP-0023-B013`, `T038-OLP-0023-B014`, `T038-OLP-0023-B015`, `T038-OLP-0023-B016`, `T038-OLP-0046-B004`, `T038-OLP-0046-B007`, `T038-OLP-0046-B010`, `T038-OLP-0046-B012`, `T038-OLP-0046-B013`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/reflections.tex:15, 38, 73`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/reflections.tex:36`.
- **Authorities actually checked:**

  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P022, MR-C011, Predicate logic continuation and section 3.2, printed page 20. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [MR-C002](https://vishwakosh.marathi.gov.in/20027/) — MR-P010, MR-C002, opening definition and first argument-form discussion; truth-value discussion. Do not treat observation hash as source-byte hash or claim full original archived.
- **Precise review question:** Do the philosophical compounds preserve the source's distinction between representation and ontological identity?

## T039 — preorder / partial order / linear order

- **Chosen wording:** पूर्वक्रम / अंशतः क्रम / रेषीय क्रम
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Provisional order compounds, defined from exact OpenLogic properties; total means every distinct pair comparable, not completeness of a theory.
- **Alternatives considered:** पूर्वक्रम / आंशिक क्रम / पूर्ण क्रम.
- **Exact aligned source/target scopes:**

  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
- **Occurrence records:** `T039-OLP-0016-B004`, `T039-OLP-0016-B005`, `T039-OLP-0016-B006`, `T039-OLP-0016-B007`, `T039-OLP-0016-B008`, `T039-OLP-0016-B009`, `T039-OLP-0016-B010`, `T039-OLP-0016-B011`, `T039-OLP-0016-B012`, `T039-OLP-0016-B013`, `T039-OLP-0016-B014`, `T039-OLP-0016-B015`, `T039-OLP-0016-B016`, `T039-OLP-0016-B017`, `T039-OLP-0016-B018`, `T039-OLP-0016-B019`, `T039-OLP-0016-B020`, `T039-OLP-0016-B021`, `T039-OLP-0016-B022`, `T039-OLP-0016-B023`, `T039-OLP-0016-B024`, `T039-OLP-0016-B025`, `T039-OLP-0016-B026`, `T039-OLP-0016-B027`, `T039-OLP-0016-B028`, `T039-OLP-0016-B029`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/orders.tex:22, 24, 27–29, 32–34, 38–40, 42, 48–49, 54–55, 63, 65–66, 68, 78, 87, 89, 93–94, 98, 101, 106–107, 139–141, 152, 156`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/orders.tex:21–22, 25–26, 29–30, 35, 37, 39, 45–46, 51–52, 59, 62, 64, 74, 83, 85, 89–90, 94–95, 100, 133–135, 146, 150`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तत्त्वज्ञान व तर्कशास्त्र परिभाषा कोश](https://shabdakosh.marathi.gov.in/ananya-glossary/7/t) — MR-P024, MR-C014, transitive relation / transitivity of equivalence. short primary-source observation read; source bytes not preserved
  - [मराठी विश्वकोश शब्दसंग्रह](https://shabdakosh.marathi.gov.in/ananya-glossary/41/r) — MR-P025, MR-C015, reflexive / reflexivity. short primary-source observation read; source bytes not preserved
- **Precise review question:** In the listed formal contexts, should “पूर्वक्रम / अंशतः क्रम / रेषीय क्रम” remain, or should one of “पूर्वक्रम / आंशिक क्रम / पूर्ण क्रम” replace it? Does the chosen wording preserve the technical sense of preorder / partial order / linear order without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T040 — graph / directed graph / vertex / edge

- **Chosen wording:** आलेख / दिशित आलेख / शिखर / कड
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Provisional graph-theory extension using native mathematical and spatial nouns. Directed-edge relation is not an ordinary function plot; isolated vertices remain part of graph identity.
- **Alternatives considered:** ग्राफ / शीर्ष / धार.
- **Exact aligned source/target scopes:**

  - OLP-0017 B004–B009: [English](../upstream/content/sets-functions-relations/relations/graphs.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/graphs.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
- **Occurrence records:** `T040-OLP-0017-B004`, `T040-OLP-0017-B005`, `T040-OLP-0017-B006`, `T040-OLP-0017-B007`, `T040-OLP-0017-B008`, `T040-OLP-0017-B009`, `T040-OLP-0018-B004`, `T040-OLP-0018-B005`, `T040-OLP-0018-B006`, `T040-OLP-0018-B008`, `T040-OLP-0018-B009`, `T040-OLP-0018-B010`, `T040-OLP-0018-B011`, `T040-OLP-0018-B012`, `T040-OLP-0018-B013`, `T040-OLP-0018-B014`, `T040-OLP-0018-B015`, `T040-OLP-0018-B016`, `T040-OLP-0018-B017`, `T040-OLP-0018-B018`, `T040-OLP-0018-B019`, `T040-OLP-0018-B020`, `T040-OLP-0023-B005`, `T040-OLP-0023-B006`, `T040-OLP-0023-B007`, `T040-OLP-0023-B008`, `T040-OLP-0023-B009`, `T040-OLP-0023-B010`, `T040-OLP-0023-B011`, `T040-OLP-0023-B012`, `T040-OLP-0023-B013`, `T040-OLP-0023-B014`, `T040-OLP-0023-B015`, `T040-OLP-0023-B016`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/functions-relations.tex:24–25, 33, 39, 42, 49, 61, 64, 66`; `upstream/content/sets-functions-relations/relations/graphs.tex:3, 10, 12–13, 18–22, 24–26, 30–31, 33, 35–36, 38–39, 44, 58, 74`; `upstream/content/sets-functions-relations/relations/trees.tex:23, 40`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/functions-relations.tex:23–24, 32, 37, 48, 59, 63–65, 101`; `mr/content/sets-functions-relations/relations/graphs.tex:10, 12–14, 17–20, 23–24, 29–36, 43, 55–56, 71`; `mr/content/sets-functions-relations/relations/trees.tex:21, 36–37`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [गणितशास्त्र परिभाषा कोश](https://shabdakosh.marathi.gov.in/ananya-glossary/9/r) — MR-P023, MR-C013, relation, web lines 365–369. short primary-source observation read; source bytes not preserved
- **Precise review question:** In the listed formal contexts, should “आलेख / दिशित आलेख / शिखर / कड” remain, or should one of “ग्राफ / शीर्ष / धार” replace it? Does the chosen wording preserve the technical sense of graph / directed graph / vertex / edge without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T041 — tree / root / branch / chain

- **Chosen wording:** वृक्ष / मूळ / शाखा / शृंखला
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Provisional descriptive mathematical metaphor. Definitions distinguish maximal chain from merely long path and finitely branching from finite total size.
- **Alternatives considered:** तरू / मूल / फांदी / साखळी.
- **Exact aligned source/target scopes:**

  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
- **Occurrence records:** `T041-OLP-0018-B004`, `T041-OLP-0018-B005`, `T041-OLP-0018-B006`, `T041-OLP-0018-B008`, `T041-OLP-0018-B009`, `T041-OLP-0018-B010`, `T041-OLP-0018-B011`, `T041-OLP-0018-B012`, `T041-OLP-0018-B013`, `T041-OLP-0018-B014`, `T041-OLP-0018-B015`, `T041-OLP-0018-B016`, `T041-OLP-0018-B017`, `T041-OLP-0018-B018`, `T041-OLP-0018-B019`, `T041-OLP-0018-B020`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/trees.tex:3, 10, 13, 15–16, 18, 22–23, 37, 42, 49–50, 52, 57, 67, 84, 87, 90–92, 97, 101–102, 106–107, 113, 117, 122–123, 128`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/trees.tex:10, 12–14, 16, 19, 21–22, 36, 41, 48–49, 51, 56, 66, 83, 86, 89–91, 96, 100–101, 104, 106, 111, 115–117, 121–122, 127`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** In the listed formal contexts, should “वृक्ष / मूळ / शाखा / शृंखला” remain, or should one of “तरू / मूल / फांदी / साखळी” replace it? Does the chosen wording preserve the technical sense of tree / root / branch / chain without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T042 — least / well-ordered / predecessor / successor

- **Chosen wording:** लघुतम / सुक्रमित / पूर्ववर्ती / उत्तरवर्ती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Provisional extension; least is below every element, not merely minimal. Successor/predecessor here is immediate, unlike arbitrary descendant/ancestor.
- **Alternatives considered:** न्यूनतम / सुव्यवस्थित / पूर्वज / उत्तरज.
- **Exact aligned source/target scopes:**

  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
  - OLP-0038 B013: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
- **Occurrence records:** `T042-OLP-0016-B004`, `T042-OLP-0016-B005`, `T042-OLP-0016-B006`, `T042-OLP-0016-B007`, `T042-OLP-0016-B008`, `T042-OLP-0016-B009`, `T042-OLP-0016-B010`, `T042-OLP-0016-B011`, `T042-OLP-0016-B012`, `T042-OLP-0016-B013`, `T042-OLP-0016-B014`, `T042-OLP-0016-B015`, `T042-OLP-0016-B016`, `T042-OLP-0016-B017`, `T042-OLP-0016-B018`, `T042-OLP-0016-B019`, `T042-OLP-0016-B020`, `T042-OLP-0016-B021`, `T042-OLP-0016-B022`, `T042-OLP-0016-B023`, `T042-OLP-0016-B024`, `T042-OLP-0016-B025`, `T042-OLP-0016-B026`, `T042-OLP-0016-B027`, `T042-OLP-0016-B028`, `T042-OLP-0016-B029`, `T042-OLP-0018-B004`, `T042-OLP-0018-B005`, `T042-OLP-0018-B006`, `T042-OLP-0018-B008`, `T042-OLP-0018-B009`, `T042-OLP-0018-B010`, `T042-OLP-0018-B011`, `T042-OLP-0018-B012`, `T042-OLP-0018-B013`, `T042-OLP-0018-B014`, `T042-OLP-0018-B015`, `T042-OLP-0018-B016`, `T042-OLP-0018-B017`, `T042-OLP-0018-B018`, `T042-OLP-0018-B019`, `T042-OLP-0018-B020`, `T042-OLP-0038-B013`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/trees.tex:44, 46–47, 51, 53, 56, 59, 62–63, 68, 74, 80, 86, 107, 114`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:74`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/trees.tex:43, 45–46, 50, 52, 55, 58, 61–62, 67, 73, 78, 85, 105, 113`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:71`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** Does लघुतम clearly mean below every element, rather than merely minimal?

## T043 — closure / inverse / restriction / relative product

- **Chosen wording:** संवरण / व्युत्क्रम / मर्यादन / सापेक्ष गुणाकार
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Provisional relation-operation compounds. Source defines inverse by swapping coordinates, restriction to both coordinates in A, product R then S, and transitive closure with positive lengths.
- **Alternatives considered:** बंदता / प्रतिलोम / निर्बंध / संबंधगुणाकार.
- **Exact aligned source/target scopes:**

  - OLP-0016 B004–B029: [English](../upstream/content/sets-functions-relations/relations/orders.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/orders.tex)
  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
- **Occurrence records:** `T043-OLP-0016-B004`, `T043-OLP-0016-B005`, `T043-OLP-0016-B006`, `T043-OLP-0016-B007`, `T043-OLP-0016-B008`, `T043-OLP-0016-B009`, `T043-OLP-0016-B010`, `T043-OLP-0016-B011`, `T043-OLP-0016-B012`, `T043-OLP-0016-B013`, `T043-OLP-0016-B014`, `T043-OLP-0016-B015`, `T043-OLP-0016-B016`, `T043-OLP-0016-B017`, `T043-OLP-0016-B018`, `T043-OLP-0016-B019`, `T043-OLP-0016-B020`, `T043-OLP-0016-B021`, `T043-OLP-0016-B022`, `T043-OLP-0016-B023`, `T043-OLP-0016-B024`, `T043-OLP-0016-B025`, `T043-OLP-0016-B026`, `T043-OLP-0016-B027`, `T043-OLP-0016-B028`, `T043-OLP-0016-B029`, `T043-OLP-0019-B004`, `T043-OLP-0019-B005`, `T043-OLP-0019-B006`, `T043-OLP-0019-B007`, `T043-OLP-0019-B008`, `T043-OLP-0019-B009`, `T043-OLP-0019-B010`, `T043-OLP-0019-B011`, `T043-OLP-0019-B012`, `T043-OLP-0019-B013`, `T043-OLP-0019-B014`, `T043-OLP-0019-B015`, `T043-OLP-0019-B016`, `T043-OLP-0019-B017`, `T043-OLP-0019-B018`, `T043-OLP-0019-B019`, `T043-OLP-0019-B020`, `T043-OLP-0023-B005`, `T043-OLP-0023-B006`, `T043-OLP-0023-B007`, `T043-OLP-0023-B008`, `T043-OLP-0023-B009`, `T043-OLP-0023-B010`, `T043-OLP-0023-B011`, `T043-OLP-0023-B012`, `T043-OLP-0023-B013`, `T043-OLP-0023-B014`, `T043-OLP-0023-B015`, `T043-OLP-0023-B016`, `T043-OLP-0025-B004`, `T043-OLP-0025-B005`, `T043-OLP-0025-B006`, `T043-OLP-0025-B007`, `T043-OLP-0025-B008`, `T043-OLP-0025-B009`, `T043-OLP-0025-B010`, `T043-OLP-0025-B011`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/composition.tex:14, 20`; `upstream/content/sets-functions-relations/functions/functions-relations.tex:81, 98`; `upstream/content/sets-functions-relations/relations/operations.tex:22, 25, 28, 50, 52, 56, 68`; `upstream/content/sets-functions-relations/relations/orders.tex:100`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/composition.tex:14, 20`; `mr/content/sets-functions-relations/functions/functions-relations.tex:79, 94–95, 97, 101`; `mr/content/sets-functions-relations/relations/operations.tex:22, 25, 28, 51, 53, 57, 70`; `mr/content/sets-functions-relations/relations/orders.tex:95`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P014, MR-C001, संचांवरील क्रिया, intersection definition, printed page 11. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P016, MR-C001, दोन संचांचा संयोग, definition and examples, printed page 13. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [गणितशास्त्र परिभाषा कोश](https://shabdakosh.marathi.gov.in/ananya-glossary/9/r) — MR-P023, MR-C013, relation, web lines 365–369. short primary-source observation read; source bytes not preserved
  - [तत्त्वज्ञान व तर्कशास्त्र परिभाषा कोश](https://shabdakosh.marathi.gov.in/ananya-glossary/7/t) — MR-P024, MR-C014, transitive relation / transitivity of equivalence. short primary-source observation read; source bytes not preserved
- **Precise review question:** In the listed formal contexts, should “संवरण / व्युत्क्रम / मर्यादन / सापेक्ष गुणाकार” remain, or should one of “बंदता / प्रतिलोम / निर्बंध / संबंधगुणाकार” replace it? Does the chosen wording preserve the technical sense of closure / inverse / restriction / relative product without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T044 — computability / formula / derivation

- **Chosen wording:** संगणनीयता / सूत्र / निष्पत्ती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** retrospective reconstruction from durable decision record and aligned files.
- **Status/uncertainty:** provisional-sparse-evidence. This choice remains open to correction.
- **Rationale:** Provisional formal-system senses; university proof and predicate-logic context supports grammar but not all exact labels. Distinguish computability संगणनीयता from countability गणनीयता before latter first use.
- **Alternatives considered:** गणनक्षमता / व्युत्पादन.
- **Exact aligned source/target scopes:**

  - OLP-0018 B004–B006, B008–B020: [English](../upstream/content/sets-functions-relations/relations/trees.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/trees.tex)
- **Occurrence records:** `T044-OLP-0018-B004`, `T044-OLP-0018-B005`, `T044-OLP-0018-B006`, `T044-OLP-0018-B008`, `T044-OLP-0018-B009`, `T044-OLP-0018-B010`, `T044-OLP-0018-B011`, `T044-OLP-0018-B012`, `T044-OLP-0018-B013`, `T044-OLP-0018-B014`, `T044-OLP-0018-B015`, `T044-OLP-0018-B016`, `T044-OLP-0018-B017`, `T044-OLP-0018-B018`, `T044-OLP-0018-B019`, `T044-OLP-0018-B020`
- **Literal English line hits:** `upstream/content/sets-functions-relations/relations/trees.tex:14–16, 126`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/relations/trees.tex:125`.
- **Authorities actually checked:**

  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P006, MR-C006, विधानीय तर्कशास्त्र, topics 1–4, printed page 12. visually-read-page-image
  - [Shivaji University BA II Philosophy syllabus](https://www.unishivaji.ac.in/uploads/bosnew/Humanities/BAII%20Philosophy.pdf) — MR-P007, MR-C006, विधेय / संख्यापनीय तर्कशास्त्र आणि संच उपपत्ती, topics 1 and 4, printed page 14. visually-read-page-image
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P021, MR-C011, Predicate logic introduction, section 3.1, printed page 19. visually-read-page-image; legacy-font text extraction not used as Unicode authority
  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P022, MR-C011, Predicate logic continuation and section 3.2, printed page 20. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** Is संगणनीयता the best way to keep computability distinct from गणनीयता for countability?

## T045 — function / mapping

- **Chosen wording:** फलन / संगती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Attested native exposition; function means exactly one value for every domain element, independent of computation method.
- **Alternatives considered:** प्रतिचित्रण; मॅप.
- **Exact aligned source/target scopes:**

  - OLP-0019 B004–B020: [English](../upstream/content/sets-functions-relations/relations/operations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/relations/operations.tex)
  - OLP-0020 B004: [English](../upstream/content/sets-functions-relations/functions/functions.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions.tex)
  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
  - OLP-0026 B005–B013: [English](../upstream/content/sets-functions-relations/functions/partial-functions.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/partial-functions.tex)
  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
  - OLP-0029 B006, B013–B015, B017–B018, B020–B022, B024–B026, B028–B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0030 B006, B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B005–B006, B008–B009, B013, B017–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B005–B007, B009–B010: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0033 B008–B009, B026: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B008–B009, B011–B013, B015, B017, B019–B020: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B006–B007, B010–B012, B015–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B006–B007, B009–B010, B012, B014–B016, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0037 B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
  - OLP-0038 B010, B013–B015, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B008–B010, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B009–B010, B012–B015, B017–B018, B021–B022: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0042 B014: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0048 B007–B009, B011–B015, B021–B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T045-OLP-0019-B004`, `T045-OLP-0019-B005`, `T045-OLP-0019-B006`, `T045-OLP-0019-B007`, `T045-OLP-0019-B008`, `T045-OLP-0019-B009`, `T045-OLP-0019-B010`, `T045-OLP-0019-B011`, `T045-OLP-0019-B012`, `T045-OLP-0019-B013`, `T045-OLP-0019-B014`, `T045-OLP-0019-B015`, `T045-OLP-0019-B016`, `T045-OLP-0019-B017`, `T045-OLP-0019-B018`, `T045-OLP-0019-B019`, `T045-OLP-0019-B020`, `T045-OLP-0027-B004`, `T045-OLP-0027-B005`, `T045-OLP-0027-B016`, `T045-OLP-0028-B005`, `T045-OLP-0028-B006`, `T045-OLP-0028-B007`, `T045-OLP-0020-B004`, `T045-OLP-0021-B004`, `T045-OLP-0021-B005`, `T045-OLP-0021-B006`, `T045-OLP-0021-B007`, `T045-OLP-0021-B008`, `T045-OLP-0021-B009`, `T045-OLP-0021-B010`, `T045-OLP-0021-B011`, `T045-OLP-0021-B012`, `T045-OLP-0021-B013`, `T045-OLP-0021-B014`, `T045-OLP-0021-B015`, `T045-OLP-0021-B016`, `T045-OLP-0021-B017`, `T045-OLP-0021-B018`, `T045-OLP-0021-B019`, `T045-OLP-0021-B020`, `T045-OLP-0022-B004`, `T045-OLP-0022-B005`, `T045-OLP-0022-B006`, `T045-OLP-0022-B007`, `T045-OLP-0022-B008`, `T045-OLP-0022-B009`, `T045-OLP-0022-B010`, `T045-OLP-0022-B011`, `T045-OLP-0022-B012`, `T045-OLP-0022-B013`, `T045-OLP-0022-B014`, `T045-OLP-0022-B015`, `T045-OLP-0022-B016`, `T045-OLP-0022-B017`, `T045-OLP-0022-B018`, `T045-OLP-0022-B019`, `T045-OLP-0023-B005`, `T045-OLP-0023-B006`, `T045-OLP-0023-B007`, `T045-OLP-0023-B008`, `T045-OLP-0023-B009`, `T045-OLP-0023-B010`, `T045-OLP-0023-B011`, `T045-OLP-0023-B012`, `T045-OLP-0023-B013`, `T045-OLP-0023-B014`, `T045-OLP-0023-B015`, `T045-OLP-0023-B016`, `T045-OLP-0024-B004`, `T045-OLP-0024-B005`, `T045-OLP-0024-B006`, `T045-OLP-0024-B007`, `T045-OLP-0024-B008`, `T045-OLP-0024-B009`, `T045-OLP-0024-B010`, `T045-OLP-0024-B011`, `T045-OLP-0024-B012`, `T045-OLP-0024-B013`, `T045-OLP-0024-B014`, `T045-OLP-0024-B015`, `T045-OLP-0024-B016`, `T045-OLP-0024-B017`, `T045-OLP-0024-B018`, `T045-OLP-0024-B019`, `T045-OLP-0024-B020`, `T045-OLP-0024-B021`, `T045-OLP-0024-B022`, `T045-OLP-0024-B023`, `T045-OLP-0024-B024`, `T045-OLP-0024-B025`, `T045-OLP-0024-B026`, `T045-OLP-0024-B027`, `T045-OLP-0025-B004`, `T045-OLP-0025-B005`, `T045-OLP-0025-B006`, `T045-OLP-0025-B007`, `T045-OLP-0025-B008`, `T045-OLP-0025-B009`, `T045-OLP-0025-B010`, `T045-OLP-0025-B011`, `T045-OLP-0026-B005`, `T045-OLP-0026-B006`, `T045-OLP-0026-B007`, `T045-OLP-0026-B008`, `T045-OLP-0026-B009`, `T045-OLP-0026-B010`, `T045-OLP-0026-B011`, `T045-OLP-0026-B012`, `T045-OLP-0026-B013`, `T045-OLP-0029-B006`, `T045-OLP-0029-B013`, `T045-OLP-0029-B014`, `T045-OLP-0029-B015`, `T045-OLP-0029-B017`, `T045-OLP-0029-B018`, `T045-OLP-0029-B020`, `T045-OLP-0029-B021`, `T045-OLP-0029-B022`, `T045-OLP-0029-B024`, `T045-OLP-0029-B025`, `T045-OLP-0029-B026`, `T045-OLP-0029-B028`, `T045-OLP-0029-B029`, `T045-OLP-0029-B030`, `T045-OLP-0029-B031`, `T045-OLP-0029-B032`, `T045-OLP-0029-B033`, `T045-OLP-0029-B034`, `T045-OLP-0029-B035`, `T045-OLP-0030-B006`, `T045-OLP-0030-B008`, `T045-OLP-0030-B009`, `T045-OLP-0031-B005`, `T045-OLP-0031-B006`, `T045-OLP-0031-B008`, `T045-OLP-0031-B009`, `T045-OLP-0031-B013`, `T045-OLP-0031-B017`, `T045-OLP-0031-B018`, `T045-OLP-0032-B005`, `T045-OLP-0032-B006`, `T045-OLP-0032-B007`, `T045-OLP-0032-B009`, `T045-OLP-0032-B010`, `T045-OLP-0033-B008`, `T045-OLP-0033-B009`, `T045-OLP-0033-B026`, `T045-OLP-0034-B008`, `T045-OLP-0034-B009`, `T045-OLP-0034-B011`, `T045-OLP-0034-B012`, `T045-OLP-0034-B013`, `T045-OLP-0034-B015`, `T045-OLP-0034-B017`, `T045-OLP-0034-B019`, `T045-OLP-0034-B020`, `T045-OLP-0035-B006`, `T045-OLP-0035-B007`, `T045-OLP-0035-B010`, `T045-OLP-0035-B011`, `T045-OLP-0035-B012`, `T045-OLP-0035-B015`, `T045-OLP-0035-B016`, `T045-OLP-0036-B006`, `T045-OLP-0036-B007`, `T045-OLP-0036-B009`, `T045-OLP-0036-B010`, `T045-OLP-0036-B012`, `T045-OLP-0036-B014`, `T045-OLP-0036-B015`, `T045-OLP-0036-B016`, `T045-OLP-0036-B018`, `T045-OLP-0037-B008`, `T045-OLP-0037-B010`, `T045-OLP-0038-B010`, `T045-OLP-0038-B013`, `T045-OLP-0038-B014`, `T045-OLP-0038-B015`, `T045-OLP-0038-B017`, `T045-OLP-0039-B008`, `T045-OLP-0039-B009`, `T045-OLP-0039-B010`, `T045-OLP-0039-B018`, `T045-OLP-0040-B009`, `T045-OLP-0040-B010`, `T045-OLP-0040-B012`, `T045-OLP-0040-B013`, `T045-OLP-0040-B014`, `T045-OLP-0040-B015`, `T045-OLP-0040-B017`, `T045-OLP-0040-B018`, `T045-OLP-0040-B021`, `T045-OLP-0040-B022`, `T045-OLP-0042-B014`, `T045-OLP-0048-B007`, `T045-OLP-0048-B008`, `T045-OLP-0048-B009`, `T045-OLP-0048-B011`, `T045-OLP-0048-B012`, `T045-OLP-0048-B013`, `T045-OLP-0048-B014`, `T045-OLP-0048-B015`, `T045-OLP-0048-B021`, `T045-OLP-0048-B022`, `T045-OLP-0048-B023`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:1, 29, 59, 62–63, 79, 84, 102, 111–112, 118, 130, 138, 154, 188, 211`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:1, 47`; `upstream/content/sets-functions-relations/functions/composition.tex:1–2, 10, 14–16, 20, 24, 26, 29–30, 34, 40, 46`; `upstream/content/sets-functions-relations/functions/function-basics.tex:1–2, 13, 15, 18–19, 21, 23, 28–29, 43–45, 50–51, 54, 65, 67, 76, 78, 83–84, 86, 94, 104, 111–112, 115–116, 124, 134–135`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:1–2, 10, 14, 16–18, 23, 29–30, 36, 44–45, 47, 52–54, 58, 64–65, 67, 77, 80, 83, 86, 98–100, 106, 113–114`; `upstream/content/sets-functions-relations/functions/functions-relations.tex:1–3, 12, 15, 19, 21, 24, 33, 35, 39, 42, 49, 61, 64–67, 71–72, 74, 79, 82, 94, 97`; `upstream/content/sets-functions-relations/functions/functions.tex:1–2, 8, 10, 12, 14, 20, 22`; `upstream/content/sets-functions-relations/functions/inverses.tex:1–2, 10, 13–16, 19, 21, 24, 28, 36, 45, 55, 58, 123, 129, 139, 146, 168`; `upstream/content/sets-functions-relations/functions/partial-functions.tex:1–3, 12, 15–17, 21, 26, 31–34, 38, 43, 50–51, 61`; `upstream/content/sets-functions-relations/relations/operations.tex:1`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:1, 19, 21, 71`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:1, 70–74, 84, 100–101`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:1, 89, 95–96, 100, 105, 108, 110, 119–121, 125, 132, 141–142, 166, 168, 174–175, 191, 210, 216, 218, 234, 238, 242, 244, 261, 273–274`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:1, 72`; `upstream/content/sets-functions-relations/size-of-sets/introduction.tex:1`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:1, 28, 36, 155, 157`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:1, 27–29, 34, 38, 207, 209`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:1, 11, 81, 87, 91, 104, 107, 111`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:1, 10, 36, 47–48, 51–53, 59, 62, 81–83, 107, 112`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:1, 43, 52, 56, 90, 92, 95, 103, 107, 109, 124–125`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:1, 36, 39, 42, 51, 53, 87, 89, 92, 99, 109, 111, 120, 122, 128`; `upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:1`; `upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:1, 46`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:1`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:30, 56, 58–59, 74, 79, 95, 105–106, 111, 123–124, 132, 153, 189, 213`; `mr/content/sets-functions-relations/arithmetization/integers.tex:47`; `mr/content/sets-functions-relations/functions/composition.tex:10, 14–17, 19, 25–26, 29–30, 34, 40, 46, 53, 59`; `mr/content/sets-functions-relations/functions/function-basics.tex:14–15, 18, 20–21, 23, 28–30, 42–43, 49–50, 63, 66, 68, 75, 77, 81–82, 84, 93, 103, 111, 113–114, 123, 132–133`; `mr/content/sets-functions-relations/functions/function-kinds.tex:10, 13, 16–17, 22–23, 28–29, 36, 43–44, 46, 51–52, 56, 62–63, 65, 76, 79, 82, 85, 98–100, 104, 111, 113`; `mr/content/sets-functions-relations/functions/functions-relations.tex:12, 15–16, 19–20, 23, 32–33, 35, 37, 48, 59, 63–65, 69, 71, 77, 81, 90, 93–94, 101`; `mr/content/sets-functions-relations/functions/functions.tex:8`; `mr/content/sets-functions-relations/functions/inverses.tex:10, 13–15, 19–20, 23, 28, 35–36, 43, 52–53, 56, 66, 75, 128, 133, 143, 150, 172`; `mr/content/sets-functions-relations/functions/partial-functions.tex:12, 15–17, 21, 26, 32–35, 39, 44, 51–52, 62`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:18, 21, 72`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:29, 68–69, 71, 83, 89, 99–100`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:87, 93–94, 98, 102, 106–107, 117–119, 124, 130, 139, 141, 166, 168, 175, 177, 194, 213, 219, 223, 239, 245, 250, 252, 272, 287–288`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:23, 43, 76, 100`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:30, 37, 155, 157`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:26, 28, 32, 36, 203, 205`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:11, 85, 88, 92, 96, 110, 113, 117`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:10, 36, 46–47, 50, 52, 58, 60, 81–83, 108, 110, 112, 116`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:43, 53, 58, 65, 91, 95–96, 105, 109, 111, 126, 128`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:36, 39, 42, 52, 55, 62, 89, 93, 95, 102–103, 106, 115, 117, 126, 128, 135`; `mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:46`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:76`.
- **Authorities actually checked:**

  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** In the listed formal contexts, should “फलन / संगती” remain, or should one of “प्रतिचित्रण / मॅप” replace it? Does the chosen wording preserve the technical sense of function / mapping without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T046 — domain / codomain / range

- **Chosen wording:** प्रांत / सहप्रांत / व्याप्ती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** All three senses directly distinguished. Choose व्याप्ती consistently; कक्षा is an attested alternative, not an additional set.
- **Alternatives considered:** परिभाषाक्षेत्र / लक्ष्यक्षेत्र / कक्षा.
- **Exact aligned source/target scopes:**

  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0023 B005–B016: [English](../upstream/content/sets-functions-relations/functions/functions-relations.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/functions-relations.tex)
  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
  - OLP-0026 B005–B013: [English](../upstream/content/sets-functions-relations/functions/partial-functions.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/partial-functions.tex)
  - OLP-0031 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0035 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B006, B014–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0038 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
- **Occurrence records:** `T046-OLP-0021-B004`, `T046-OLP-0021-B005`, `T046-OLP-0021-B006`, `T046-OLP-0021-B007`, `T046-OLP-0021-B008`, `T046-OLP-0021-B009`, `T046-OLP-0021-B010`, `T046-OLP-0021-B011`, `T046-OLP-0021-B012`, `T046-OLP-0021-B013`, `T046-OLP-0021-B014`, `T046-OLP-0021-B015`, `T046-OLP-0021-B016`, `T046-OLP-0021-B017`, `T046-OLP-0021-B018`, `T046-OLP-0021-B019`, `T046-OLP-0021-B020`, `T046-OLP-0022-B004`, `T046-OLP-0022-B005`, `T046-OLP-0022-B006`, `T046-OLP-0022-B007`, `T046-OLP-0022-B008`, `T046-OLP-0022-B009`, `T046-OLP-0022-B010`, `T046-OLP-0022-B011`, `T046-OLP-0022-B012`, `T046-OLP-0022-B013`, `T046-OLP-0022-B014`, `T046-OLP-0022-B015`, `T046-OLP-0022-B016`, `T046-OLP-0022-B017`, `T046-OLP-0022-B018`, `T046-OLP-0022-B019`, `T046-OLP-0023-B005`, `T046-OLP-0023-B006`, `T046-OLP-0023-B007`, `T046-OLP-0023-B008`, `T046-OLP-0023-B009`, `T046-OLP-0023-B010`, `T046-OLP-0023-B011`, `T046-OLP-0023-B012`, `T046-OLP-0023-B013`, `T046-OLP-0023-B014`, `T046-OLP-0023-B015`, `T046-OLP-0023-B016`, `T046-OLP-0024-B004`, `T046-OLP-0024-B005`, `T046-OLP-0024-B006`, `T046-OLP-0024-B007`, `T046-OLP-0024-B008`, `T046-OLP-0024-B009`, `T046-OLP-0024-B010`, `T046-OLP-0024-B011`, `T046-OLP-0024-B012`, `T046-OLP-0024-B013`, `T046-OLP-0024-B014`, `T046-OLP-0024-B015`, `T046-OLP-0024-B016`, `T046-OLP-0024-B017`, `T046-OLP-0024-B018`, `T046-OLP-0024-B019`, `T046-OLP-0024-B020`, `T046-OLP-0024-B021`, `T046-OLP-0024-B022`, `T046-OLP-0024-B023`, `T046-OLP-0024-B024`, `T046-OLP-0024-B025`, `T046-OLP-0024-B026`, `T046-OLP-0024-B027`, `T046-OLP-0026-B005`, `T046-OLP-0026-B006`, `T046-OLP-0026-B007`, `T046-OLP-0026-B008`, `T046-OLP-0026-B009`, `T046-OLP-0026-B010`, `T046-OLP-0026-B011`, `T046-OLP-0026-B012`, `T046-OLP-0026-B013`, `T046-OLP-0031-B017`, `T046-OLP-0035-B015`, `T046-OLP-0036-B006`, `T046-OLP-0036-B014`, `T046-OLP-0036-B015`, `T046-OLP-0036-B016`, `T046-OLP-0038-B009`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/function-basics.tex:32, 38, 44–47, 53, 60, 97, 99, 120`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:17, 24, 31, 41, 72, 103, 107`; `upstream/content/sets-functions-relations/functions/functions-relations.tex:36`; `upstream/content/sets-functions-relations/functions/inverses.tex:22`; `upstream/content/sets-functions-relations/functions/partial-functions.tex:26`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:21–23, 77, 82, 91, 123`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:40–41`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:88, 93`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/function-basics.tex:32, 37, 43–45, 50–51, 57–58, 95, 97, 119`; `mr/content/sets-functions-relations/functions/function-kinds.tex:16, 22, 30, 40, 70, 100–101, 104`; `mr/content/sets-functions-relations/functions/functions-relations.tex:34`; `mr/content/sets-functions-relations/functions/inverses.tex:21`; `mr/content/sets-functions-relations/functions/partial-functions.tex:26`; `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:21–22, 77, 84, 94, 131`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:39–40`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:91–92, 97–98, 101`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:110`.
- **Authorities actually checked:**

  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** Are प्रांत, सहप्रांत and व्याप्ती the clearest mutually distinct domain, codomain and range labels, and should कक्षा replace व्याप्ती?

## T047 — argument / input / output / value

- **Chosen wording:** फलसाधक / आदान / प्रदान / मूल्य
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** फलसाधक is explicitly mathematical in the dictionary. Input/output renderings are provisional explanatory vocabulary; not logical युक्तिवाद.
- **Alternatives considered:** चल / निविष्ट / निर्गत.
- **Exact aligned source/target scopes:**

  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
  - OLP-0034 B013, B015: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0040 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T047-OLP-0021-B004`, `T047-OLP-0021-B005`, `T047-OLP-0021-B006`, `T047-OLP-0021-B007`, `T047-OLP-0021-B008`, `T047-OLP-0021-B009`, `T047-OLP-0021-B010`, `T047-OLP-0021-B011`, `T047-OLP-0021-B012`, `T047-OLP-0021-B013`, `T047-OLP-0021-B014`, `T047-OLP-0021-B015`, `T047-OLP-0021-B016`, `T047-OLP-0021-B017`, `T047-OLP-0021-B018`, `T047-OLP-0021-B019`, `T047-OLP-0021-B020`, `T047-OLP-0022-B004`, `T047-OLP-0022-B005`, `T047-OLP-0022-B006`, `T047-OLP-0022-B007`, `T047-OLP-0022-B008`, `T047-OLP-0022-B009`, `T047-OLP-0022-B010`, `T047-OLP-0022-B011`, `T047-OLP-0022-B012`, `T047-OLP-0022-B013`, `T047-OLP-0022-B014`, `T047-OLP-0022-B015`, `T047-OLP-0022-B016`, `T047-OLP-0022-B017`, `T047-OLP-0022-B018`, `T047-OLP-0022-B019`, `T047-OLP-0025-B004`, `T047-OLP-0025-B005`, `T047-OLP-0025-B006`, `T047-OLP-0025-B007`, `T047-OLP-0025-B008`, `T047-OLP-0025-B009`, `T047-OLP-0025-B010`, `T047-OLP-0025-B011`, `T047-OLP-0034-B013`, `T047-OLP-0034-B015`, `T047-OLP-0040-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/composition.tex:28–30, 47`; `upstream/content/sets-functions-relations/functions/function-basics.tex:18–19, 24–25, 33–35, 39, 46–47, 52–53, 58–59, 65–66, 84, 86–88, 95–96, 105, 133, 135`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:17, 24, 41–42, 52–54, 59`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:21, 79, 96, 108, 115, 120`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:21, 76, 93, 105, 110, 116`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/composition.tex:28, 30–31, 47`; `mr/content/sets-functions-relations/functions/function-basics.tex:18–19, 21, 23–24, 33–35, 38, 44–45, 50–51, 56, 63–64, 81–83, 85, 92–93, 102, 107, 132, 134`; `mr/content/sets-functions-relations/functions/function-kinds.tex:16, 23, 41, 51–52, 56–57`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:80`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:77, 102, 106`.
- **Authorities actually checked:**

  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
  - [argument — मराठी शब्दकोश](https://shabdakosh.marathi.gov.in/node/326273) — MR-P031, MR-C020, Sense 2 Math., distinct from reason/argument and Fregean predicate senses; current search extraction personally read 2026-09-04. Short indexed dictionary observation, not an original-byte source. No claim that this attests all input/output vocabulary.
- **Precise review question:** In the listed formal contexts, should “फलसाधक / आदान / प्रदान / मूल्य” remain, or should one of “चल / निविष्ट / निर्गत” replace it? Does the chosen wording preserve the technical sense of argument / input / output / value without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T048 — surjective / surjection

- **Chosen wording:** आच्छादक / आच्छादन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Adjective directly attested; nominal form is a documented extension. Every codomain point attained.
- **Alternatives considered:** ऑन्टू; अधिच्छादक.
- **Exact aligned source/target scopes:**

  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
  - OLP-0029 B006, B013–B015, B018, B021–B022, B024–B026, B028–B030, B032, B034–B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0031 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0033 B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B008, B012, B015, B017, B020: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B014: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0038 B014–B015: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B006, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B009, B014–B015, B017–B018, B022: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T048-OLP-0027-B004`, `T048-OLP-0027-B005`, `T048-OLP-0027-B016`, `T048-OLP-0028-B005`, `T048-OLP-0028-B006`, `T048-OLP-0028-B007`, `T048-OLP-0022-B004`, `T048-OLP-0022-B005`, `T048-OLP-0022-B006`, `T048-OLP-0022-B007`, `T048-OLP-0022-B008`, `T048-OLP-0022-B009`, `T048-OLP-0022-B010`, `T048-OLP-0022-B011`, `T048-OLP-0022-B012`, `T048-OLP-0022-B013`, `T048-OLP-0022-B014`, `T048-OLP-0022-B015`, `T048-OLP-0022-B016`, `T048-OLP-0022-B017`, `T048-OLP-0022-B018`, `T048-OLP-0022-B019`, `T048-OLP-0024-B004`, `T048-OLP-0024-B005`, `T048-OLP-0024-B006`, `T048-OLP-0024-B007`, `T048-OLP-0024-B008`, `T048-OLP-0024-B009`, `T048-OLP-0024-B010`, `T048-OLP-0024-B011`, `T048-OLP-0024-B012`, `T048-OLP-0024-B013`, `T048-OLP-0024-B014`, `T048-OLP-0024-B015`, `T048-OLP-0024-B016`, `T048-OLP-0024-B017`, `T048-OLP-0024-B018`, `T048-OLP-0024-B019`, `T048-OLP-0024-B020`, `T048-OLP-0024-B021`, `T048-OLP-0024-B022`, `T048-OLP-0024-B023`, `T048-OLP-0024-B024`, `T048-OLP-0024-B025`, `T048-OLP-0024-B026`, `T048-OLP-0024-B027`, `T048-OLP-0025-B004`, `T048-OLP-0025-B005`, `T048-OLP-0025-B006`, `T048-OLP-0025-B007`, `T048-OLP-0025-B008`, `T048-OLP-0025-B009`, `T048-OLP-0025-B010`, `T048-OLP-0025-B011`, `T048-OLP-0029-B006`, `T048-OLP-0029-B013`, `T048-OLP-0029-B014`, `T048-OLP-0029-B015`, `T048-OLP-0029-B018`, `T048-OLP-0029-B021`, `T048-OLP-0029-B022`, `T048-OLP-0029-B024`, `T048-OLP-0029-B025`, `T048-OLP-0029-B026`, `T048-OLP-0029-B028`, `T048-OLP-0029-B029`, `T048-OLP-0029-B030`, `T048-OLP-0029-B032`, `T048-OLP-0029-B034`, `T048-OLP-0029-B035`, `T048-OLP-0031-B017`, `T048-OLP-0032-B009`, `T048-OLP-0033-B008`, `T048-OLP-0033-B009`, `T048-OLP-0034-B008`, `T048-OLP-0034-B012`, `T048-OLP-0034-B015`, `T048-OLP-0034-B017`, `T048-OLP-0034-B020`, `T048-OLP-0035-B015`, `T048-OLP-0036-B014`, `T048-OLP-0038-B014`, `T048-OLP-0038-B015`, `T048-OLP-0039-B006`, `T048-OLP-0039-B009`, `T048-OLP-0040-B009`, `T048-OLP-0040-B014`, `T048-OLP-0040-B015`, `T048-OLP-0040-B017`, `T048-OLP-0040-B018`, `T048-OLP-0040-B022`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/composition.tex:59`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:18–19, 22–23, 25, 29–30, 36, 40, 44, 48, 78, 81, 84, 94, 99, 114`; `upstream/content/sets-functions-relations/functions/inverses.tex:52, 92, 98–99, 101, 103, 118, 146`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:71, 75, 92`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:79, 91`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:15, 89, 95, 97, 105, 108, 110, 133, 166–167, 169, 174–176, 190, 195–196, 200, 202, 210, 224, 228, 244–245, 259, 270, 276`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:72, 76–79, 84`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:16, 37`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:27, 34, 38`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:103`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:37, 39, 63, 78, 90, 94, 96, 108, 131–132`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:36, 38, 60, 75, 87, 91, 93, 110, 128, 130`; `upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:13, 46`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:76, 95`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:15`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:15, 19`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:16–17`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:32`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:109`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:109, 112`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:96–97, 111`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:39, 104, 117`; `mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:13, 15, 46, 48`.
- **Authorities actually checked:**

  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
- **Precise review question:** Is आच्छादक / आच्छादन standard and morphologically natural for surjective / surjection?

## T049 — injective / injection

- **Chosen wording:** एकास-एक / एकास-एक फलन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Provisional sense-controlled use: no two different arguments share a value. The broader witness correspondence wording does not itself prove injectivity versus bijectivity.
- **Alternatives considered:** इंजेक्टिव्ह; अंतःक्षेपी.
- **Exact aligned source/target scopes:**

  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
  - OLP-0026 B005–B013: [English](../upstream/content/sets-functions-relations/functions/partial-functions.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/partial-functions.tex)
  - OLP-0029 B014, B029, B032, B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0031 B008, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B007, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0034 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B006–B007, B009, B012, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0037 B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
  - OLP-0038 B014: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0040 B010: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T049-OLP-0022-B004`, `T049-OLP-0022-B005`, `T049-OLP-0022-B006`, `T049-OLP-0022-B007`, `T049-OLP-0022-B008`, `T049-OLP-0022-B009`, `T049-OLP-0022-B010`, `T049-OLP-0022-B011`, `T049-OLP-0022-B012`, `T049-OLP-0022-B013`, `T049-OLP-0022-B014`, `T049-OLP-0022-B015`, `T049-OLP-0022-B016`, `T049-OLP-0022-B017`, `T049-OLP-0022-B018`, `T049-OLP-0022-B019`, `T049-OLP-0024-B004`, `T049-OLP-0024-B005`, `T049-OLP-0024-B006`, `T049-OLP-0024-B007`, `T049-OLP-0024-B008`, `T049-OLP-0024-B009`, `T049-OLP-0024-B010`, `T049-OLP-0024-B011`, `T049-OLP-0024-B012`, `T049-OLP-0024-B013`, `T049-OLP-0024-B014`, `T049-OLP-0024-B015`, `T049-OLP-0024-B016`, `T049-OLP-0024-B017`, `T049-OLP-0024-B018`, `T049-OLP-0024-B019`, `T049-OLP-0024-B020`, `T049-OLP-0024-B021`, `T049-OLP-0024-B022`, `T049-OLP-0024-B023`, `T049-OLP-0024-B024`, `T049-OLP-0024-B025`, `T049-OLP-0024-B026`, `T049-OLP-0024-B027`, `T049-OLP-0025-B004`, `T049-OLP-0025-B005`, `T049-OLP-0025-B006`, `T049-OLP-0025-B007`, `T049-OLP-0025-B008`, `T049-OLP-0025-B009`, `T049-OLP-0025-B010`, `T049-OLP-0025-B011`, `T049-OLP-0026-B005`, `T049-OLP-0026-B006`, `T049-OLP-0026-B007`, `T049-OLP-0026-B008`, `T049-OLP-0026-B009`, `T049-OLP-0026-B010`, `T049-OLP-0026-B011`, `T049-OLP-0026-B012`, `T049-OLP-0026-B013`, `T049-OLP-0029-B014`, `T049-OLP-0029-B029`, `T049-OLP-0029-B032`, `T049-OLP-0029-B035`, `T049-OLP-0031-B008`, `T049-OLP-0031-B017`, `T049-OLP-0032-B007`, `T049-OLP-0032-B010`, `T049-OLP-0034-B009`, `T049-OLP-0036-B006`, `T049-OLP-0036-B007`, `T049-OLP-0036-B009`, `T049-OLP-0036-B012`, `T049-OLP-0036-B018`, `T049-OLP-0037-B008`, `T049-OLP-0037-B010`, `T049-OLP-0038-B014`, `T049-OLP-0040-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/composition.tex:54`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:54–55, 57–58, 60, 64–65, 67, 71, 78, 81, 84, 94, 99, 114`; `upstream/content/sets-functions-relations/functions/inverses.tex:51, 63, 69, 71, 88, 148`; `upstream/content/sets-functions-relations/functions/partial-functions.tex:46`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:18, 20, 28, 38, 61, 143, 145, 147`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:80`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:101, 223, 247, 272, 274`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:111`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:53`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:43`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:42`; `upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:30–31, 50`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/function-kinds.tex:100`; `mr/content/sets-functions-relations/functions/inverses.tex:66`; `mr/content/sets-functions-relations/functions/partial-functions.tex:47`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:15`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:19`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:51, 112`.
- **Authorities actually checked:**

  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** Does एकास-एक reliably express injectivity without being read as bijectivity in these contexts?

## T050 — bijective / bijection / one-to-one correspondence

- **Chosen wording:** एकास-एक व आच्छादक / एकास-एक आच्छादन / एकास-एक संगती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Transparent conjunction of injectivity and surjectivity; avoid claiming that a unique specialized noun was attested.
- **Alternatives considered:** द्विएक; बायजेक्शन.
- **Exact aligned source/target scopes:**

  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
  - OLP-0029 B006, B029–B030, B033–B034: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0035 B006–B007, B010–B012, B015–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B006, B009, B014: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0037 B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
  - OLP-0038 B006–B010: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B006, B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
- **Occurrence records:** `T050-OLP-0027-B004`, `T050-OLP-0027-B005`, `T050-OLP-0027-B016`, `T050-OLP-0028-B005`, `T050-OLP-0028-B006`, `T050-OLP-0028-B007`, `T050-OLP-0022-B004`, `T050-OLP-0022-B005`, `T050-OLP-0022-B006`, `T050-OLP-0022-B007`, `T050-OLP-0022-B008`, `T050-OLP-0022-B009`, `T050-OLP-0022-B010`, `T050-OLP-0022-B011`, `T050-OLP-0022-B012`, `T050-OLP-0022-B013`, `T050-OLP-0022-B014`, `T050-OLP-0022-B015`, `T050-OLP-0022-B016`, `T050-OLP-0022-B017`, `T050-OLP-0022-B018`, `T050-OLP-0022-B019`, `T050-OLP-0024-B004`, `T050-OLP-0024-B005`, `T050-OLP-0024-B006`, `T050-OLP-0024-B007`, `T050-OLP-0024-B008`, `T050-OLP-0024-B009`, `T050-OLP-0024-B010`, `T050-OLP-0024-B011`, `T050-OLP-0024-B012`, `T050-OLP-0024-B013`, `T050-OLP-0024-B014`, `T050-OLP-0024-B015`, `T050-OLP-0024-B016`, `T050-OLP-0024-B017`, `T050-OLP-0024-B018`, `T050-OLP-0024-B019`, `T050-OLP-0024-B020`, `T050-OLP-0024-B021`, `T050-OLP-0024-B022`, `T050-OLP-0024-B023`, `T050-OLP-0024-B024`, `T050-OLP-0024-B025`, `T050-OLP-0024-B026`, `T050-OLP-0024-B027`, `T050-OLP-0025-B004`, `T050-OLP-0025-B005`, `T050-OLP-0025-B006`, `T050-OLP-0025-B007`, `T050-OLP-0025-B008`, `T050-OLP-0025-B009`, `T050-OLP-0025-B010`, `T050-OLP-0025-B011`, `T050-OLP-0029-B006`, `T050-OLP-0029-B029`, `T050-OLP-0029-B030`, `T050-OLP-0029-B033`, `T050-OLP-0029-B034`, `T050-OLP-0035-B006`, `T050-OLP-0035-B007`, `T050-OLP-0035-B010`, `T050-OLP-0035-B011`, `T050-OLP-0035-B012`, `T050-OLP-0035-B015`, `T050-OLP-0035-B016`, `T050-OLP-0036-B006`, `T050-OLP-0036-B009`, `T050-OLP-0036-B014`, `T050-OLP-0037-B008`, `T050-OLP-0037-B010`, `T050-OLP-0038-B006`, `T050-OLP-0038-B007`, `T050-OLP-0038-B008`, `T050-OLP-0038-B009`, `T050-OLP-0038-B010`, `T050-OLP-0039-B006`, `T050-OLP-0039-B008`, `T050-OLP-0039-B009`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/composition.tex:14`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:100–102, 105–106, 108, 112–113, 115`; `upstream/content/sets-functions-relations/functions/inverses.tex:109–110, 123, 127–128, 138, 148–149`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:17, 38, 72, 94, 99`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:14, 27, 31, 36, 40, 48`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:18, 224, 229, 253, 261, 264`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:31, 43, 47–49, 52–53, 69, 87, 92, 97`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:16, 27, 34`; `upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:31, 48`; `upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:14, 44`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/function-kinds.tex:100`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:15`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:19`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:23`; `mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:15`.
- **Authorities actually checked:**

  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** Is the transparent phrase एकास-एक व आच्छादक preferable to a specialist noun such as द्विएक?

## T051 — identity / constant function

- **Chosen wording:** एकरूपता फलन / स्थिर फलन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Constant directly attested. Identity extends the existing relation terminology to x mapped to x.
- **Alternatives considered:** परिचय फलन.
- **Exact aligned source/target scopes:**

  - OLP-0021 B004–B020: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0022 B004–B019: [English](../upstream/content/sets-functions-relations/functions/function-kinds.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-kinds.tex)
  - OLP-0029 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0035 B010: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0038 B013: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0048 B014: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T051-OLP-0021-B004`, `T051-OLP-0021-B005`, `T051-OLP-0021-B006`, `T051-OLP-0021-B007`, `T051-OLP-0021-B008`, `T051-OLP-0021-B009`, `T051-OLP-0021-B010`, `T051-OLP-0021-B011`, `T051-OLP-0021-B012`, `T051-OLP-0021-B013`, `T051-OLP-0021-B014`, `T051-OLP-0021-B015`, `T051-OLP-0021-B016`, `T051-OLP-0021-B017`, `T051-OLP-0021-B018`, `T051-OLP-0021-B019`, `T051-OLP-0021-B020`, `T051-OLP-0022-B004`, `T051-OLP-0022-B005`, `T051-OLP-0022-B006`, `T051-OLP-0022-B007`, `T051-OLP-0022-B008`, `T051-OLP-0022-B009`, `T051-OLP-0022-B010`, `T051-OLP-0022-B011`, `T051-OLP-0022-B012`, `T051-OLP-0022-B013`, `T051-OLP-0022-B014`, `T051-OLP-0022-B015`, `T051-OLP-0022-B016`, `T051-OLP-0022-B017`, `T051-OLP-0022-B018`, `T051-OLP-0022-B019`, `T051-OLP-0029-B017`, `T051-OLP-0035-B010`, `T051-OLP-0038-B013`, `T051-OLP-0048-B014`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:138`; `upstream/content/sets-functions-relations/functions/function-kinds.tex:77, 80`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:70`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:120`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:42`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:132`; `mr/content/sets-functions-relations/functions/function-kinds.tex:76, 79`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:69`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:118`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:43`.
- **Authorities actually checked:**

  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** In the listed formal contexts, should “एकरूपता फलन / स्थिर फलन” remain, or should one of “परिचय फलन” replace it? Does the chosen wording preserve the technical sense of identity / constant function without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T052 — inverse / left inverse / right inverse

- **Chosen wording:** व्युत्क्रम / डावा व्युत्क्रम / उजवा व्युत्क्रम
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Retain earlier inverse-relation term. Left/right composition definitions follow English; not inferred from witness inverse prose.
- **Alternatives considered:** प्रतिलोम.
- **Exact aligned source/target scopes:**

  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
  - OLP-0031 B005–B007, B009, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B006, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0035 B011, B015–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
- **Occurrence records:** `T052-OLP-0024-B004`, `T052-OLP-0024-B005`, `T052-OLP-0024-B006`, `T052-OLP-0024-B007`, `T052-OLP-0024-B008`, `T052-OLP-0024-B009`, `T052-OLP-0024-B010`, `T052-OLP-0024-B011`, `T052-OLP-0024-B012`, `T052-OLP-0024-B013`, `T052-OLP-0024-B014`, `T052-OLP-0024-B015`, `T052-OLP-0024-B016`, `T052-OLP-0024-B017`, `T052-OLP-0024-B018`, `T052-OLP-0024-B019`, `T052-OLP-0024-B020`, `T052-OLP-0024-B021`, `T052-OLP-0024-B022`, `T052-OLP-0024-B023`, `T052-OLP-0024-B024`, `T052-OLP-0024-B025`, `T052-OLP-0024-B026`, `T052-OLP-0024-B027`, `T052-OLP-0031-B005`, `T052-OLP-0031-B006`, `T052-OLP-0031-B007`, `T052-OLP-0031-B009`, `T052-OLP-0031-B017`, `T052-OLP-0032-B006`, `T052-OLP-0032-B009`, `T052-OLP-0035-B011`, `T052-OLP-0035-B015`, `T052-OLP-0035-B016`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/inverses.tex:3, 10, 24, 28, 33, 36–37, 57, 59, 64, 87, 93, 117, 123–124, 127, 138, 140, 145, 149–151, 155–156, 167–168, 172–173`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:48`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:15, 104`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:18, 47, 61, 108`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/inverses.tex:10, 23, 29, 32, 35–36, 55, 57, 63, 66, 89, 95, 121, 127, 143, 149, 154–155, 159, 172, 176–177`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:48`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:14, 109`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:18, 46, 60, 109–110, 112`.
- **Authorities actually checked:**

  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** Do डावा and उजवा व्युत्क्रम keep composition order clear in Marathi prose?

## T053 — composition / partial / total function

- **Chosen wording:** संयोजन / अंशतः फलन / सर्वत्र परिभाषित फलन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Provisional descriptive vocabulary. Full definitions govern composition order and the difference between missing values and multiple values.
- **Alternatives considered:** संघटन / आंशिक फलन / पूर्ण फलन.
- **Exact aligned source/target scopes:**

  - OLP-0025 B004–B011: [English](../upstream/content/sets-functions-relations/functions/composition.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/composition.tex)
  - OLP-0026 B005–B013: [English](../upstream/content/sets-functions-relations/functions/partial-functions.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/partial-functions.tex)
  - OLP-0032 B009: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0034 B019: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B012, B015: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0040 B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T053-OLP-0025-B004`, `T053-OLP-0025-B005`, `T053-OLP-0025-B006`, `T053-OLP-0025-B007`, `T053-OLP-0025-B008`, `T053-OLP-0025-B009`, `T053-OLP-0025-B010`, `T053-OLP-0025-B011`, `T053-OLP-0026-B005`, `T053-OLP-0026-B006`, `T053-OLP-0026-B007`, `T053-OLP-0026-B008`, `T053-OLP-0026-B009`, `T053-OLP-0026-B010`, `T053-OLP-0026-B011`, `T053-OLP-0026-B012`, `T053-OLP-0026-B013`, `T053-OLP-0032-B009`, `T053-OLP-0034-B019`, `T053-OLP-0035-B012`, `T053-OLP-0035-B015`, `T053-OLP-0040-B021`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/composition.tex:3, 10, 15, 23–25, 33–35, 39, 41, 48`; `upstream/content/sets-functions-relations/functions/partial-functions.tex:3, 12, 17, 21, 26, 31, 38, 43, 50–51, 60`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:53`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:104`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:124`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:121`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/composition.tex:10, 15–16, 23, 25, 34, 39, 41, 49`; `mr/content/sets-functions-relations/functions/partial-functions.tex:12, 17, 21, 26, 32–33, 39, 44, 51–52, 62`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:54`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:110`.
- **Authorities actually checked:**

  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
  - [अवकलन व समाकलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/26597/) — MR-P030, MR-C019, Function discussion: domain, codomain and range paragraph; current search extraction personally read 2026-09-04. Original HTML download failed. One-to-one correspondence vocabulary alone does not decide the injective/bijective distinction; OpenLogic definitions govern.
- **Precise review question:** Is संयोजन preferable to संघटन for function composition, and are the partial/total labels idiomatic without losing the definedness distinction?

## T054 — serial relation

- **Chosen wording:** प्रत्येक आदानाशी किमान एक प्रदान जोडणारा
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Source-defined descriptive rendering, not an attested technical noun. For every x in A, at least one y in B is R-related; does not require uniqueness.
- **Alternatives considered:** क्रमिक संबंध; ‘serial’ च्या सामान्य अर्थामुळे संदिग्धता संभवते.
- **Exact aligned source/target scopes:**

  - OLP-0026 B005–B013: [English](../upstream/content/sets-functions-relations/functions/partial-functions.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/partial-functions.tex)
- **Occurrence records:** `T054-OLP-0026-B005`, `T054-OLP-0026-B006`, `T054-OLP-0026-B007`, `T054-OLP-0026-B008`, `T054-OLP-0026-B009`, `T054-OLP-0026-B010`, `T054-OLP-0026-B011`, `T054-OLP-0026-B012`, `T054-OLP-0026-B013`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/partial-functions.tex:64`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Should the edition keep the explicit quantified paraphrase for serial relation, or is there a well-attested concise Marathi technical term?

## T055 — Axiom of Choice

- **Chosen wording:** निवडीचे स्वयंसिद्धक
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested core or explicitly provisional extension; see reason. This choice remains open to correction.
- **Rationale:** Provisional transparent extension of the existing axiom decision. Full English footnote governs the arbitrary family of nonempty fibers and the special cases where choice is unnecessary.
- **Alternatives considered:** चयन स्वयंसिद्ध.
- **Exact aligned source/target scopes:**

  - OLP-0024 B004–B027: [English](../upstream/content/sets-functions-relations/functions/inverses.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/inverses.tex)
- **Occurrence records:** `T055-OLP-0024-B004`, `T055-OLP-0024-B005`, `T055-OLP-0024-B006`, `T055-OLP-0024-B007`, `T055-OLP-0024-B008`, `T055-OLP-0024-B009`, `T055-OLP-0024-B010`, `T055-OLP-0024-B011`, `T055-OLP-0024-B012`, `T055-OLP-0024-B013`, `T055-OLP-0024-B014`, `T055-OLP-0024-B015`, `T055-OLP-0024-B016`, `T055-OLP-0024-B017`, `T055-OLP-0024-B018`, `T055-OLP-0024-B019`, `T055-OLP-0024-B020`, `T055-OLP-0024-B021`, `T055-OLP-0024-B022`, `T055-OLP-0024-B023`, `T055-OLP-0024-B024`, `T055-OLP-0024-B025`, `T055-OLP-0024-B026`, `T055-OLP-0024-B027`
- **Literal English line hits:** `upstream/content/sets-functions-relations/functions/inverses.tex:110`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/functions/inverses.tex:109, 112`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** In the listed formal contexts, should “निवडीचे स्वयंसिद्धक” remain, or should one of “चयन स्वयंसिद्ध” replace it? Does the chosen wording preserve the technical sense of Axiom of Choice without importing an unwanted ordinary sense? Please cite a Marathi mathematical or logic source.

## T056 — enumeration / enumerate

- **Chosen wording:** प्रगणन / प्रगणन करणे
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** Attested core or explicit descriptive extension. This choice remains open to correction.
- **Rationale:** Attested label with source-defined meaning. Arbitrary listing need not be computable.
- **Alternatives considered:** परिगणन; यादीकरण.
- **Exact aligned source/target scopes:**

  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
  - OLP-0029 B005–B024, B029–B032, B034–B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0030 B006, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B005–B007, B010–B012, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B006, B008: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0033 B006–B009, B012, B020, B026: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B007–B010, B013–B015, B018–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B013–B016, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0038 B005–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B009, B012–B013: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B007–B011, B015, B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T056-OLP-0027-B004`, `T056-OLP-0027-B005`, `T056-OLP-0027-B016`, `T056-OLP-0028-B005`, `T056-OLP-0028-B006`, `T056-OLP-0028-B007`, `T056-OLP-0029-B005`, `T056-OLP-0029-B006`, `T056-OLP-0029-B007`, `T056-OLP-0029-B008`, `T056-OLP-0029-B009`, `T056-OLP-0029-B010`, `T056-OLP-0029-B011`, `T056-OLP-0029-B012`, `T056-OLP-0029-B013`, `T056-OLP-0029-B014`, `T056-OLP-0029-B015`, `T056-OLP-0029-B016`, `T056-OLP-0029-B017`, `T056-OLP-0029-B018`, `T056-OLP-0029-B019`, `T056-OLP-0029-B020`, `T056-OLP-0029-B021`, `T056-OLP-0029-B022`, `T056-OLP-0029-B023`, `T056-OLP-0029-B024`, `T056-OLP-0029-B029`, `T056-OLP-0029-B030`, `T056-OLP-0029-B031`, `T056-OLP-0029-B032`, `T056-OLP-0029-B034`, `T056-OLP-0029-B035`, `T056-OLP-0030-B006`, `T056-OLP-0030-B009`, `T056-OLP-0031-B005`, `T056-OLP-0031-B006`, `T056-OLP-0031-B007`, `T056-OLP-0031-B010`, `T056-OLP-0031-B011`, `T056-OLP-0031-B012`, `T056-OLP-0031-B017`, `T056-OLP-0032-B006`, `T056-OLP-0032-B008`, `T056-OLP-0033-B006`, `T056-OLP-0033-B007`, `T056-OLP-0033-B008`, `T056-OLP-0033-B009`, `T056-OLP-0033-B012`, `T056-OLP-0033-B020`, `T056-OLP-0033-B026`, `T056-OLP-0034-B007`, `T056-OLP-0034-B008`, `T056-OLP-0034-B009`, `T056-OLP-0034-B010`, `T056-OLP-0034-B013`, `T056-OLP-0034-B014`, `T056-OLP-0034-B015`, `T056-OLP-0034-B018`, `T056-OLP-0034-B019`, `T056-OLP-0035-B013`, `T056-OLP-0035-B014`, `T056-OLP-0035-B015`, `T056-OLP-0035-B016`, `T056-OLP-0035-B018`, `T056-OLP-0038-B005`, `T056-OLP-0038-B006`, `T056-OLP-0038-B007`, `T056-OLP-0038-B008`, `T056-OLP-0038-B009`, `T056-OLP-0038-B010`, `T056-OLP-0038-B011`, `T056-OLP-0038-B012`, `T056-OLP-0038-B013`, `T056-OLP-0038-B014`, `T056-OLP-0038-B015`, `T056-OLP-0038-B016`, `T056-OLP-0038-B017`, `T056-OLP-0038-B018`, `T056-OLP-0038-B019`, `T056-OLP-0039-B009`, `T056-OLP-0039-B012`, `T056-OLP-0039-B013`, `T056-OLP-0040-B007`, `T056-OLP-0040-B008`, `T056-OLP-0040-B009`, `T056-OLP-0040-B010`, `T056-OLP-0040-B011`, `T056-OLP-0040-B015`, `T056-OLP-0040-B021`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:3, 11, 14, 39–40, 47, 60, 66, 90–91, 96, 106`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:3, 11, 14, 17, 27–28, 31, 35–37, 42, 44, 46, 48–49, 52, 55–56, 60, 65, 69, 74, 76–77, 84, 87–88, 95–96, 104, 115, 131–132, 137, 143, 190, 215, 228, 240`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:85`; `upstream/content/sets-functions-relations/size-of-sets/introduction.tex:21`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:35, 62, 99, 101`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:14, 16, 23, 40, 49, 71, 95`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:18, 27, 32, 47, 67, 76, 108`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:30, 32, 35–36, 38, 45, 50, 80`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:29–30, 34–35, 37–38, 44, 49, 77`; `upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:11, 13–14`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:14, 59, 80, 91–93, 110–111`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:11, 15, 34, 36, 38–39, 45–46, 57, 63, 68, 71, 88, 90, 94`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:11, 14, 17, 28–29, 32, 36, 40, 42, 44, 46, 48–52, 54–56, 59, 63, 68, 72–73, 75, 81, 85–86, 93–94, 101, 113, 117, 119, 129–130, 135, 193, 217, 233, 247`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:89`; `mr/content/sets-functions-relations/size-of-sets/introduction.tex:22`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:60, 99, 101`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:33`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:14–15, 24, 44, 53, 74, 101`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:18, 26, 32, 46, 66, 76, 109, 112`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:29–32, 34–35, 38–39, 45, 51, 81, 129–130`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:28, 30–31, 33–34, 37–38, 44, 50, 79, 130`; `mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:11–12, 14`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:14, 60, 93–95, 112–113`.
- **Authorities actually checked:**

  - [भौतिकशास्त्र पारिभाषिक शब्दावली — enumeration](https://shabdakosh.marathi.gov.in/ananya-glossary/33/e) — MR-P033, MR-C021, Entries enumeration and enumerate, personally read in current web-search extraction 2026-09-04. Short indexed lexical observation; no original HTML hash, no independent attestation of effective enumeration.
- **Precise review question:** Does प्रगणन naturally cover arbitrary mathematical listings that need not be computable, or would परिगणन be less misleading?

## T057 — enumerable / countable / uncountable

- **Chosen wording:** गणनीय / गणनीय / अगणनीय
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** Attested core or explicit descriptive extension. This choice remains open to correction.
- **Rationale:** In this edition, गणनीय includes finite and empty sets as specified by OpenLogic. Native witness discusses the infinite case; do not import that narrower convention.
- **Alternatives considered:** मोजता येण्याजोगा; काउंटेबल.
- **Exact aligned source/target scopes:**

  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
  - OLP-0029 B005, B008–B009, B012, B016, B021–B023, B028, B033, B035: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0030 B007, B010–B012: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B011, B013–B017: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0033 B005–B009, B011–B012, B019–B022, B025–B026: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B006–B007, B009–B010, B014–B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0035 B013–B016, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B010, B013–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0038 B005–B007, B011–B012, B014, B018–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0039 B005–B009, B011, B013–B015, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B006–B007, B010–B011, B016–B023: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0044 B006: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
- **Occurrence records:** `T057-OLP-0027-B004`, `T057-OLP-0027-B005`, `T057-OLP-0027-B016`, `T057-OLP-0028-B005`, `T057-OLP-0028-B006`, `T057-OLP-0028-B007`, `T057-OLP-0029-B005`, `T057-OLP-0029-B008`, `T057-OLP-0029-B009`, `T057-OLP-0029-B012`, `T057-OLP-0029-B016`, `T057-OLP-0029-B021`, `T057-OLP-0029-B022`, `T057-OLP-0029-B023`, `T057-OLP-0029-B028`, `T057-OLP-0029-B033`, `T057-OLP-0029-B035`, `T057-OLP-0030-B007`, `T057-OLP-0030-B010`, `T057-OLP-0030-B011`, `T057-OLP-0030-B012`, `T057-OLP-0031-B011`, `T057-OLP-0031-B013`, `T057-OLP-0031-B014`, `T057-OLP-0031-B015`, `T057-OLP-0031-B016`, `T057-OLP-0031-B017`, `T057-OLP-0033-B005`, `T057-OLP-0033-B006`, `T057-OLP-0033-B007`, `T057-OLP-0033-B008`, `T057-OLP-0033-B009`, `T057-OLP-0033-B011`, `T057-OLP-0033-B012`, `T057-OLP-0033-B019`, `T057-OLP-0033-B020`, `T057-OLP-0033-B021`, `T057-OLP-0033-B022`, `T057-OLP-0033-B025`, `T057-OLP-0033-B026`, `T057-OLP-0034-B006`, `T057-OLP-0034-B007`, `T057-OLP-0034-B009`, `T057-OLP-0034-B010`, `T057-OLP-0034-B014`, `T057-OLP-0034-B015`, `T057-OLP-0034-B016`, `T057-OLP-0034-B017`, `T057-OLP-0034-B018`, `T057-OLP-0034-B019`, `T057-OLP-0034-B020`, `T057-OLP-0034-B021`, `T057-OLP-0035-B013`, `T057-OLP-0035-B014`, `T057-OLP-0035-B015`, `T057-OLP-0035-B016`, `T057-OLP-0035-B018`, `T057-OLP-0036-B010`, `T057-OLP-0036-B013`, `T057-OLP-0036-B014`, `T057-OLP-0036-B015`, `T057-OLP-0036-B016`, `T057-OLP-0038-B005`, `T057-OLP-0038-B006`, `T057-OLP-0038-B007`, `T057-OLP-0038-B011`, `T057-OLP-0038-B012`, `T057-OLP-0038-B014`, `T057-OLP-0038-B018`, `T057-OLP-0038-B019`, `T057-OLP-0039-B005`, `T057-OLP-0039-B006`, `T057-OLP-0039-B007`, `T057-OLP-0039-B008`, `T057-OLP-0039-B009`, `T057-OLP-0039-B011`, `T057-OLP-0039-B013`, `T057-OLP-0039-B014`, `T057-OLP-0039-B015`, `T057-OLP-0039-B018`, `T057-OLP-0040-B006`, `T057-OLP-0040-B007`, `T057-OLP-0040-B010`, `T057-OLP-0040-B011`, `T057-OLP-0040-B016`, `T057-OLP-0040-B017`, `T057-OLP-0040-B018`, `T057-OLP-0040-B019`, `T057-OLP-0040-B020`, `T057-OLP-0040-B021`, `T057-OLP-0040-B022`, `T057-OLP-0040-B023`, `T057-OLP-0044-B006`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:44`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:11, 58–59, 61, 65, 78, 80, 127, 132`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:11, 31, 64, 84, 114–115, 165, 173, 181–182, 209, 253, 259, 269–272`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:58, 63–64, 70–71, 85, 94, 96, 107`; `upstream/content/sets-functions-relations/size-of-sets/introduction.tex:24, 26`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:22–24, 115`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:22, 26, 53, 143, 149`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:71, 83, 88, 96, 100–103`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:24–25, 49, 82–83, 103, 126`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:24–26, 48, 79–80, 100, 123`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:69, 115, 119, 123`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:124, 130`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:63, 166, 175, 183, 185, 282, 286`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:15`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:15`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:13, 83, 111`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:14`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:14, 43`; `mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:11, 45`.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P032, MR-C004, Current search extraction, personally read 2026-09-04: paragraphs headed infinite sets and cardinality. Same previously indexed source, new actual consultation. The witness's positive-natural-number convention and its restriction to infinite countable sets do not replace OpenLogic conventions. Missing/corrupt mathematical glyphs and source historical assertions are not imported. Original HTML remains unavailable.
- **Precise review question:** Can गणनीय include finite and empty sets here without readers importing the checked witness's narrower countably-infinite convention?

## T058 — size / cardinality / equinumerous

- **Chosen wording:** आकारमान / संचांक / तुल्यबल
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** Attested core or explicit descriptive extension. This choice remains open to correction.
- **Rationale:** Cardinality and equinumerosity are attested; आकारमान is a contextual size rendering, not geometric shape.
- **Alternatives considered:** प्रमाण / कार्डिनॅलिटी / समसंख्य.
- **Exact aligned source/target scopes:**

  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
  - OLP-0035 B005–B013, B015–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0036 B005–B012, B014–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0037 B005–B008, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
- **Occurrence records:** `T058-OLP-0027-B004`, `T058-OLP-0027-B005`, `T058-OLP-0027-B016`, `T058-OLP-0028-B005`, `T058-OLP-0028-B006`, `T058-OLP-0028-B007`, `T058-OLP-0035-B005`, `T058-OLP-0035-B006`, `T058-OLP-0035-B007`, `T058-OLP-0035-B008`, `T058-OLP-0035-B009`, `T058-OLP-0035-B010`, `T058-OLP-0035-B011`, `T058-OLP-0035-B012`, `T058-OLP-0035-B013`, `T058-OLP-0035-B015`, `T058-OLP-0035-B016`, `T058-OLP-0035-B017`, `T058-OLP-0035-B018`, `T058-OLP-0036-B005`, `T058-OLP-0036-B006`, `T058-OLP-0036-B007`, `T058-OLP-0036-B008`, `T058-OLP-0036-B009`, `T058-OLP-0036-B010`, `T058-OLP-0036-B011`, `T058-OLP-0036-B012`, `T058-OLP-0036-B014`, `T058-OLP-0036-B015`, `T058-OLP-0036-B016`, `T058-OLP-0037-B005`, `T058-OLP-0037-B006`, `T058-OLP-0037-B007`, `T058-OLP-0037-B008`, `T058-OLP-0037-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:2–3, 11, 15, 17, 19–20`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:2–3, 13, 15–16, 30`; `upstream/content/sets-functions-relations/size-of-sets/introduction.tex:2, 16`; `upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:11, 15, 18, 47–48`; `upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:2, 8, 31, 33`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:11, 14, 16, 19, 27, 37`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:11, 13, 15–16, 29, 35, 39`; `mr/content/sets-functions-relations/size-of-sets/introduction.tex:16`; `mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:11, 14–17, 45–46`; `mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex:8`.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P032, MR-C004, Current search extraction, personally read 2026-09-04: paragraphs headed infinite sets and cardinality. Same previously indexed source, new actual consultation. The witness's positive-natural-number convention and its restriction to infinite countable sets do not replace OpenLogic conventions. Missing/corrupt mathematical glyphs and source historical assertions are not imported. Original HTML remains unavailable.
- **Precise review question:** Are आकारमान, संचांक and तुल्यबल standard and sufficiently distinct in the listed contexts?

## T059 — actual infinity

- **Chosen wording:** प्रत्यक्ष अस्तित्वातील अनंतता
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** Attested core or explicit descriptive extension. This choice remains open to correction.
- **Rationale:** Provisional descriptive rendering of the historical philosophical distinction; not a claim about real-valued quantities.
- **Alternatives considered:** वास्तविक अनंत.
- **Exact aligned source/target scopes:**

  - OLP-0027 B004–B005, B016: [English](../upstream/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/size-of-sets-complete.tex)
  - OLP-0028 B005–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/introduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/introduction.tex)
- **Occurrence records:** `T059-OLP-0027-B004`, `T059-OLP-0027-B005`, `T059-OLP-0027-B016`, `T059-OLP-0028-B005`, `T059-OLP-0028-B006`, `T059-OLP-0028-B007`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/introduction.tex:15`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Does प्रत्यक्ष अस्तित्वातील अनंतता accurately name actual infinity without suggesting real-number infinity?

## T060 — ceiling function

- **Chosen wording:** ऊर्ध्व पूर्णांक फलन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional-not-attested; open to correction. This choice remains open to correction.
- **Rationale:** Provisional descriptive rendering. The accompanying OpenLogic definition—least integer not below x—governs the sense. No Marathi specialist source was checked or found for this exact label before first use.
- **Alternatives considered:** लघुतम उच्च पूर्णांक फलन; सीलिंग फलन.
- **Exact aligned source/target scopes:**

  - OLP-0029 B020: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0038 B017: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
- **Occurrence records:** `T060-OLP-0029-B020`, `T060-OLP-0038-B017`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:141`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Is ऊर्ध्व पूर्णांक फलन an idiomatic name for the least-integer-not-below-x function, or is लघुतम उच्च पूर्णांक फलन preferable?

## T061 — recursive / recursively defined

- **Chosen wording:** पुनरावर्ती / पुनरावर्ती रीतीने परिभाषित
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional-not-attested; open to correction. This choice remains open to correction.
- **Rationale:** Provisional compositional rendering for a definition whose next value is selected from earlier values. No exact Marathi recursion terminology source was checked before first use; the frozen construction governs meaning.
- **Alternatives considered:** पुनरावृत्तीने परिभाषित; आवर्ती व्याख्या.
- **Exact aligned source/target scopes:**

  - OLP-0029 B031: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0048 B021: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T061-OLP-0029-B031`, `T061-OLP-0048-B021`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:196–197`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:197`; `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:239`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Does पुनरावर्ती describe recursive definition here without being mistaken for periodic recurrence?

## T062 — initial segment

- **Chosen wording:** आरंभीचा खंड / सांत आरंभीचा खंड
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional-not-attested; open to correction. This choice remains open to correction.
- **Rationale:** Provisional descriptive rendering for Nat or a finite set beginning at its least endpoint. No exact specialist Marathi attestation was checked before first use; displayed domains preserve the mathematical meaning.
- **Alternatives considered:** प्रारंभिक खंड; आरंभखंड.
- **Exact aligned source/target scopes:**

  - OLP-0029 B006, B030–B031, B033–B034: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
  - OLP-0035 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex)
  - OLP-0038 B006–B007, B009: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0045 B006: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0047 B024, B028: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T062-OLP-0029-B006`, `T062-OLP-0029-B030`, `T062-OLP-0029-B031`, `T062-OLP-0029-B033`, `T062-OLP-0029-B034`, `T062-OLP-0035-B015`, `T062-OLP-0038-B006`, `T062-OLP-0038-B007`, `T062-OLP-0038-B009`, `T062-OLP-0045-B006`, `T062-OLP-0047-B024`, `T062-OLP-0047-B028`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:163, 185`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:28`; `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:18`; `upstream/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:94`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:160, 183`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:27`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:40`; `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:92, 99, 101`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Is आरंभीचा खंड standard for an initial segment of the natural numbers?

## T063 — enumeration with/without repetitions; redundant enumeration

- **Chosen wording:** पुनरुक्ती असलेले / पुनरुक्ती नसलेले प्रगणन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested headword with provisional descriptive qualifiers; open to correction. This choice remains open to correction.
- **Rationale:** The headword प्रगणन is attested; the repetition qualifiers are transparent descriptive extensions. The construction allows repeated values unless injectivity is explicitly required.
- **Alternatives considered:** पुनरावृत्तीसह / पुनरावृत्तीविना प्रगणन; अतिरिक्त नोंदी असलेले प्रगणन.
- **Exact aligned source/target scopes:**

  - OLP-0029 B009–B011, B014, B029: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability.tex)
- **Occurrence records:** `T063-OLP-0029-B009`, `T063-OLP-0029-B010`, `T063-OLP-0029-B011`, `T063-OLP-0029-B014`, `T063-OLP-0029-B029`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/enumerability.tex:48, 69, 214, 221`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:68`.
- **Authorities actually checked:**

  - [भौतिकशास्त्र पारिभाषिक शब्दावली — enumeration](https://shabdakosh.marathi.gov.in/ananya-glossary/33/e) — MR-P033, MR-C021, Entries enumeration and enumerate, personally read in current web-search extraction 2026-09-04. Short indexed lexical observation; no original HTML hash, no independent attestation of effective enumeration.
- **Precise review question:** Are पुनरुक्ती असलेले and पुनरुक्ती नसलेले the clearest qualifiers for enumerations with and without repeated values?

## T064 — Cantor's zig-zag method

- **Chosen wording:** कँटर यांची नागमोडी पद्धत
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional descriptive extension; open to correction. This choice remains open to correction.
- **Rationale:** Cantor's surname follows the existing Marathi chapter spelling. नागमोडी is a provisional descriptive rendering of the diagonal traversal pattern; MR-P032 supports Cantor/set-theory register but does not attest this method name.
- **Alternatives considered:** कँटर यांची तिरपी प्रगणन पद्धत; कँटर यांची कर्णरेषीय पद्धत.
- **Exact aligned source/target scopes:**

  - OLP-0030 B005–B006, B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B005–B006: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B006: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
- **Occurrence records:** `T064-OLP-0030-B005`, `T064-OLP-0030-B006`, `T064-OLP-0030-B008`, `T064-OLP-0030-B009`, `T064-OLP-0031-B005`, `T064-OLP-0031-B006`, `T064-OLP-0032-B006`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:13`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:11, 59, 109`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:11, 59`.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P032, MR-C004, Current search extraction, personally read 2026-09-04: paragraphs headed infinite sets and cardinality. Same previously indexed source, new actual consultation. The witness's positive-natural-number convention and its restriction to infinite countable sets do not replace OpenLogic conventions. Missing/corrupt mathematical glyphs and source historical assertions are not imported. Original HTML remains unavailable.
- **Precise review question:** Does नागमोडी पद्धत naturally identify Cantor's diagonal zig-zag traversal, or would a term built from तिरपी or कर्णरेषीय make the mathematical path clearer?

## T065 — array / row / column / axis

- **Chosen wording:** सरणी / ओळ / स्तंभ / अक्ष
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional compositional vocabulary; open to correction. This choice remains open to correction.
- **Rationale:** Provisional mathematical-layout vocabulary. स्तंभ and अक्ष are established general mathematical terms; सरणी and ओळ are chosen for the displayed two-dimensional arrangement. The witness supports mathematical register but was not checked for the exact array phrase.
- **Alternatives considered:** मांडणी / पंक्ती / रकाना / दिशा; द्विमितीय सारणी / पंक्ती / स्तंभ / अक्ष.
- **Exact aligned source/target scopes:**

  - OLP-0030 B006, B008–B009: [English](../upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/zig-zag.tex)
  - OLP-0031 B005–B006: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B006: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0033 B013, B020, B024: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0039 B012, B014, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
- **Occurrence records:** `T065-OLP-0030-B006`, `T065-OLP-0030-B008`, `T065-OLP-0030-B009`, `T065-OLP-0031-B005`, `T065-OLP-0031-B006`, `T065-OLP-0032-B006`, `T065-OLP-0033-B013`, `T065-OLP-0033-B020`, `T065-OLP-0033-B024`, `T065-OLP-0039-B012`, `T065-OLP-0039-B014`, `T065-OLP-0039-B017`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:66, 68, 75, 80, 107–109, 134–135, 138, 140, 146`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:63, 65, 72, 89, 106, 141–143, 182–183, 185, 187, 193, 197`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:16, 25, 28, 33, 37, 42, 46, 48, 52, 68, 70, 72, 74, 76`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:14–15, 30–32, 43`; `upstream/content/sets-functions-relations/size-of-sets/zig-zag.tex:21, 23, 35, 38–40, 43, 57, 75, 91–92, 95, 107`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:64–66, 79, 107–108, 135–136, 139`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:59, 85, 101, 137, 139, 179–180, 182, 193`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:15, 53`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:14–15, 30–31, 42`; `mr/content/sets-functions-relations/size-of-sets/zig-zag.tex:21, 37, 39–40, 73–74, 93–94`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
- **Precise review question:** In the displayed grid and higher-dimensional generalization, are सरणी, ओळ, स्तंभ and अक्ष the standard mutually distinct Marathi layout terms?

## T066 — rational number / non-negative rational number

- **Chosen wording:** परिमेय संख्या / ऋणेतर परिमेय संख्या
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested headword with compositional qualifier; open to correction. This choice remains open to correction.
- **Rationale:** परिमेय संख्या is directly present in the inspected mathematics page. ऋणेतर is the already adopted zero-inclusive modifier and preserves the exercise's non-negative scope.
- **Alternatives considered:** परिमेय अंक / अऋण परिमेय संख्या.
- **Exact aligned source/target scopes:**

  - OLP-0031 B010–B011: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0043 B004–B008: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0044 B005–B007, B011–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B003–B008, B010–B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B006, B008–B012: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B019–B025, B027–B028: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B008–B009, B011–B012, B014, B020–B022: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T066-OLP-0031-B010`, `T066-OLP-0031-B011`, `T066-OLP-0043-B004`, `T066-OLP-0043-B005`, `T066-OLP-0043-B006`, `T066-OLP-0043-B007`, `T066-OLP-0043-B008`, `T066-OLP-0044-B005`, `T066-OLP-0044-B006`, `T066-OLP-0044-B007`, `T066-OLP-0044-B011`, `T066-OLP-0044-B012`, `T066-OLP-0044-B013`, `T066-OLP-0045-B003`, `T066-OLP-0045-B004`, `T066-OLP-0045-B005`, `T066-OLP-0045-B006`, `T066-OLP-0045-B007`, `T066-OLP-0045-B008`, `T066-OLP-0045-B010`, `T066-OLP-0045-B011`, `T066-OLP-0045-B012`, `T066-OLP-0046-B006`, `T066-OLP-0046-B008`, `T066-OLP-0046-B009`, `T066-OLP-0046-B010`, `T066-OLP-0046-B011`, `T066-OLP-0046-B012`, `T066-OLP-0047-B019`, `T066-OLP-0047-B020`, `T066-OLP-0047-B021`, `T066-OLP-0047-B022`, `T066-OLP-0047-B023`, `T066-OLP-0047-B024`, `T066-OLP-0047-B025`, `T066-OLP-0047-B027`, `T066-OLP-0047-B028`, `T066-OLP-0048-B008`, `T066-OLP-0048-B009`, `T066-OLP-0048-B011`, `T066-OLP-0048-B012`, `T066-OLP-0048-B014`, `T066-OLP-0048-B020`, `T066-OLP-0048-B021`, `T066-OLP-0048-B022`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:58`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:16, 21`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:22, 80`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:67, 71`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:54–56`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:126, 128, 143, 183, 185`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:15–16, 18, 21, 26, 87, 92`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:14, 16, 21, 42, 52, 62`; `mr/content/sets-functions-relations/arithmetization/reals.tex:12, 16, 19, 21, 27, 31, 79–80, 82, 86–87, 91, 95–96, 99`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:16, 33, 37–38, 45, 51, 53, 59, 71, 88`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:66, 70`.
- **Authorities actually checked:**

  - [गणित, इयत्ता आठवी](https://books.ebalbharati.in/pdfs/801020004.pdf) — MR-P027, MR-C017, PDF page 12, printed page 2. Personally read recovered OCR and actual page image; historical consultation not adopted
- **Precise review question:** Is ऋणेतर the clearest zero-inclusive modifier for non-negative rationals in current Marathi mathematics usage?

## T067 — pairing function / encode / code / decode

- **Chosen wording:** जोडीकरण फलन / सांकेतीकरण करणे / संकेतांक / विसांकेतीकरण करणे
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional compositional vocabulary; open to correction. This choice remains open to correction.
- **Rationale:** जोडी and फलन are evidence-backed components; the coding forms are provisional transparent extensions for an injective numeric representation, not cryptographic encryption. The source definition governs injectivity and inverse-domain qualifications.
- **Alternatives considered:** युग्मीकरण फलन / कूटबद्ध करणे / कूट / उकल करणे; पेअरिंग फलन / एन्कोड / कोड / डीकोड.
- **Exact aligned source/target scopes:**

  - OLP-0031 B004–B009, B017–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
  - OLP-0032 B005–B010: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0042 B005: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B005: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
- **Occurrence records:** `T067-OLP-0031-B004`, `T067-OLP-0031-B005`, `T067-OLP-0031-B006`, `T067-OLP-0031-B007`, `T067-OLP-0031-B008`, `T067-OLP-0031-B009`, `T067-OLP-0031-B017`, `T067-OLP-0031-B018`, `T067-OLP-0032-B005`, `T067-OLP-0032-B006`, `T067-OLP-0032-B007`, `T067-OLP-0032-B008`, `T067-OLP-0032-B009`, `T067-OLP-0032-B010`, `T067-OLP-0042-B005`, `T067-OLP-0043-B005`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:11, 91, 96–98, 102`; `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:10, 48, 51, 53–55, 59, 62, 107, 112`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:11, 96, 102–104`; `mr/content/sets-functions-relations/size-of-sets/pairing.tex:10, 47, 50, 52, 54, 58, 60, 108, 112`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P017, MR-C001, ordered-pair discussion, first half of page, printed page 81. visually-read-page-image
  - [फलन — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/27548/) — MR-P029, MR-C018, Opening paragraph, current web-search extraction personally read 2026-09-04. Origin download failed with ConnectionError; web open had 502. This is a short observed extraction, not preserved original HTML. Later article mathematics and its inverse wording were not adopted as authoritative.
- **Precise review question:** Do जोडीकरण, सांकेतीकरण, संकेतांक and विसांकेतीकरण clearly describe an injective numerical coding without suggesting cryptography, and is the partial inverse qualification natural?

## T068 — cofinite / complement

- **Chosen wording:** सांत-पूरक / पूरक संच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional definition-controlled term; open to correction. This choice remains open to correction.
- **Rationale:** सांत-पूरक is a provisional definition-transparent compound: the complement in Nat is finite. Checked set sources support finite-set and subset grammar but do not attest the exact cofinite label.
- **Alternatives considered:** सांतपूरक / संचपूरक; सहसांत / पूरक.
- **Exact aligned source/target scopes:**

  - OLP-0031 B015: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T068-OLP-0031-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:92–95`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/pairing.tex:93, 96`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P003, MR-C001, संचांचे प्रकार table, empty/finite/infinite rows, printed page 4. visually-read-page-image
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P005, MR-C001, उपसंच, definition and first example, printed page 7. visually-read-page-image
- **Precise review question:** Is सांत-पूरक an established or readily intelligible term for a set whose complement in the ambient set is finite, and should the hyphen be retained?

## T069 — truth table / truth function

- **Chosen wording:** सत्यताकोष्टक / सत्यता-फलन
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** attested register with provisional compound; open to correction. This choice remains open to correction.
- **Rationale:** The inspected logic textbook directly supports truth-table and truth-value register. सत्यता-फलन is a compositional extension for functions from binary rows to a truth value; validity terminology remains separate.
- **Alternatives considered:** सत्यतासारणी / सत्यफलन; सत्य-मूल्य कोष्टक / सत्य-मूल्य फलन.
- **Exact aligned source/target scopes:**

  - OLP-0031 B013: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T069-OLP-0031-B013`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:81, 83`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/pairing.tex:81, 83`.
- **Authorities actually checked:**

  - [तर्कशास्त्र, इयत्ता बारावी](https://ebooks.ebalbharati.in/pdfs/1201010508.pdf) — MR-P020, MR-C011, Short truth table, section 1.3 continuation and 1.4, printed page 2. visually-read-page-image; legacy-font text extraction not used as Unicode authority
- **Precise review question:** Should truth table and truth function share the सत्यता stem, and is कोष्टक preferable to सारणी in contemporary Marathi logic teaching?

## T070 — enumerable union of enumerable sets

- **Chosen wording:** गणनीय इतक्या गणनीय संचांचा संयोग
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional ambiguity-avoiding paraphrase; open to correction. This choice remains open to correction.
- **Rationale:** Expanded wording avoids reading enumerable as a property only of the member sets: both the index family and each set are countable. The union term is attested; the full phrase is source-defined and provisional.
- **Alternatives considered:** गणनीय संचकुलाचा गणनीय संयोग; गणनीय संयोग.
- **Exact aligned source/target scopes:**

  - OLP-0031 B016: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T070-OLP-0031-B016`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P032, MR-C004, Current search extraction, personally read 2026-09-04: paragraphs headed infinite sets and cardinality. Same previously indexed source, new actual consultation. The witness's positive-natural-number convention and its restriction to infinite countable sets do not replace OpenLogic conventions. Missing/corrupt mathematical glyphs and source historical assertions are not imported. Original HTML remains unavailable.
  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P016, MR-C001, दोन संचांचा संयोग, definition and examples, printed page 13. visually-read-page-image
- **Precise review question:** Does गणनीय इतक्या गणनीय संचांचा संयोग unambiguously state that both the index set and every indexed set are countable?

## T071 — triangular number

- **Chosen wording:** त्रिकोणी संख्या
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional compositional term; open to correction. This choice remains open to correction.
- **Rationale:** Provisional transparent geometric compound for the source-defined sums 0, 1, 3, 6 and k(k+1)/2. The checked mathematics page supports native number exposition but was not checked for this exact specialist label.
- **Alternatives considered:** त्रिकोण संख्या; त्रिभुजी संख्या.
- **Exact aligned source/target scopes:**

  - OLP-0031 B006: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing.tex)
- **Occurrence records:** `T071-OLP-0031-B006`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/pairing.tex:32–33`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/pairing.tex:33–34`.
- **Authorities actually checked:**

  - [गणित भाग १, इयत्ता नववी](https://books.ebalbharati.in/pdfs/901000608.pdf) — MR-P001, MR-C001, संच (Sets), opening definition and membership notation, printed page 2. visually-read-page-image
- **Precise review question:** Is त्रिकोणी संख्या the established Marathi name for k(k+1)/2, or is another geometric form more idiomatic?

## T072 — positive / odd / even / factor / power / exponent

- **Chosen wording:** धन / विषम / सम / गुणक / घात / घातांक
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional source-controlled mathematical vocabulary; open to correction. This choice remains open to correction.
- **Rationale:** Source-defined elementary number vocabulary used in the alternative pairing construction. The formulas determine the odd-number, factor and exponent senses. No exact Marathi authority was newly checked for this grouped vocabulary before current use, so it remains explicitly open to correction.
- **Alternatives considered:** धन / विषम / सम / अवयव / घात / घातांक; सकारात्मक / विषम / सम / गुणनखंड / कोटी / घातांक.
- **Exact aligned source/target scopes:**

  - OLP-0032 B006, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex)
  - OLP-0033 B007–B008: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B011: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0038 B010, B013, B015, B017: [English](../upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex)
  - OLP-0040 B013: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0043 B006: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0044 B007–B009: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0048 B008–B009, B013, B015: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T072-OLP-0032-B006`, `T072-OLP-0032-B010`, `T072-OLP-0033-B007`, `T072-OLP-0033-B008`, `T072-OLP-0034-B011`, `T072-OLP-0038-B010`, `T072-OLP-0038-B013`, `T072-OLP-0038-B015`, `T072-OLP-0038-B017`, `T072-OLP-0040-B013`, `T072-OLP-0043-B006`, `T072-OLP-0044-B007`, `T072-OLP-0044-B008`, `T072-OLP-0044-B009`, `T072-OLP-0048-B008`, `T072-OLP-0048-B009`, `T072-OLP-0048-B013`, `T072-OLP-0048-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:23, 66–67, 85, 113, 150, 152`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:55`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:24, 60, 67`; `upstream/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:53, 72, 90, 116, 120–121`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:20, 31, 143, 164`; `upstream/content/sets-functions-relations/size-of-sets/pairing-alt.tex:17, 70, 73, 75–76, 78–79, 81`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:59, 125`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:56, 61, 104, 120, 122, 129`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:62, 219, 227`; `mr/content/sets-functions-relations/arithmetization/reals.tex:31, 61, 70`; `mr/content/sets-functions-relations/size-of-sets/enumerability-alt.tex:88, 118`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:50, 132`; `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:74, 76, 78, 80–81, 83–84`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** In this elementary number-theory context, are धन, विषम, सम, गुणक, घात and घातांक the clearest mutually distinct Marathi labels, especially for factor versus exponent?

## T073 — Cantor's diagonal method / diagonalization / diagonal argument

- **Chosen wording:** कँटर यांची कर्णरेषीय पद्धत / कर्णीकरण / कर्णरेषीय युक्तिवाद
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional descriptive extension; open to correction. This choice remains open to correction.
- **Rationale:** The three forms distinguish the named method, the general proof technique and an instance of its argument. MR-P032 supports Cantor and Marathi set-theory register but does not attest these exact diagonalization labels; the two explicit OpenLogic constructions govern their meaning.
- **Alternatives considered:** कँटर यांची विकर्ण पद्धत / विकर्णीकरण / विकर्ण युक्तिवाद; कँटर यांची तिरपी पद्धत / तिरपीकरण.
- **Exact aligned source/target scopes:**

  - OLP-0033 B009, B015, B020, B022, B024–B026: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex)
  - OLP-0034 B006–B007: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0036 B015–B016: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0039 B009, B012, B014, B017–B018: [English](../upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex)
  - OLP-0040 B007: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T073-OLP-0033-B009`, `T073-OLP-0033-B015`, `T073-OLP-0033-B020`, `T073-OLP-0033-B022`, `T073-OLP-0033-B024`, `T073-OLP-0033-B025`, `T073-OLP-0033-B026`, `T073-OLP-0034-B006`, `T073-OLP-0034-B007`, `T073-OLP-0036-B015`, `T073-OLP-0036-B016`, `T073-OLP-0039-B009`, `T073-OLP-0039-B012`, `T073-OLP-0039-B014`, `T073-OLP-0039-B017`, `T073-OLP-0039-B018`, `T073-OLP-0040-B007`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:106–107, 156`; `upstream/content/sets-functions-relations/size-of-sets/non-enumerability.tex:140–141, 203, 208`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:20–21`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:20`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:106–107`; `mr/content/sets-functions-relations/size-of-sets/non-enumerability.tex:137–138, 199, 204`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:19–20`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:20`.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P032, MR-C004, Current search extraction, personally read 2026-09-04: paragraphs headed infinite sets and cardinality. Same previously indexed source, new actual consultation. The witness's positive-natural-number convention and its restriction to infinite countable sets do not replace OpenLogic conventions. Missing/corrupt mathematical glyphs and source historical assertions are not imported. Original HTML remains unavailable.
- **Precise review question:** Does कर्णरेषीय पद्धत / कर्णीकरण clearly name Cantor's diagonal construction in Marathi logic, or is विकर्ण the established technical stem?

## T074 — reduction / reduce one problem to another

- **Chosen wording:** न्यूनीकरण / एक समस्या दुसऱ्या समस्येकडे न्यूनीत करणे
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted lexical head; direction-explicit technical use governed by OpenLogic. This choice remains open to correction.
- **Rationale:** MR-P034 directly attests the short lexical headword reduction — न्यूनीकरण in the official Marathi glossary. The expanded directional phrase remains necessary because the frozen OpenLogic definitions and constructions—not the glossary—govern which problem reduces to which.
- **Alternatives considered:** घटीकरण / एक समस्या दुसरीत घटवणे; रिडक्शन / एका समस्येचे दुसऱ्या समस्येत रूपांतर.
- **Exact aligned source/target scopes:**

  - OLP-0034 B005–B011, B014–B019: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0040 B005–B006, B008–B011, B018–B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
- **Occurrence records:** `T074-OLP-0034-B005`, `T074-OLP-0034-B006`, `T074-OLP-0034-B007`, `T074-OLP-0034-B008`, `T074-OLP-0034-B009`, `T074-OLP-0034-B010`, `T074-OLP-0034-B011`, `T074-OLP-0034-B014`, `T074-OLP-0034-B015`, `T074-OLP-0034-B016`, `T074-OLP-0034-B017`, `T074-OLP-0034-B018`, `T074-OLP-0034-B019`, `T074-OLP-0040-B005`, `T074-OLP-0040-B006`, `T074-OLP-0040-B008`, `T074-OLP-0040-B009`, `T074-OLP-0040-B010`, `T074-OLP-0040-B011`, `T074-OLP-0040-B018`, `T074-OLP-0040-B019`, `T074-OLP-0040-B020`, `T074-OLP-0040-B021`
- **Literal English line hits:** `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:3, 11, 14, 48–49, 89, 108, 114, 120`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:3, 11, 14, 47, 86, 105, 110, 116`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:11, 15, 49–50, 90, 110, 116, 122`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:11, 15, 48, 88, 110, 115, 122`.
- **Authorities actually checked:**

  - [मराठी विश्वकोश | मराठी शब्दकोश — R glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/41/r) — MR-P034, MR-C022, web-open lines 1479-1483. Observation hash is not an origin-page hash and does not independently attest the computability-theory direction.
- **Precise review question:** Does न्यूनीकरण, together with the explicit directional phrase, state the direction of a mathematical reduction naturally and without suggesting mere simplification?

## T075 — no larger than / smaller than (cardinal comparison)

- **Chosen wording:** आकारमानाने मोठा नाही / आकारमानाने लहान
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional definition-controlled comparison phrase; open to correction. This choice remains open to correction.
- **Rationale:** The explicit आकारमानाने modifier prevents the order from being mistaken for subset inclusion or spatial size. MR-P032 supports cardinality and equinumerosity context but does not attest these exact comparison phrases; the injection and no-bijection definitions govern.
- **Alternatives considered:** संचांकाने मोठा नाही / संचांकाने लहान; अधिकतम समान / काटेकोरपणे कमी आकारमानाचा.
- **Exact aligned source/target scopes:**

  - OLP-0036 B005–B012, B014–B016, B018: [English](../upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/comparing-size.tex)
  - OLP-0037 B005–B007, B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
  - OLP-0044 B006: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
- **Occurrence records:** `T075-OLP-0036-B005`, `T075-OLP-0036-B006`, `T075-OLP-0036-B007`, `T075-OLP-0036-B008`, `T075-OLP-0036-B009`, `T075-OLP-0036-B010`, `T075-OLP-0036-B011`, `T075-OLP-0036-B012`, `T075-OLP-0036-B014`, `T075-OLP-0036-B015`, `T075-OLP-0036-B016`, `T075-OLP-0036-B018`, `T075-OLP-0037-B005`, `T075-OLP-0037-B006`, `T075-OLP-0037-B007`, `T075-OLP-0037-B010`, `T075-OLP-0044-B006`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/reals.tex:80`; `upstream/content/sets-functions-relations/size-of-sets/comparing-size.tex:16, 27, 37`; `upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:14–15`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:27, 37`; `mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:14–15`.
- **Authorities actually checked:**

  - [MR-C004](https://vishwakosh.marathi.gov.in/34075/) — MR-P032, MR-C004, Current search extraction, personally read 2026-09-04: paragraphs headed infinite sets and cardinality. Same previously indexed source, new actual consultation. The witness's positive-natural-number convention and its restriction to infinite countable sets do not replace OpenLogic conventions. Missing/corrupt mathematical glyphs and source historical assertions are not imported. Original HTML remains unavailable.
- **Precise review question:** Do आकारमानाने मोठा नाही and आकारमानाने लहान express cardinal comparison naturally while remaining distinct from subset inclusion and ordinary physical size?

## T076 — Schröder–Bernstein theorem

- **Chosen wording:** श्रेडर--बर्नस्टाइन प्रमेय
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional proper-name transliteration; open to correction. This choice remains open to correction.
- **Rationale:** A conservative phonetic transliteration preserves the two-name order in the frozen source. No Marathi authority was consulted for this proper-name spelling, so alternatives remain explicitly reviewable.
- **Alternatives considered:** श्रोडर--बर्नस्टाइन प्रमेय; कँटर--बर्नस्टाइन--श्रोडर प्रमेय.
- **Exact aligned source/target scopes:**

  - OLP-0037 B005–B007, B009–B010: [English](../upstream/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex)
- **Occurrence records:** `T076-OLP-0037-B005`, `T076-OLP-0037-B006`, `T076-OLP-0037-B007`, `T076-OLP-0037-B009`, `T076-OLP-0037-B010`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/size-of-sets/schroder-bernstein.tex:11, 19, 43, 46`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Is श्रेडर--बर्नस्टाइन the clearest established Marathi transliteration of Schröder–Bernstein, and should the edition preserve the frozen source's two-name order?

## T077 — arithmetization

- **Chosen wording:** अंकगणितीकरण
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted with two official Marathi reference attestations. This choice remains open to correction.
- **Rationale:** MR-P035 uses the term in the matching historical sense of constructing reals from rationals and rationals from integers; MR-P036 independently gives the direct official glossary pairing.
- **Alternatives considered:** अंकगणितीयकरण; अंकगणितरूपीकरण.
- **Exact aligned source/target scopes:**

  - OLP-0041 B004–B005: [English](../upstream/content/sets-functions-relations/arithmetization/arithmetization.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/arithmetization.tex)
- **Occurrence records:** `T077-OLP-0041-B004`, `T077-OLP-0041-B005`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/arithmetization.tex:2, 8`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/arithmetization.tex:8`.
- **Authorities actually checked:**

  - [गणिताचा तात्त्विक पाया — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/21257/) — MR-P035, MR-C023, web-open lines 80-81. Observation hash is not an origin-page hash; the article's broader historical claim is not imported as chapter content.
  - [मराठी विश्वकोश | मराठी शब्दकोश — A glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/41) — MR-P036, MR-C024, web-open lines 20-22. Observation hash is not an origin-page hash and the displayed English headword is misspelled on the glossary page.
- **Precise review question:** Does the officially attested अंकगणितीकरण remain the clearest heading for this specific set-theoretic construction of integer, rational and real number systems?

## T078 — naive set theory

- **Chosen wording:** अनौपचारिक संचसिद्धान्त
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional definition-controlled rendering; open to correction. This choice remains open to correction.
- **Rationale:** A meaning-explicit rendering distinguishes informal set construction from axiomatic set theory and avoids the colloquial connotations of a literal rendering of naive. No exact Marathi specialist attestation was located in the bounded search; OpenLogic context governs.
- **Alternatives considered:** भोळा संचसिद्धान्त; स्वयंसिद्धकविरहित संचसिद्धान्त.
- **Exact aligned source/target scopes:**

  - OLP-0041 B005: [English](../upstream/content/sets-functions-relations/arithmetization/arithmetization.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/arithmetization.tex)
  - OLP-0043 B005: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0046 B012: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
- **Occurrence records:** `T078-OLP-0041-B005`, `T078-OLP-0043-B005`, `T078-OLP-0046-B012`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/arithmetization.tex:11`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:12`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:87`.
- **Authorities actually checked:** none for this exact label before current use; this absence is recorded rather than treated as a hold.
- **Precise review question:** Does अनौपचारिक संचसिद्धान्त convey naive set theory's informal, pre-axiomatic method without suggesting mathematical looseness beyond the source?

## T079 — number system

- **Chosen wording:** संख्याप्रणाली
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** provisional contextual extension; open to correction. This choice remains open to correction.
- **Rationale:** MR-P035 supplies the native mathematical register for the linked integer, rational and real constructions but does not use this exact compound in the consulted lines. The compact descriptive compound remains reviewable.
- **Alternatives considered:** संख्या-पद्धती; संख्याव्यवस्था.
- **Exact aligned source/target scopes:**

  - OLP-0041 B005: [English](../upstream/content/sets-functions-relations/arithmetization/arithmetization.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/arithmetization.tex)
- **Occurrence records:** `T079-OLP-0041-B005`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/arithmetization.tex:11`.
- **Authorities actually checked:**

  - [गणिताचा तात्त्विक पाया — मराठी विश्वकोश प्रथमावृत्ती](https://vishwakosh.marathi.gov.in/21257/) — MR-P035, MR-C023, web-open lines 80-81. Observation hash is not an origin-page hash; the article's broader historical claim is not imported as chapter content.
- **Precise review question:** In exposition covering integers, rationals and reals together, is संख्याप्रणाली preferable to संख्या-पद्धती or संख्याव्यवस्था?

## T080 — integer / set of integers

- **Chosen wording:** पूर्णांक / पूर्णांकांचा संच
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted from visually verified official Marathi mathematics textbook usage. This choice remains open to correction.
- **Rationale:** MR-P037 directly uses पूर्णांक संख्या समूह and distinguishes it from the whole-number set while listing negative integers, zero and positive integers. OpenLogic governs the equivalence-class construction.
- **Alternatives considered:** पूर्ण संख्या — rejected here because MR-P037 distinguishes that set from the integer set; इंटीजर — unnecessary transliteration.
- **Exact aligned source/target scopes:**

  - OLP-0042 B004–B007, B012, B014–B015: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B004–B008: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
  - OLP-0046 B009–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B005, B007–B008, B010, B012–B015, B017–B020, B022: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B008, B011: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T080-OLP-0042-B004`, `T080-OLP-0042-B005`, `T080-OLP-0042-B006`, `T080-OLP-0042-B007`, `T080-OLP-0042-B012`, `T080-OLP-0042-B014`, `T080-OLP-0042-B015`, `T080-OLP-0043-B004`, `T080-OLP-0043-B005`, `T080-OLP-0043-B006`, `T080-OLP-0043-B007`, `T080-OLP-0043-B008`, `T080-OLP-0046-B009`, `T080-OLP-0046-B010`, `T080-OLP-0046-B011`, `T080-OLP-0046-B012`, `T080-OLP-0046-B013`, `T080-OLP-0047-B005`, `T080-OLP-0047-B007`, `T080-OLP-0047-B008`, `T080-OLP-0047-B010`, `T080-OLP-0047-B012`, `T080-OLP-0047-B013`, `T080-OLP-0047-B014`, `T080-OLP-0047-B015`, `T080-OLP-0047-B017`, `T080-OLP-0047-B018`, `T080-OLP-0047-B019`, `T080-OLP-0047-B020`, `T080-OLP-0047-B022`, `T080-OLP-0048-B008`, `T080-OLP-0048-B011`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:38, 127, 145`; `upstream/content/sets-functions-relations/arithmetization/integers.tex:15, 18, 20, 24, 42, 47, 57, 59, 62`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:12, 14, 18, 43, 47, 64`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:37, 39, 41, 48, 57, 59, 63, 75–76, 83, 86, 94`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:40, 126, 143`; `mr/content/sets-functions-relations/arithmetization/integers.tex:15, 18, 20, 24, 42, 47, 58–59, 61`; `mr/content/sets-functions-relations/arithmetization/rationals.tex:12–13, 17, 41, 46, 57, 62`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:33, 36, 45, 54, 56, 59, 70, 72, 78–79, 81, 88`.
- **Authorities actually checked:**

  - [गणित, इयत्ता आठवी](https://books.ebalbharati.in/pdfs/801020004.pdf) — MR-P037, MR-C017, PDF page 11, printed page 1. The elementary textbook supports the label and number-set distinction, not the set-theoretic equivalence-class construction.
- **Precise review question:** Does पूर्णांक remain unambiguous throughout the quotient construction, especially where the source contrasts natural numbers as constructed objects with their embedded integer representatives?

## T081 — stipulative definition / stipulate

- **Chosen wording:** संकेतजनक व्याख्या / अर्थ ठरवणे
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted official lexical noun; context-controlled idiomatic verb. This choice remains open to correction.
- **Rationale:** MR-P038 directly attests संकेतजनक व्याख्या. In the later verbal use, अर्थ ठरवणे is the more idiomatic Marathi action phrase while retaining the deliberate assignment of a representative required by the source.
- **Alternatives considered:** करारात्मक व्याख्या; निर्धारित व्याख्या.
- **Exact aligned source/target scopes:**

  - OLP-0042 B013, B015: [English](../upstream/content/sets-functions-relations/arithmetization/integers.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/integers.tex)
  - OLP-0043 B007: [English](../upstream/content/sets-functions-relations/arithmetization/rationals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/rationals.tex)
- **Occurrence records:** `T081-OLP-0042-B013`, `T081-OLP-0042-B015`, `T081-OLP-0043-B007`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/integers.tex:45, 63`; `upstream/content/sets-functions-relations/arithmetization/rationals.tex:65`.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [साहित्य समीक्षा परिभाषा कोश — S glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/27/s) — MR-P038, MR-C025, web-open lines 1187-1191. The glossary is for literary criticism rather than mathematical logic and the observation hash is not an origin-page hash.
- **Precise review question:** In this mathematical-philosophical context, does संकेतजनक व्याख्या clearly convey deliberate meaning assignment, and is अर्थ ठरवणे the best idiomatic rendering of the related verb?

## T082 — real number / real line

- **Chosen wording:** वास्तव संख्या / वास्तव संख्या-रेषा
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted from visually verified official Marathi mathematics textbook usage. This choice remains open to correction.
- **Rationale:** MR-P040 directly defines वास्तव संख्या through the number line in native school mathematics. The same stem was already used consistently in translated earlier units; the hyphenated line compound keeps the title explicit.
- **Alternatives considered:** वास्तविक संख्या / वास्तविक संख्या-रेषा; सत् संख्या.
- **Exact aligned source/target scopes:**

  - OLP-0007 B005–B006: [English](../upstream/content/sets-functions-relations/sets/important-sets.tex) ↔ [Marathi](../mr/content/sets-functions-relations/sets/important-sets.tex)
  - OLP-0021 B014: [English](../upstream/content/sets-functions-relations/functions/function-basics.tex) ↔ [Marathi](../mr/content/sets-functions-relations/functions/function-basics.tex)
  - OLP-0034 B021: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction.tex)
  - OLP-0040 B023: [English](../upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex) ↔ [Marathi](../mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex)
  - OLP-0044 B004–B006, B011–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B003–B004, B006, B008, B010–B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B006, B008–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B022–B023, B026–B027: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B005–B009, B011–B012, B014–B015, B018–B020, B022–B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T082-OLP-0007-B005`, `T082-OLP-0007-B006`, `T082-OLP-0021-B014`, `T082-OLP-0034-B021`, `T082-OLP-0040-B023`, `T082-OLP-0044-B004`, `T082-OLP-0044-B005`, `T082-OLP-0044-B006`, `T082-OLP-0044-B011`, `T082-OLP-0044-B012`, `T082-OLP-0044-B013`, `T082-OLP-0045-B003`, `T082-OLP-0045-B004`, `T082-OLP-0045-B006`, `T082-OLP-0045-B008`, `T082-OLP-0045-B010`, `T082-OLP-0045-B011`, `T082-OLP-0045-B012`, `T082-OLP-0046-B006`, `T082-OLP-0046-B008`, `T082-OLP-0046-B009`, `T082-OLP-0046-B010`, `T082-OLP-0046-B011`, `T082-OLP-0046-B012`, `T082-OLP-0046-B013`, `T082-OLP-0047-B022`, `T082-OLP-0047-B023`, `T082-OLP-0047-B026`, `T082-OLP-0047-B027`, `T082-OLP-0048-B005`, `T082-OLP-0048-B006`, `T082-OLP-0048-B007`, `T082-OLP-0048-B008`, `T082-OLP-0048-B009`, `T082-OLP-0048-B011`, `T082-OLP-0048-B012`, `T082-OLP-0048-B014`, `T082-OLP-0048-B015`, `T082-OLP-0048-B018`, `T082-OLP-0048-B019`, `T082-OLP-0048-B020`, `T082-OLP-0048-B022`, `T082-OLP-0048-B023`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:31, 35, 63, 78–79, 97, 99–100, 107, 110`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:13, 15`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:10, 74, 82`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:33`; `upstream/content/sets-functions-relations/sets/important-sets.tex:24, 36`; `upstream/content/sets-functions-relations/size-of-sets/reduction-alt.tex:137`; `upstream/content/sets-functions-relations/size-of-sets/reduction.tex:135`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:11, 13, 16, 35, 46, 51, 73–75, 91, 104, 118, 133, 173`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:143`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:12, 15–16, 87, 90, 92`; `mr/content/sets-functions-relations/arithmetization/reals.tex:10, 12–13, 16, 19, 22, 79–80, 99`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:15, 24, 26, 29–30, 38, 45, 50, 59, 62, 65, 71, 89, 95`; `mr/content/sets-functions-relations/functions/function-basics.tex:65`; `mr/content/sets-functions-relations/sets/important-sets.tex:24, 35`; `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:141`; `mr/content/sets-functions-relations/size-of-sets/reduction.tex:141`.
- **Authorities actually checked:**

  - [गणित, इयत्ता आठवी](https://books.ebalbharati.in/pdfs/801020004.pdf) — MR-P040, MR-C017, PDF page 15, printed page 5. The elementary geometric description does not govern OpenLogic's set construction or completeness characterization.
- **Precise review question:** Should the edition retain the textbook's concise वास्तव संख्या consistently, including वास्तव संख्या-रेषा, or prefer the also-attested वास्तविक संख्या in advanced contexts?

## T083 — irrational number

- **Chosen wording:** अपरिमेय संख्या
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted from repeated official Marathi mathematics textbook usage. This choice remains open to correction.
- **Rationale:** Both visually verified textbook pages use अपरिमेय संख्या and distinguish it from परिमेय संख्या while placing both within the real numbers.
- **Alternatives considered:** करणी संख्या — too narrow for arbitrary irrational numbers; इरॅशनल संख्या.
- **Exact aligned source/target scopes:**

  - OLP-0044 B005–B010, B012–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0048 B007–B008: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T083-OLP-0044-B005`, `T083-OLP-0044-B006`, `T083-OLP-0044-B007`, `T083-OLP-0044-B008`, `T083-OLP-0044-B009`, `T083-OLP-0044-B010`, `T083-OLP-0044-B012`, `T083-OLP-0044-B013`, `T083-OLP-0048-B007`, `T083-OLP-0048-B008`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/reals.tex:22`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/reals.tex:21`.
- **Authorities actually checked:**

  - [गणित, इयत्ता आठवी](https://books.ebalbharati.in/pdfs/801020004.pdf) — MR-P039, MR-C017, PDF page 14, printed page 4. The page announces rather than proves irrationality; OpenLogic supplies the proof and its two methods.
  - [गणित, इयत्ता आठवी](https://books.ebalbharati.in/pdfs/801020004.pdf) — MR-P040, MR-C017, PDF page 15, printed page 5. The elementary geometric description does not govern OpenLogic's set construction or completeness characterization.
- **Precise review question:** Does अपरिमेय संख्या remain clear in both the square-root example and the later completeness discussion without being confused with a merely incommensurable magnitude?

## T084 — ordered field

- **Chosen wording:** क्रमित क्षेत्र
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct official mathematics-glossary attestation. This choice remains open to correction.
- **Rationale:** MR-P041 is a direct entry in the official mathematics glossary; the referenced OpenLogic definition controls the technical axioms.
- **Alternatives considered:** क्रमबद्ध क्षेत्र; सुव्यवस्थित क्षेत्र — rejected because well-ordering is different.
- **Exact aligned source/target scopes:**

  - OLP-0044 B006: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0046 B006: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B003, B019–B022, B026: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B015, B017: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T084-OLP-0044-B006`, `T084-OLP-0046-B006`, `T084-OLP-0047-B003`, `T084-OLP-0047-B019`, `T084-OLP-0047-B020`, `T084-OLP-0047-B021`, `T084-OLP-0047-B022`, `T084-OLP-0047-B026`, `T084-OLP-0048-B015`, `T084-OLP-0048-B017`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:162, 170`; `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:132, 139, 142, 147, 151, 176`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:17`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:20`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:161, 170`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:130, 136, 140, 144–145, 147, 174`; `mr/content/sets-functions-relations/arithmetization/reals.tex:17`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:19`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — O glossary](https://shabdakosh.marathi.gov.in/index.php/ananya-glossary/9/o) — MR-P041, MR-C026, web-open lines 640-642. Observation hash is not an origin-page hash.
- **Precise review question:** Is क्रमित क्षेत्र the established advanced-mathematics form for an ordered field throughout the later checking-details section?

## T085 — Completeness Property / upper bound / least upper bound

- **Chosen wording:** संपूर्णता गुणधर्म / ऊर्ध्वबंध / लघुतम ऊर्ध्वबंध
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted lexical components; exact property sense controlled by source definition. This choice remains open to correction.
- **Rationale:** The official sources directly attest संपूर्णता, ऊर्ध्वबंध and the full phrase लघुतम ऊर्ध्वबंध. The property compound is governed by OpenLogic's exact quantified least-upper-bound formulation.
- **Alternatives considered:** पूर्णता गुणधर्म / उच्च बंध / न्यूनतम उच्च बंध; परिपूर्णता गुणधर्म.
- **Exact aligned source/target scopes:**

  - OLP-0044 B011–B013: [English](../upstream/content/sets-functions-relations/arithmetization/reals.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reals.tex)
  - OLP-0045 B004, B008–B011: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B006, B008: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B022: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
  - OLP-0048 B018–B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T085-OLP-0044-B011`, `T085-OLP-0044-B012`, `T085-OLP-0044-B013`, `T085-OLP-0045-B004`, `T085-OLP-0045-B008`, `T085-OLP-0045-B009`, `T085-OLP-0045-B010`, `T085-OLP-0045-B011`, `T085-OLP-0046-B006`, `T085-OLP-0046-B008`, `T085-OLP-0047-B022`, `T085-OLP-0048-B018`, `T085-OLP-0048-B019`, `T085-OLP-0048-B020`, `T085-OLP-0048-B021`, `T085-OLP-0048-B022`, `T085-OLP-0048-B023`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:174, 177–178, 182–184, 215, 226`; `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:148–149`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:12, 14, 48, 50, 55, 59, 64, 66, 77`; `upstream/content/sets-functions-relations/arithmetization/reals.tex:74, 76, 80, 82`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:16, 32`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:173, 177–178, 182–183, 185, 188, 190, 216, 230, 236`; `mr/content/sets-functions-relations/arithmetization/checking-details.tex:144, 146`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:12, 14, 46, 48–49, 54, 58, 65, 68, 77–78, 82, 85`; `mr/content/sets-functions-relations/arithmetization/reals.tex:83–84, 86, 91–92, 95–96, 98`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:16, 29`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — C glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/c) — MR-P042, MR-C027, current web-search extraction personally read 2026-09-05. Observation hash is not an origin-page hash; the compound property label is contextual.
  - [मराठी विश्वकोश — L glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/41/l) — MR-P043, MR-C028, current web-search extraction personally read 2026-09-05. Observation hash is not an origin-page hash; OpenLogic controls the quantified property.
  - [मराठी विश्वकोश — U glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/41/u) — MR-P044, MR-C029, web-open lines 491-493. Observation hash is not an origin-page hash.
- **Precise review question:** Does संपूर्णता गुणधर्म, paired with the directly attested ऊर्ध्वबंध and लघुतम ऊर्ध्वबंध, state the order-completeness property naturally and avoid suggesting logical completeness?

## T086 — Dedekind cut / cut

- **Chosen wording:** डेडेकिंड छेद / छेद
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted from native Government of Maharashtra-hosted mathematical-philosophical usage with normalized proper-name spelling. This choice remains open to correction.
- **Rationale:** MR-P045 is a Government of Maharashtra-hosted Marathi translation that explicitly uses a transliteration of Dedekind with छेद. The target regularizes the garbled/extracted proper-name spelling to डेडेकिंड. Bare छेद is retained after the definition; its intersection sense in T018 is disambiguated by the Dedekind and rational-partition context.
- **Alternatives considered:** डेडेकिंट छेद; डेडेकिंड काप; डेडेकिंड विभाजन.
- **Exact aligned source/target scopes:**

  - OLP-0045 B004–B012: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
  - OLP-0046 B006, B008: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0047 B023–B025, B027–B028: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T086-OLP-0045-B004`, `T086-OLP-0045-B005`, `T086-OLP-0045-B006`, `T086-OLP-0045-B007`, `T086-OLP-0045-B008`, `T086-OLP-0045-B009`, `T086-OLP-0045-B010`, `T086-OLP-0045-B011`, `T086-OLP-0045-B012`, `T086-OLP-0046-B006`, `T086-OLP-0046-B008`, `T086-OLP-0047-B023`, `T086-OLP-0047-B024`, `T086-OLP-0047-B025`, `T086-OLP-0047-B027`, `T086-OLP-0047-B028`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:148, 155–156, 159, 165, 171–172, 180, 182`; `upstream/content/sets-functions-relations/arithmetization/cuts.tex:3, 9, 17–18, 21, 26–27, 29, 35, 39, 48–51, 55, 59, 62, 64–65, 67, 70, 73, 82, 110–111`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:18, 20, 25`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:151–152, 156, 162, 168–169, 179`; `mr/content/sets-functions-relations/arithmetization/cuts.tex:17, 19, 25–27, 34, 38, 46, 48–49, 51, 54, 58, 61, 63–64, 70, 73, 86–87, 102, 117–118`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:17, 19, 25`.
- **Authorities actually checked:**

  - [गणिती तत्त्वज्ञानाचा परिचय — Bertrand Russell, Marathi translation](https://sahitya.marathi.gov.in/ebooks/%E0%A4%97%E0%A4%A3%E0%A4%BF%E0%A4%A4%E0%A5%80%20%E0%A4%A4%E0%A4%A4%E0%A5%8D%E0%A4%A4%E0%A5%8D%E0%A4%B5%E0%A4%9C%E0%A5%8D%E0%A4%9E%E0%A4%BE%E0%A4%A8%E0%A4%BE%E0%A4%9A%E0%A4%BE%20%E0%A4%AA%E0%A4%B0%E0%A4%BF%E0%A4%9A%E0%A4%AF.pdf) — MR-P045, MR-C030, web-open PDF lines 1712-1744, PDF pages 57-58 (printed pages 69-70). The extraction garbles Devanagari and the proper name; डेडेकिंड is a normalized target transliteration. Observation hash is not an origin-PDF hash.
- **Precise review question:** Is डेडेकिंड छेद sufficiently unambiguous beside the established set-intersection term छेद, once the full label has introduced the context?

## T087 — greatest lower bound

- **Chosen wording:** महत्तम निम्नबंध
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct official glossary attestation. This choice remains open to correction.
- **Rationale:** MR-P046 directly attests the complete phrase in the official glossary and forms a transparent counterpart to the already adopted लघुतम ऊर्ध्वबंध.
- **Alternatives considered:** महत्तम अवबंध; सर्वात मोठा निम्नबंध; गुरुतम निम्नबंध.
- **Exact aligned source/target scopes:**

  - OLP-0045 B004: [English](../upstream/content/sets-functions-relations/arithmetization/cuts.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cuts.tex)
- **Occurrence records:** `T087-OLP-0045-B004`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cuts.tex:15`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:14`.
- **Authorities actually checked:**

  - [मराठी विश्वकोश — G glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/41/g) — MR-P046, MR-C031, web-open lines 1603-1607. Observation hash is not an origin-page hash; OpenLogic controls the quantified property.
- **Precise review question:** Should महत्तम निम्नबंध remain paired consistently with लघुतम ऊर्ध्वबंध in all later order-theoretic units?

## T088 — Cauchy sequence

- **Chosen wording:** कोशी क्रमिका
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct official mathematics-glossary attestation. This choice remains open to correction.
- **Rationale:** MR-P047 is an exact entry in the official Government of Maharashtra mathematics glossary. The spelling and mathematical noun are therefore adopted directly.
- **Alternatives considered:** कौशी अनुक्रम; कोशी अनुक्रम; कॉशी क्रमिका.
- **Exact aligned source/target scopes:**

  - OLP-0046 B008, B010: [English](../upstream/content/sets-functions-relations/arithmetization/reflections.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/reflections.tex)
  - OLP-0048 B005–B006, B009–B015, B017, B019–B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T088-OLP-0046-B008`, `T088-OLP-0046-B010`, `T088-OLP-0048-B005`, `T088-OLP-0048-B006`, `T088-OLP-0048-B009`, `T088-OLP-0048-B010`, `T088-OLP-0048-B011`, `T088-OLP-0048-B012`, `T088-OLP-0048-B013`, `T088-OLP-0048-B014`, `T088-OLP-0048-B015`, `T088-OLP-0048-B017`, `T088-OLP-0048-B019`, `T088-OLP-0048-B020`, `T088-OLP-0048-B021`, `T088-OLP-0048-B022`, `T088-OLP-0048-B023`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:11, 15, 84, 98, 100–101, 107, 110, 124, 129, 146, 162, 170, 177, 210, 219, 226`; `upstream/content/sets-functions-relations/arithmetization/reflections.tex:29`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:11, 14, 79, 91, 93–94, 99, 102, 117, 123, 140–141, 143, 161, 170, 177, 182, 211, 220, 230`; `mr/content/sets-functions-relations/arithmetization/reflections.tex:27`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — C glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/c) — MR-P047, MR-C027, current web-search extraction personally read 2026-09-05. A follow-up web-open request returned a transient gateway error; observation hash is not an origin-page hash.
- **Precise review question:** Should कोशी क्रमिका remain the exact form throughout the later Cauchy construction and analysis chapters?

## T089 — ring / commutative ring / ordered ring

- **Chosen wording:** वलय / क्रमनिरपेक्ष वलय / क्रमित वलय
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** commutative-ring phrase directly attested; ordered-ring compound definition-controlled. This choice remains open to correction.
- **Rationale:** MR-P049 directly attests क्रमनिरपेक्ष वलय. The shorter वलय is its transparent head, and क्रमित वलय pairs it with the directly attested क्रमित क्षेत्र in MR-P041 while OpenLogic supplies the exact order-compatibility axioms.
- **Alternatives considered:** क्रमविनिमेय वलय / क्रमबद्ध वलय; अदला-बदलीचे वलय.
- **Exact aligned source/target scopes:**

  - OLP-0047 B003, B005–B007, B013–B020, B022: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T089-OLP-0047-B003`, `T089-OLP-0047-B005`, `T089-OLP-0047-B006`, `T089-OLP-0047-B007`, `T089-OLP-0047-B013`, `T089-OLP-0047-B014`, `T089-OLP-0047-B015`, `T089-OLP-0047-B016`, `T089-OLP-0047-B017`, `T089-OLP-0047-B018`, `T089-OLP-0047-B019`, `T089-OLP-0047-B020`, `T089-OLP-0047-B022`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:11, 21, 24, 38, 94, 98, 104, 112, 121, 125, 132, 138`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:11, 20, 23, 40, 94, 98, 103, 111–112, 120, 123, 130, 136`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — C glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/c) — MR-P049, MR-C027, current web-search extraction personally read 2026-09-05. Observation hash is not an origin-page hash.
  - [गणितशास्त्र परिभाषा कोश — O glossary](https://shabdakosh.marathi.gov.in/index.php/ananya-glossary/9/o) — MR-P041, MR-C026, web-open lines 640-642. Observation hash is not an origin-page hash.
- **Precise review question:** Do क्रमनिरपेक्ष वलय and क्रमित वलय remain clear and mutually distinct throughout the algebra appendix?

## T090 — associativity / commutativity / identity / additive inverse / distributivity / multiplicative inverse

- **Chosen wording:** सहचारिता / क्रमनिरपेक्षता / अविकारक / बेरीज व्यस्त / वितरणता / गुणाकार व्यस्त
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** direct official glossary attestations with one transparent generic-head shortening. This choice remains open to correction.
- **Rationale:** The official glossary directly attests every displayed law name except the deliberately generic plural heading Identities. अविकारक is the shared head of the attested गुणाकार अविकारक, while the adjacent equations identify both additive and multiplicative instances.
- **Alternatives considered:** साहचर्य / क्रमविनिमेयता / एकक / योगात्मक व्यस्त / वितरणशीलता / गुणात्मक व्यस्त.
- **Exact aligned source/target scopes:**

  - OLP-0047 B006–B012, B019: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T090-OLP-0047-B006`, `T090-OLP-0047-B007`, `T090-OLP-0047-B008`, `T090-OLP-0047-B009`, `T090-OLP-0047-B010`, `T090-OLP-0047-B011`, `T090-OLP-0047-B012`, `T090-OLP-0047-B019`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:26, 28, 32–33, 41, 62, 74, 134`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:26, 28, 30, 32–33, 43, 63, 132`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — A glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/a) — MR-P048, MR-C032, web-open lines 365-369 and 1236-1240. Observation hash is not an origin-page hash.
  - [गणितशास्त्र परिभाषा कोश — C glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/c) — MR-P049, MR-C027, current web-search extraction personally read 2026-09-05. Observation hash is not an origin-page hash.
  - [गणितशास्त्र परिभाषा कोश — D glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/d) — MR-P050, MR-C033, web-open lines 154-158 and 236-240. Observation hash is not an origin-page hash.
  - [गणितशास्त्र परिभाषा कोश — M glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/M) — MR-P051, MR-C034, web-open lines 189-193 and 248-252. Observation hash is not an origin-page hash.
- **Precise review question:** Are the concise displayed headings natural while the equations keep each property unambiguous?

## T091 — trichotomy / trichotomic property

- **Chosen wording:** त्रिपर्याय / त्रिपर्यायी गुणधर्म
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct official mathematics-glossary attestation. This choice remains open to correction.
- **Rationale:** MR-P052 directly attests both the noun and property adjective in the official mathematics glossary; the source footnote's disjunction controls the local explanatory use.
- **Alternatives considered:** त्रिभाजन; त्रिविधता; तीन पर्यायांचा गुणधर्म.
- **Exact aligned source/target scopes:**

  - OLP-0047 B015: [English](../upstream/content/sets-functions-relations/arithmetization/checking-details.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/checking-details.tex)
- **Occurrence records:** `T091-OLP-0047-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/checking-details.tex:108`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:106`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — T glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/t) — MR-P052, MR-C035, current web-search extraction personally read 2026-09-05. Observation hash is not an origin-page hash.
- **Precise review question:** Does त्रिपर्याय read naturally as the order-theoretic property rather than an arbitrary three-way choice?

## T092 — approximation / approximate

- **Chosen wording:** निकटन / निकटन करणे
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct official mathematics-glossary attestation. This choice remains open to correction.
- **Rationale:** MR-P053 directly attests निकटन for approximation in the official mathematics glossary; the surrounding comparative phrases express increasing accuracy.
- **Alternatives considered:** सन्निकटन; स्थूलमान; अदमास.
- **Exact aligned source/target scopes:**

  - OLP-0048 B008, B010: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T092-OLP-0048-B008`, `T092-OLP-0048-B010`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:42, 48, 93`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:41, 46, 88`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — A glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/a) — MR-P053, MR-C036, web-open lines 1118-1120. Observation hash is not an origin-page hash.
- **Precise review question:** Does निकटन remain natural in both the noun and verbal contexts of rational approximation?

## T093 — decimal expansion / decimal place

- **Chosen wording:** दशांश विस्तार / दशांश स्थान
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct lexical components with transparent contextual compound. This choice remains open to correction.
- **Rationale:** MR-P054 directly attests दशांश and दशांश स्थान; विस्तार is the established transparent head for the expansion displayed by OpenLogic.
- **Alternatives considered:** दशमान विस्तार / दशांश जागा; दशांश प्रसार.
- **Exact aligned source/target scopes:**

  - OLP-0048 B007–B008: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T093-OLP-0048-B007`, `T093-OLP-0048-B008`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:23–24, 28, 30, 40`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:23–24, 29, 31, 40, 51, 53`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — D glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/d) — MR-P054, MR-C037, web-open lines 178-180, 266-268, 342-344 and 418-420. Observation hash is not an origin-page hash.
- **Precise review question:** Is दशांश विस्तार clear for both finite prefixes and an infinite decimal representation?

## T094 — monotone / monotonically decreasing

- **Chosen wording:** एकस्वनिक / एकस्वनिक घटती
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted direct official mathematics-glossary components. This choice remains open to correction.
- **Rationale:** MR-P055 directly attests एकस्वनिक and एकस्वनिक क्रमिका, while MR-P054 directly attests घटता. The combined phrase states the direction required in the proof.
- **Alternatives considered:** एकदिश घटती; एकसुरी घटती; अवर्धमान.
- **Exact aligned source/target scopes:**

  - OLP-0048 B022–B023: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T094-OLP-0048-B022`, `T094-OLP-0048-B023`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:220`.
- **Authorities actually checked:**

  - [गणितशास्त्र परिभाषा कोश — M glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/M) — MR-P055, MR-C038, web-open lines 587-589 and 646-648. Observation hash is not an origin-page hash.
  - [गणितशास्त्र परिभाषा कोश — D glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/9/d) — MR-P054, MR-C037, web-open lines 178-180, 266-268, 342-344 and 418-420. Observation hash is not an origin-page hash.
- **Precise review question:** Does एकस्वनिक घटती communicate monotone decrease without suggesting strict decrease?

## T095 — limit / tends to zero

- **Chosen wording:** सीमा / सीमा शून्य आहे
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted official lexical attestation; mathematical sense controlled by source formulas. This choice remains open to correction.
- **Rationale:** MR-P056 officially attests सीमा as limit. OpenLogic's exact epsilon conditions determine when a sequence or difference function has zero as its limit.
- **Alternatives considered:** मर्यादा / शून्याकडे अभिसरते; सीमामूल्य.
- **Exact aligned source/target scopes:**

  - OLP-0048 B008–B013, B021: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T095-OLP-0048-B008`, `T095-OLP-0048-B009`, `T095-OLP-0048-B010`, `T095-OLP-0048-B011`, `T095-OLP-0048-B012`, `T095-OLP-0048-B013`, `T095-OLP-0048-B021`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:73, 75–76, 79, 82, 89, 93, 105, 112, 117, 129`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:68, 74, 87, 97, 105–106, 114, 124, 213`.
- **Authorities actually checked:**

  - [भौतिकशास्त्र परिभाषा कोश — indexed limit entry](https://shabdakosh.marathi.gov.in/ananya-glossary?page=13568) — MR-P056, MR-C039, current web-search extraction personally read 2026-09-05. Cross-disciplinary entry; observation hash is not an origin-page hash.
- **Precise review question:** Does सीमा remain unambiguous when the surrounding prose also discusses upper bounds?

## T096 — representative of an equivalence class

- **Chosen wording:** तुल्यतावर्गाचा प्रतिनिधी
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** adopted official lexical head with source-controlled mathematical role. This choice remains open to correction.
- **Rationale:** MR-P057 directly attests प्रतिनिधी, while MR-P026 supplies the established equivalence-class terminology. OpenLogic fixes the representative-function role.
- **Alternatives considered:** प्रातिनिधिक फलन; वर्गप्रतिनिधी; प्रतिनिधिक.
- **Exact aligned source/target scopes:**

  - OLP-0048 B014–B015: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T096-OLP-0048-B014`, `T096-OLP-0048-B015`
- **Literal English line hits:** none found in the current applied scope; aligned blocks above remain the trace locator.
- **Literal Marathi line hits:** none found as a literal phrase; glossary-token use or the aligned blocks above carry the decision.
- **Authorities actually checked:**

  - [Representative — मराठी शब्दकोश](https://shabdakosh.marathi.gov.in/node/43954) — MR-P057, MR-C040, web-open lines 10-16. Generic rather than mathematical entry; the target normalizes the spelling प्रतिनिधी.
  - [गट सिद्धांत](https://vishwakosh.marathi.gov.in/21196/) — MR-P026, MR-C016, representation isomorphism discussion, primary search observation. short primary-source observation read; source bytes not preserved
- **Precise review question:** Is प्रतिनिधी फलन sufficiently explicit whenever several equivalent sequences name one real?

## T097 — well-defined / independent of representatives

- **Chosen wording:** सुव्याख्यायित / प्रतिनिधीच्या निवडीपासून स्वतंत्र
- **Coverage:** applied in current partial source coverage.
- **Decision provenance:** contemporaneous durable decision at first current use.
- **Status/uncertainty:** contextual mathematical rendering supported by official lexical components. This choice remains open to correction.
- **Rationale:** MR-P058 attests the general sense सुस्पष्ट. The target uses the more explicit mathematical compound सुव्याख्यायित and immediately defines it as independence from the chosen representative.
- **Alternatives considered:** सुस्पष्ट; सुस्पष्टपणे परिभाषित; प्रतिनिधी-निरपेक्ष.
- **Exact aligned source/target scopes:**

  - OLP-0048 B014–B015: [English](../upstream/content/sets-functions-relations/arithmetization/cauchy.tex) ↔ [Marathi](../mr/content/sets-functions-relations/arithmetization/cauchy.tex)
- **Occurrence records:** `T097-OLP-0048-B014`, `T097-OLP-0048-B015`
- **Literal English line hits:** `upstream/content/sets-functions-relations/arithmetization/cauchy.tex:153`.
- **Literal Marathi line hits:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:143, 152`.
- **Authorities actually checked:**

  - [विकृतिशास्त्र पारिभाषिक शब्दावली — W glossary](https://shabdakosh.marathi.gov.in/ananya-glossary/35/W) — MR-P058, MR-C041, current web-search extraction personally read 2026-09-05. Cross-disciplinary entry and contextual mathematical extension; observation hash is not an origin-page hash.
  - [Representative — मराठी शब्दकोश](https://shabdakosh.marathi.gov.in/node/43954) — MR-P057, MR-C040, web-open lines 10-16. Generic rather than mathematical entry; the target normalizes the spelling प्रतिनिधी.
  - [गट सिद्धांत](https://vishwakosh.marathi.gov.in/21196/) — MR-P026, MR-C016, representation isomorphism discussion, primary search observation. short primary-source observation read; source bytes not preserved
- **Precise review question:** Does the immediate representative-independence gloss make सुव्याख्यायित transparent to a Marathi reader?

# Source corrections and difficult source decisions

## MR-SI001 — OLP-0012

- **Source location:** `content/sets-functions-relations/relations/relations-as-sets.tex:83-100`.
- **Target location:** `mr/content/sets-functions-relations/relations/relations-as-sets.tex:83-100`.
- **Occurrence record:** `MR-SI001-OLP-0012`.
- **Finding:** I is used without an explicit local assignment, after defining Id(A). The preceding diagonal discussion indicates that I means Id(Nat).
- **Chosen action:** Explain I as the preceding diagonal identity relation, without replacing the source formula.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** high contextual interpretation
- **Precise review question:** Is the current source-preserving note mathematically precise and natural in Marathi, or should a different visible correction be used?

## MR-SI002 — OLP-0018

- **Source location:** `content/sets-functions-relations/relations/trees.tex:90-95`.
- **Target location:** `mr/content/sets-functions-relations/relations/trees.tex:89-94`.
- **Occurrence record:** `MR-SI002-OLP-0018`.
- **Finding:** Ambient tree set was A; X has no definition here. Intended domain is A minus B.
- **Chosen action:** Explain the likely intended A domain while preserving X in aligned source.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** high local notation defect
- **Precise review question:** Is the current source-preserving note mathematically precise and natural in Marathi, or should a different visible correction be used?

## MR-SI003 — OLP-0018

- **Source location:** `content/sets-functions-relations/relations/trees.tex:110-118`.
- **Target location:** `mr/content/sets-functions-relations/relations/trees.tex:109-117`.
- **Occurrence record:** `MR-SI003-OLP-0018`.
- **Finding:** A rooted tree is required to have a unique least element, so the empty prefix-closed subset does not meet the earlier tree definition. This example requires nonempty A under that convention.
- **Chosen action:** State the nonempty qualification for consistency with the given rooted-tree definition.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** high boundary case
- **Precise review question:** Is the current source-preserving note mathematically precise and natural in Marathi, or should a different visible correction be used?

## OLFUN-001 — OLP-0024

- **Source location:** `content/sets-functions-relations/functions/inverses.tex:62-84`.
- **Target location:** `mr/content/sets-functions-relations/functions/inverses.tex:66`.
- **Occurrence record:** `OLFUN-001-OLP-0024`.
- **Finding:** An injection f:A to B has a left inverse iff A is nonempty or B is empty.
- **Chosen action:** Added A nonempty to the translated theorem and proof; formulas unchanged.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** confirmed mathematical defect
- **Precise review question:** Is the Marathi distinction between the simple repaired theorem and the exact empty-set condition completely unambiguous?

## OLFUN-002 — OLP-0021

- **Source location:** `content/sets-functions-relations/functions/function-basics.tex:64-71; content/sets-functions-relations/sets/important-sets.tex:17`.
- **Target location:** `mr/content/sets-functions-relations/functions/function-basics.tex:71`.
- **Occurrence record:** `OLFUN-002-OLP-0021`.
- **Finding:** The source calls the selected square root positive on all natural-number inputs, but OpenLogic includes zero and the selected root at zero is zero, hence nonnegative rather than positive.
- **Chosen action:** Used ऋणेतर (प्रधान) वर्गमूळ for the selector on all natural numbers; display and preceding positive-integer two-root claim unchanged.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** confirmed wording defect
- **Precise review question:** Is प्रधान वर्गमूळ the clearest Marathi modifier here, or should the body keep only ऋणेतर वर्गमूळ?

## OLFUN-003 — OLP-0021

- **Source location:** `content/sets-functions-relations/functions/function-basics.tex:103-107`.
- **Target location:** `mr/content/sets-functions-relations/functions/function-basics.tex:107`.
- **Occurrence record:** `OLFUN-003-OLP-0021`.
- **Finding:** The source changes the input variable from n to x within one example even though its displayed function is defined in x.
- **Chosen action:** Used x consistently in the translated prose; mathematical formula unchanged.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** confirmed typographical inconsistency
- **Precise review question:** Does the repaired prose read naturally without suggesting a change to the source function definition?

## OLFUN-004 — OLP-0023

- **Source location:** `content/sets-functions-relations/functions/functions-relations.tex:24-30,61-64; content/sets-functions-relations/relations/relations-as-sets.tex:55-58`.
- **Target location:** `mr/content/sets-functions-relations/functions/functions-relations.tex:74`.
- **Occurrence record:** `OLFUN-004-OLP-0023`.
- **Finding:** Calling the graph a relation on A×B conflicts with the book's own definition: the graph is a relation between A and B, hence a subset of A×B.
- **Chosen action:** Said relation between A and B contained in A×B, avoiding the project-defined but incorrect literal relation on A×B wording.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** confirmed terminology imprecision
- **Precise review question:** Is the chosen Marathi wording standard and concise for a heterogeneous binary relation?

## OLFUN-005 — OLP-0023

- **Source location:** `content/sets-functions-relations/functions/functions-relations.tex:78-100; content/sets-functions-relations/relations/operations.tex:20-32`.
- **Target location:** `mr/content/sets-functions-relations/functions/functions-relations.tex:101`.
- **Occurrence record:** `OLFUN-005-OLP-0023`.
- **Finding:** Function restriction limits the domain coordinate only, while the earlier relation restriction R∩C² limits both coordinates; they are analogous operations but not literally identical.
- **Chosen action:** Kept domain-only function restriction and qualified the analogy: relation restriction to C limits both coordinates, so the operations are analogous but not identical.
- **Alternatives considered:** Preserve source silently; Change aligned mathematical content directly.
- **Uncertainty:** confirmed explanatory inconsistency; explicit definition correct
- **Precise review question:** Would Marathi readers benefit from displaying the counterexample in the main reader, or is the concise adjacent distinction sufficient?

## OLSIZ-001 — OLP-0029

- **Source location:** `content/sets-functions-relations/size-of-sets/enumerability.tex:145-153`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:145-153`.
- **Occurrence record:** `OLSIZ-001-OLP-0029`.
- **Finding:** The header and formula rows include f(7), whose value is -3, but the final value row stops at 3 and omits -3.
- **Chosen action:** Inserted the missing -3 beneath f(7) in the Marathi table and added the adjacent keyed note; frozen English bytes remain unchanged.
- **Alternatives considered:** Leave the omission and annotate only; Change the frozen English table.
- **Uncertainty:** None about the value; the controlling formula gives -3.
- **Precise review question:** Is the inserted -3 cell and adjacent Marathi source note the clearest correction?

## MRSIZ-001 — OLP-0029

- **Source location:** `content/sets-functions-relations/size-of-sets/enumerability.tex:252-265`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/enumerability.tex:278`.
- **Occurrence record:** `MRSIZ-001-OLP-0029`.
- **Finding:** The statement uses the finite initial segment 0 through n while the proof obtains 0 through n-1; the parameter is implicitly renamed.
- **Chosen action:** Preserved both endpoints and added an adjacent clarification that they describe the same family after reindexing.
- **Alternatives considered:** Normalize both endpoints; Leave the reindexing implicit.
- **Uncertainty:** No mathematical uncertainty; this is a Marathi-lane explanatory observation outside the shared deterministic-defect list.
- **Precise review question:** Would an explicit parameter renaming be clearer than the current adjacent note?

## OLSIZ-002 — OLP-0031

- **Source location:** `content/sets-functions-relations/size-of-sets/pairing.tex:91-96`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/pairing.tex:91-95`.
- **Occurrence record:** `OLSIZ-002-OLP-0031`.
- **Finding:** The phrase 'complement of a finite set Nat' is malformed and omits the relation between the finite set and Nat.
- **Chosen action:** Rendered the body as the complement in Nat of a finite subset of Nat and added the adjacent keyed note.
- **Alternatives considered:** Translate the malformed phrase literally; Rely on the following equivalence without a note.
- **Uncertainty:** None about the intended relation; the following formula controls it.
- **Precise review question:** Does the Marathi wording state both the ambient Nat and the finite-subset relation without redundancy?

## MRSIZ-002 — OLP-0031

- **Source location:** `content/sets-functions-relations/size-of-sets/pairing.tex:107-108`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/pairing.tex:112`.
- **Occurrence record:** `MRSIZ-002-OLP-0031`.
- **Finding:** A pairing function is defined only as an injection A×B→Nat, so its inverse is generally partial and is not an enumeration unless the pairing function is surjective.
- **Chosen action:** Separated the surjective case from the general range-restricted inverse argument and added an adjacent note.
- **Alternatives considered:** Strengthen the definition to bijection; Assume surjectivity only in the exercise; Preserve the false claim.
- **Uncertainty:** No mathematical uncertainty; this is an additional Marathi-lane finding outside the shared audit.
- **Precise review question:** Should the exercise retain both cases or simply assume a bijective pairing function?

## OLSIZ-003 — OLP-0032

- **Source location:** `content/sets-functions-relations/size-of-sets/pairing-alt.tex:39-45`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:41-45`.
- **Occurrence record:** `OLSIZ-003-OLP-0032`.
- **Finding:** The prose repeats the family (2,m) where it is enumerating successive rows.
- **Chosen action:** Replaced the second (2,m) occurrence by (3,m) in the Marathi body and added the adjacent keyed note.
- **Alternatives considered:** Retain both (2,m) occurrences and explain in prose; Change the frozen English source.
- **Uncertainty:** None; the following table fixes the intended row family.
- **Precise review question:** Is the direct (3,m) correction and note preferable to retaining the duplicated displayed family?

## MRSIZ-003 — OLP-0032

- **Source location:** `content/sets-functions-relations/size-of-sets/pairing-alt.tex:20-27`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/pairing-alt.tex:26`.
- **Occurrence record:** `MRSIZ-003-OLP-0032`.
- **Finding:** The prose calls (0,2) the second pair after (0,0), but the table places (0,1) in that position.
- **Chosen action:** Identified (0,1) as intended in prose while retaining the frozen formula occurrence and adding an adjacent note.
- **Alternatives considered:** Directly replace the formula by (0,1); Preserve the inconsistency silently.
- **Uncertainty:** Very low; this is an additional Marathi-lane finding outside the shared audit.
- **Precise review question:** Should the displayed prose formula also be directly corrected to (0,1) in a future source-authorized edition?

## OLSIZ-004 — OLP-0034

- **Source location:** `content/sets-functions-relations/size-of-sets/reduction.tex:47-69`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/reduction.tex:50-60`.
- **Occurrence record:** `OLSIZ-004-OLP-0034`.
- **Finding:** The definition calls f(Z) the sequence s_k although k is never bound or determined.
- **Chosen action:** Replaced the unbound s_k and s_k(n) forms by one bound output name s and s(n), and added the adjacent keyed note.
- **Alternatives considered:** Use s_Z; Define a numerical k from Z; Retain the unbound subscript.
- **Uncertainty:** No semantic uncertainty; an unsubscripted s was selected for the corrected notation.
- **Precise review question:** Would s_Z communicate dependence on Z more clearly than the chosen bound name s?

## OLSIZ-005 — OLP-0034

- **Source location:** `content/sets-functions-relations/size-of-sets/reduction.tex:85-100`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/reduction.tex:96-106`.
- **Occurrence record:** `OLSIZ-005-OLP-0034`.
- **Finding:** The displayed h(n) is explicitly a finite string of n zeros, but h is declared to map into the set of infinite binary sequences.
- **Chosen action:** Appended an explicit infinite tail of ones after the n initial zeros, making every displayed value an element of Bin^omega, and added the adjacent keyed note.
- **Alternatives considered:** Use a constant all-zero sequence; Use n zeros followed by an alternating infinite tail; Retain the finite string.
- **Uncertainty:** No codomain uncertainty; the chosen eventually-one family is one of several valid non-surjective examples.
- **Precise review question:** Is the n-zeros-then-ones family the clearest corrected non-surjective map for this warning?

## OLSIZ-006 — OLP-0035

- **Source location:** `content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:68-94`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:72-100`.
- **Occurrence record:** `OLSIZ-006-OLP-0035`.
- **Finding:** Two conditional variants refer to g(x)=y before g is introduced, although the bijection in scope is f.
- **Chosen action:** Replaced both premature g(x)=y occurrences by f(x)=y in the Marathi conditional branches and added one adjacent keyed note.
- **Alternatives considered:** Avoid a named equation; Retain g and explain the typo.
- **Uncertainty:** None; f is the only bijection in scope in both empty-set branches.
- **Precise review question:** Is the direct two-occurrence replacement by f(x)=y sufficiently clear in both retained branches?

## MRSIZ-004 — OLP-0035

- **Source location:** `content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:87-94`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/equinumerous-sets.tex:101`.
- **Occurrence record:** `MRSIZ-004-OLP-0035`.
- **Finding:** The same finite domain is first called an initial sequence and later an initial segment; the preceding definition uses initial segment.
- **Chosen action:** Used आरंभीचा खंड consistently and added an adjacent note.
- **Alternatives considered:** Translate the two English labels differently; Normalize silently.
- **Uncertainty:** Very low; this is an additional Marathi-lane observation outside the shared audit.
- **Precise review question:** Should the frozen source normalize initial sequence to initial segment?

## OLSIZ-007 — OLP-0036

- **Source location:** `content/sets-functions-relations/size-of-sets/comparing-size.tex:74-90`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/comparing-size.tex:81-109`.
- **Occurrence record:** `OLSIZ-007-OLP-0036`.
- **Finding:** After choosing arbitrary x in A, the source says the conclusion holds for each x in overline(A).
- **Chosen action:** Changed the Marathi conclusion to quantify over every x∈A and added the adjacent keyed note.
- **Alternatives considered:** Rewrite the two cases without a displayed equivalence; Retain the too-narrow scope and explain it.
- **Uncertainty:** None; excluding every possible input x∈A is required to prove the diagonal set is outside the range.
- **Precise review question:** Is the corrected universal scope over A sufficiently explicit in the Marathi proof?

## OLSIZ-008 — OLP-0039

- **Source location:** `content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:61-75`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:60-64`.
- **Occurrence record:** `OLSIZ-008-OLP-0039`.
- **Finding:** The prose calls s_n(m) the nth digit of the mth string, reversing the indices.
- **Chosen action:** Described s_n(m) as the mth digit of the nth string, consistent with row n and column m, and added the adjacent keyed note.
- **Alternatives considered:** Translate the reversed index description literally; Rely on the following row/column sentence without a note.
- **Uncertainty:** None; the immediately following sentence and array fix the intended index order.
- **Precise review question:** Is the corrected nth-string/mth-digit wording the clearest match to the array?

## OLSIZ-009 — OLP-0039

- **Source location:** `content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:77-84`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/non-enumerability-alt.tex:77-82`.
- **Occurrence record:** `OLSIZ-009-OLP-0039`.
- **Finding:** The intuitive diagonal instruction says to change every 1 to 0 twice.
- **Chosen action:** Stated both complementary bit flips, 1 to 0 and 0 to 1, and added the adjacent keyed note.
- **Alternatives considered:** Repeat the defective 1-to-0 instruction literally; Omit the intuitive prose and rely only on the cases formula.
- **Uncertainty:** None; the immediately following cases formula determines both flips.
- **Precise review question:** Does the repaired two-way bit-flip sentence align transparently with the cases formula?

## OLSIZ-010 — OLP-0040

- **Source location:** `content/sets-functions-relations/size-of-sets/reduction-alt.tex:48-58`.
- **Target location:** `mr/content/sets-functions-relations/size-of-sets/reduction-alt.tex:52-56`.
- **Occurrence record:** `OLSIZ-010-OLP-0040`.
- **Finding:** The alternate proof again calls f(N) the string s_k although k is never bound or determined.
- **Chosen action:** Replaced the unbound s_k and s_k(n) forms by one bound output name s and s(n), and added the adjacent keyed note.
- **Alternatives considered:** Use s_N; Define an index k from N; Retain the unbound subscript.
- **Uncertainty:** No semantic uncertainty; unsubscripted s was chosen as the bound output name.
- **Precise review question:** Would s_N communicate dependence on N more clearly than the chosen bound name s?

## MRARITH-001 — OLP-0043

- **Source location:** `content/sets-functions-relations/arithmetization/rationals.tex:52-60`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/rationals.tex:54-58`.
- **Occurrence record:** `MRARITH-001-OLP-0043`.
- **Finding:** After correctly stating that r≤s exactly when s−r is not negative, the next English phrase says r−s can be written with nonnegative numerator and positive denominator. The following displayed definition again uses s−r, so the middle occurrence reverses the sign.
- **Chosen action:** Used s−r consistently in the Marathi explanatory sentence and displayed definition, added the adjacent MRARITH-001 note, and left the frozen English bytes unchanged.
- **Alternatives considered:** Translate the reversed r−s phrase literally and annotate it; Omit the explanatory equivalence and rely on the displayed definition.
- **Uncertainty:** None about the intended expression; both the immediately preceding clause and immediately following displayed equation use s−r.
- **Precise review question:** Does the direct s−r correction plus adjacent note make the order definition clear without interrupting the derivation?

## MRARITH-002 — OLP-0044

- **Source location:** `content/sets-functions-relations/arithmetization/reals.tex:24`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/reals.tex:24-25`.
- **Occurrence record:** `MRARITH-002-OLP-0044`.
- **Finding:** The commented-out English footnote says the symbol √2 refers equally to positive and negative roots. Under the standard radical convention used by the theorem, √2 denotes the principal nonnegative root; the two roots of x²=2 are ±√2.
- **Chosen action:** Corrected the Marathi version of the inactive footnote, added the adjacent MRARITH-002 note, and made no change to active reader content or frozen English bytes.
- **Alternatives considered:** Translate the false inactive footnote literally; Omit the inactive footnote from the editable Marathi source.
- **Uncertainty:** None under the standard real radical convention used throughout the section.
- **Precise review question:** Should the inactive corrected footnote remain for source parity, or should a future upstream-authorized edition remove the obsolete comment entirely?

## MRARITH-003 — OLP-0044

- **Source location:** `content/sets-functions-relations/arithmetization/reals.tex:72`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/reals.tex:74-77`.
- **Occurrence record:** `MRARITH-003-OLP-0044`.
- **Finding:** The frozen English gives Stanley Tennenbaum's lifespan as 1927–2006; his memorial biography records that he died on 4 May 2005.
- **Chosen action:** Used 1927–2005 in Marathi and added the adjacent MRARITH-003 note; frozen English bytes remain unchanged.
- **Alternatives considered:** Preserve 2006 silently; Omit the parenthetical dates.
- **Uncertainty:** Birth-year sources vary between 1927 and 1928, so the frozen 1927 start is retained; the memorial gives an exact 2005 death date.
- **Precise review question:** Should a future upstream-authorized edition use 1927/28–2005, or retain the source's 1927 start while correcting only the certain death year?

## MRARITH-004 — OLP-0045

- **Source location:** `content/sets-functions-relations/arithmetization/cuts.tex:58-68`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:57-68`.
- **Occurrence record:** `MRARITH-004-OLP-0045`.
- **Finding:** The proof says that S having an upper bound implies at least one cut belongs to S. An empty family can have upper bounds; λ is nonempty because the theorem separately assumes S is nonempty.
- **Chosen action:** Used the explicit nonemptiness assumption to prove λ nonempty, retained the upper-bound assumption for the common omitted rational needed to prove λ proper, and added the adjacent MRARITH-004 note.
- **Alternatives considered:** Translate the invalid implication literally; Reorder the proof to select an element of S before defining λ.
- **Uncertainty:** None; nonemptiness is an explicit theorem hypothesis and is exactly what supplies a member of S.
- **Precise review question:** Does the corrected first sentence make clear that nonemptiness and boundedness serve separate parts of the cut proof?

## MRARITH-005 — OLP-0045

- **Source location:** `content/sets-functions-relations/arithmetization/cuts.tex:91-95`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:94-102`.
- **Occurrence record:** `MRARITH-005-OLP-0045`.
- **Finding:** The positive-product formula writes the zero cut once as 0^mathbb{R}, while the surrounding definitions consistently use 0_Real. The superscript form is inconsistent with the established embedding notation.
- **Chosen action:** Used 0_Real in the Marathi formula, added the adjacent MRARITH-005 note, and registered the exact projection in tools/qa_aligned.py.
- **Alternatives considered:** Preserve the isolated superscript form; Rewrite every zero-cut occurrence with a verbose set-builder.
- **Uncertainty:** None; the immediately following source comment and every case condition use 0_Real.
- **Precise review question:** Is the direct 0_Real normalization preferable to preserving the isolated source typo in display?

## MRARITH-006 — OLP-0045

- **Source location:** `content/sets-functions-relations/arithmetization/cuts.tex:96-108`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cuts.tex:103-116`.
- **Occurrence record:** `MRARITH-006-OLP-0045`.
- **Finding:** The source says ‘first let:’ but comments out the zero-product equation on the same line. The remaining strict-sign cases omit products where either factor is zero, leaving multiplication incompletely defined.
- **Chosen action:** Activated the source's own zero-product equation in Marathi before the negative cases and added the adjacent MRARITH-006 note. The formula tokens remain source-identical because the frozen source still contains them in its comment.
- **Alternatives considered:** Keep the equation disabled and leave zero cases undefined; Add zero branches to the later cases display.
- **Uncertainty:** None; the later cases use strict inequalities and cannot cover a zero factor.
- **Precise review question:** Should a future upstream-authorized edition restore the zero-product equation as active source text exactly where the Marathi edition does?

## MRARITH-007 — OLP-0047

- **Source location:** `content/sets-functions-relations/arithmetization/checking-details.tex:145-151`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:143-148`.
- **Occurrence record:** `MRARITH-007-OLP-0047`.
- **Finding:** The English phrase ‘run through the (tedious) of checking’ is grammatically incomplete because the noun after ‘tedious’ is missing.
- **Chosen action:** Rendered the intended phrase as ‘the tedious checking’ in Marathi and added the adjacent MRARITH-007 note; frozen English bytes remain unchanged.
- **Alternatives considered:** Mirror the broken syntax; Omit the parenthetical adjective.
- **Uncertainty:** None about the intended meaning; the sentence explicitly says what remains to be checked.
- **Precise review question:** Is the concise Marathi repair preferable to supplying a more specific missing noun such as task or process?

## MRARITH-008 — OLP-0047

- **Source location:** `content/sets-functions-relations/arithmetization/cuts.tex:90-96; content/sets-functions-relations/arithmetization/checking-details.tex:170-173`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/checking-details.tex:167-171`.
- **Occurrence record:** `MRARITH-008-OLP-0047`.
- **Finding:** The appendix asks the reader to check that real subtraction and division yield cuts, but the preceding frozen cuts section leaves both corresponding formulas in comments. Thus the active source text has not supplied the definitions that this exercise presupposes.
- **Chosen action:** Preserved the exercise claim and formulas in Marathi, added an adjacent MRARITH-008 note, and did not invent or activate a potentially incomplete division construction.
- **Alternatives considered:** Activate the commented formulas without proving they define the intended operations; Delete subtraction and division from the exercise.
- **Uncertainty:** The intended high-level operations are clear, but the commented division formula is not sufficiently supported to promote as a source correction without a fuller reconstruction.
- **Precise review question:** Should a future upstream-authorized mathematical revision supply and prove complete subtraction and reciprocal definitions before retaining this exercise?

## MRARITH-009 — OLP-0048

- **Source location:** `content/sets-functions-relations/arithmetization/cauchy.tex:109-125`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:102-123`.
- **Occurrence record:** `MRARITH-009-OLP-0048`.
- **Finding:** The frozen sentence says to identify real numbers with equivalence relations, while the construction immediately and correctly defines them as equivalence classes under one equivalence relation.
- **Chosen action:** Rendered the intended object as तुल्यतावर्ग in Marathi and added the adjacent MRARITH-009 note; frozen English bytes remain unchanged.
- **Alternatives considered:** Mirror equivalence relations literally; Delete the mistaken identification sentence.
- **Uncertainty:** None; the following definition explicitly names equivalence classes as the reals.
- **Precise review question:** Does the direct equivalence-class correction align cleanly with the immediately following construction?

## MRARITH-010 — OLP-0048

- **Source location:** `content/sets-functions-relations/arithmetization/cauchy.tex:149-154`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:145-153`.
- **Occurrence record:** `MRARITH-010-OLP-0048`.
- **Finding:** The positivity definition compares a real equivalence class with rational zero 0_Rat even though the preceding embedding defines real zero as 0_Real.
- **Chosen action:** Changed only this occurrence to 0_Real in Marathi, added MRARITH-010, and registered a narrow exact-QA projection back to the frozen symbol.
- **Alternatives considered:** Keep 0_Rat and rely on implicit embedding; Rewrite the definition without a named zero.
- **Uncertainty:** None; both sides of the inequality and equality are elements of the constructed real field.
- **Precise review question:** Is the direct 0_Real correction the clearest type-consistent notation?

## MRARITH-011 — OLP-0048

- **Source location:** `content/sets-functions-relations/arithmetization/cauchy.tex:161-185`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:159-186`.
- **Occurrence record:** `MRARITH-011-OLP-0048`.
- **Finding:** The theorem, exercise and completeness statement say Cauchy sequences constitute an ordered field, although the operations and order were defined on their equivalence classes; the proof also occasionally applies real order directly to a sequence representative.
- **Chosen action:** Named the equivalence classes explicitly in the theorem, exercise and completeness statement, and added MRARITH-011 to state the representative-class convention used by the preserved proof formulas.
- **Alternatives considered:** Retain the shorthand without explanation; Rewrite every later formula to wrap representatives in equivalence-class notation.
- **Uncertainty:** None about the field's carrier; fully normalizing every proof formula would create a larger mathematical rewrite.
- **Precise review question:** Does the adjacent convention make the preserved proof notation readable while keeping the field carrier exact?

## MRARITH-012 — OLP-0048

- **Source location:** `content/sets-functions-relations/arithmetization/cauchy.tex:133-147`.
- **Target location:** `mr/content/sets-functions-relations/arithmetization/cauchy.tex:126-143`.
- **Occurrence record:** `MRARITH-012-OLP-0048`.
- **Finding:** After defining addition and multiplication on equivalence classes, the source asks only for closure of pointwise sum, difference and product under the Cauchy property. It omits the separate proof that changing representatives does not change the resulting class.
- **Chosen action:** Preserved the operations and assigned closure check, then added MRARITH-012 disclosing the additional well-definedness obligation without inventing a proof.
- **Alternatives considered:** Supply an unrequested proof; Leave the missing obligation implicit.
- **Uncertainty:** None that representative independence is required for operations on quotient classes.
- **Precise review question:** Is the adjacent disclosure sufficient until a source-authorized proof is supplied?
